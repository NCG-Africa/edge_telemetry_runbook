#!/bin/bash
# Checks getstarted.sh maps each supported distro to the right package family
# and Docker repo. Run: bash shared/scripts/test-distro-detection.sh
set -u
SCRIPT="$(cd "$(dirname "$0")/../.." && pwd)/getstarted.sh"
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
fail=0

check() { # <name> <os-release body> <expected fields, space separated>
  printf '%s\n' "$2" > "$TMP/os-release"
  got=$(OS_RELEASE="$TMP/os-release" bash "$SCRIPT" --detect-only 2>&1 | tail -1)
  for want in $3; do
    case " $got " in
      *" $want "*) ;;
      *) echo "FAIL $1: expected '$want' in '$got'"; fail=1; return ;;
    esac
  done
  echo "ok   $1"
}

check ubuntu   'ID=ubuntu
ID_LIKE=debian
UBUNTU_CODENAME=noble
PRETTY_NAME="Ubuntu 24.04"'                   'family=debian docker_repo=ubuntu'

check debian   'ID=debian
VERSION_CODENAME=bookworm
PRETTY_NAME="Debian 12"'                      'family=debian docker_repo=debian'

check rhel     'ID="rhel"
ID_LIKE="fedora"
PRETTY_NAME="Red Hat Enterprise Linux 9.7"'   'family=rhel docker_repo=rhel'

check rocky    'ID="rocky"
ID_LIKE="rhel centos fedora"
PRETTY_NAME="Rocky Linux 9"'                  'family=rhel docker_repo=centos'

check amazon   'ID="amzn"
ID_LIKE="fedora"
PRETTY_NAME="Amazon Linux 2023"'              'family=rhel docker_repo=none'

check sles     'ID="sles"
ID_LIKE="suse"
PRETTY_NAME="SLES 15"'                        'family=suse docker_repo=sles'

# unsupported distro must abort, not guess
printf 'ID=plan9\nPRETTY_NAME="Plan 9"\n' > "$TMP/os-release"
if OS_RELEASE="$TMP/os-release" bash "$SCRIPT" --detect-only > /dev/null 2>&1; then
  echo "FAIL unsupported: expected non-zero exit"; fail=1
else
  echo "ok   unsupported distro aborts"
fi

exit $fail
