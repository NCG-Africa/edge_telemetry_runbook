#!/usr/bin/env bash
# Remove what acceptance runs wrote: RUN_ID=<id> for one run, RUN_ID=all for every run.
# Revokes the keys first (A3: an App with an active key can't be deleted; the revoke
# tombstones the key on rum-api-keys), deletes the Apps through the API (which purges
# their sessions and telemetry), then the rows no App owns: devices, users, dead letters,
# legacy key rows. Run from deployments/single-host.
set -uo pipefail
here=$(cd "$(dirname "$0")" && pwd)
one=${RUN_ID:?set RUN_ID=<id> for one run, or RUN_ID=all for every run on this install}
[ "$one" = all ] && { unset RUN_ID; one=; }
# shellcheck source=lib.sh
. "$here/lib.sh"
if [ -n "$one" ]; then dev=$DEV_PREFIX- pkg=$PKG_PREFIX. app=$APP_PREFIX-; else dev=acc- pkg=com.acceptance.r app=acceptance-; fi
log "acceptance clean ${one:-<every run>} ($(date -u +%FT%TZ))"
mint_jwt
failed=0
# ponytail: devices, users and <app-not-registered> dead letters carry no tenant, so those
# deletes match the device prefix alone; RUN_ID=all widens it to every acc-* device.
tenant="tenant_id = '$ACCEPTANCE_TENANT_ID'"
ours="$tenant AND (name LIKE '$app%' OR package_name LIKE '$pkg%')"
apps=$(q "SELECT id FROM rum_apps WHERE $ours")

while IFS='|' read -r a k; do
  [ -n "$k" ] || continue
  api PATCH "/api/v1/rum/mobile/apps/$a/api-keys/$k/revoke"
  log "    revoke key $k (App $a): HTTP $HTTP_CODE"; [ "$HTTP_CODE" = 200 ] || { log "      $HTTP_BODY"; failed=1; }
done <<< "$(q "SELECT app_id || '|' || id FROM rum_api_keys WHERE $tenant AND app_id IS NOT NULL
               AND api_revoked_at IS NULL AND app_id IN (SELECT id FROM rum_apps WHERE $ours)")"
for k in $(q "SELECT api_key_id FROM rum_api_keys WHERE $tenant AND app_id IS NULL AND api_revoked_at IS NULL
              AND api_key_name LIKE '$app%'"); do
  api POST /api/v1/api-keys/revoke "{\"api_key_id\":\"$k\"}"
  log "    revoke legacy key $k: HTTP $HTTP_CODE"; [ "$HTTP_CODE" = 200 ] || { log "      $HTTP_BODY"; failed=1; }
done
for a in $apps; do
  api DELETE "/api/v1/rum/apps/$a"
  log "    delete App $a: HTTP $HTTP_CODE"; [ "$HTTP_CODE" = 200 ] || { log "      $HTTP_BODY"; failed=1; }
done

q "BEGIN;
   DELETE FROM processor_device_context WHERE rum_device_id IN (SELECT id FROM rum_devices WHERE device_id LIKE '$dev%');
   DELETE FROM rum_devices WHERE device_id LIKE '$dev%';
   DELETE FROM rum_users WHERE user_id LIKE '$dev%';
   DELETE FROM processor_dead_letter_events WHERE event_json::text LIKE '%\"$dev%';
   DELETE FROM rum_api_keys WHERE $tenant AND app_id IS NULL AND api_revoked_at IS NOT NULL AND api_key_name LIKE '$app%';
   COMMIT;" || failed=1
log "    left: $(q "SELECT 'apps=' || (SELECT count(*) FROM rum_apps WHERE $ours)
                   || ' devices=' || (SELECT count(*) FROM rum_devices WHERE device_id LIKE '$dev%')
                   || ' dead_letters=' || (SELECT count(*) FROM processor_dead_letter_events WHERE event_json::text LIKE '%\"$dev%')
                   || ' keys=' || (SELECT count(*) FROM rum_api_keys WHERE $tenant AND api_key_name LIKE '$app%')")"
if [ "$failed" = 0 ]; then log "clean: done"; else log "clean: FAILED (see above)"; fi
exit "$failed"
