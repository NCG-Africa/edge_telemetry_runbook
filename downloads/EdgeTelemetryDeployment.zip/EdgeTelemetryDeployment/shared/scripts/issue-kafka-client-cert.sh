#!/bin/bash
# Issue Kafka client certificate and create JKS keystores for bank-side processor
# Usage: ./issue-kafka-client-cert.sh --ca-cert ./ca/ca-cert.pem --ca-key ./ca/ca-key.pem --client-name bank-processor --output-dir ./client-certs

set -euo pipefail

CA_CERT=""
CA_KEY=""
CLIENT_NAME=""
OUTPUT_DIR="./kafka-client-certs"
KEYSTORE_PASS="changeit"
VALIDITY_DAYS=365

while [[ $# -gt 0 ]]; do
    case $1 in
        --ca-cert) CA_CERT="$2"; shift 2 ;;
        --ca-key) CA_KEY="$2"; shift 2 ;;
        --client-name) CLIENT_NAME="$2"; shift 2 ;;
        --output-dir) OUTPUT_DIR="$2"; shift 2 ;;
        --keystore-pass) KEYSTORE_PASS="$2"; shift 2 ;;
        --validity-days) VALIDITY_DAYS="$2"; shift 2 ;;
        -h|--help)
            echo "Usage: $0 [OPTIONS]"
            echo ""
            echo "Required:"
            echo "  --ca-cert FILE         CA certificate PEM file"
            echo "  --ca-key FILE          CA private key PEM file"
            echo "  --client-name NAME     Client identifier (e.g., bank-processor)"
            echo ""
            echo "Optional:"
            echo "  --output-dir DIR       Output directory (default: ./kafka-client-certs)"
            echo "  --keystore-pass PASS   Keystore password (default: changeit)"
            echo "  --validity-days DAYS   Certificate validity (default: 365)"
            exit 0
            ;;
        *) echo "Unknown option: $1"; exit 1 ;;
    esac
done

if [[ -z "$CA_CERT" || -z "$CA_KEY" || -z "$CLIENT_NAME" ]]; then
    echo "ERROR: --ca-cert, --ca-key, and --client-name are required"
    exit 1
fi

mkdir -p "$OUTPUT_DIR"
WORK_DIR=$(mktemp -d)
trap "rm -rf $WORK_DIR" EXIT

echo "Issuing Kafka client certificate..."
echo "  Client: $CLIENT_NAME"
echo "  CA cert: $CA_CERT"
echo "  Output: $OUTPUT_DIR"

# Step 1: Generate client keystore with keypair
echo "[1/5] Generating client keystore..."
keytool -genkey -noprompt \
    -alias "kafka-client-$CLIENT_NAME" \
    -dname "CN=$CLIENT_NAME,O=EdgeTelemetry,OU=Bank" \
    -keystore "$OUTPUT_DIR/client.keystore.jks" \
    -keyalg RSA \
    -keysize 2048 \
    -validity "$VALIDITY_DAYS" \
    -storepass "$KEYSTORE_PASS" \
    -keypass "$KEYSTORE_PASS"

# Step 2: Generate CSR from keystore
echo "[2/5] Generating certificate signing request..."
keytool -certreq \
    -alias "kafka-client-$CLIENT_NAME" \
    -keystore "$OUTPUT_DIR/client.keystore.jks" \
    -file "$WORK_DIR/client.csr" \
    -storepass "$KEYSTORE_PASS" \
    -keypass "$KEYSTORE_PASS"

# Step 3: Sign the CSR with the CA
echo "[3/5] Signing certificate with CA..."
openssl x509 -req \
    -in "$WORK_DIR/client.csr" \
    -CA "$CA_CERT" \
    -CAkey "$CA_KEY" \
    -CAcreateserial \
    -out "$WORK_DIR/client-signed.pem" \
    -days "$VALIDITY_DAYS"

# Step 4: Import CA cert and signed cert into keystore
echo "[4/5] Importing certificates into keystore..."
keytool -import -noprompt \
    -alias ca-root \
    -file "$CA_CERT" \
    -keystore "$OUTPUT_DIR/client.keystore.jks" \
    -storepass "$KEYSTORE_PASS"

keytool -import -noprompt \
    -alias "kafka-client-$CLIENT_NAME" \
    -file "$WORK_DIR/client-signed.pem" \
    -keystore "$OUTPUT_DIR/client.keystore.jks" \
    -storepass "$KEYSTORE_PASS" \
    -keypass "$KEYSTORE_PASS"

# Step 5: Create truststore with CA cert
echo "[5/5] Creating truststore..."
keytool -import -noprompt \
    -alias ca-root \
    -file "$CA_CERT" \
    -keystore "$OUTPUT_DIR/client.truststore.jks" \
    -storepass "$KEYSTORE_PASS"

echo ""
echo "Kafka client certificates generated:"
echo "  Keystore:   $OUTPUT_DIR/client.keystore.jks"
echo "  Truststore: $OUTPUT_DIR/client.truststore.jks"
echo ""
echo "Copy these to: deployments/segmented/bank/secrets/kafka-tls/"
echo "Update KAFKA_CLIENT_KEYSTORE_PASSWORD in deployments/segmented/bank/.env to: $KEYSTORE_PASS"
