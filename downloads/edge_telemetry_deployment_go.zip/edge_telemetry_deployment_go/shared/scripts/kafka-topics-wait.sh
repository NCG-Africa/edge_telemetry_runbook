#!/usr/bin/env bash
# Bank-side topic gate (spec K5 across hosts, K8), run by the one-shot
# kafka-topics-wait compose service. The bank can't depend_on the DMZ's
# kafka-init, so this polls the DMZ Kafka over mTLS every 5 s until
# telemetry-upsert has 12 partitions and rum-api-keys has 1, then exits 0.
# Exits 1 after KAFKA_TOPICS_WAIT_SECONDS (300). Never creates or alters a topic.
#
# Env: KAFKA_BOOTSTRAP_SERVERS (required), KAFKA_TOPIC, KAFKA_API_KEYS_TOPIC,
#      KAFKA_TOPICS_WAIT_SECONDS, plus kafka-mtls-config.sh's KAFKA_TLS_*.
set -uo pipefail

bs=${KAFKA_BOOTSTRAP_SERVERS:?}
upsert=${KAFKA_TOPIC:-telemetry-upsert}
keys=${KAFKA_API_KEYS_TOPIC:-rum-api-keys}
timeout=${KAFKA_TOPICS_WAIT_SECONDS:-300}
cc=$(bash /kafka-mtls-config.sh) || exit 1

partitions() {
  kafka-topics --bootstrap-server "$bs" --command-config "$cc" --describe --topic "$1" 2>/dev/null |
    sed -n 's/.*PartitionCount: *\([0-9]*\).*/\1/p' | head -1
}

while :; do
  u=$(partitions "$upsert"); k=$(partitions "$keys")
  state="$upsert partitions=${u:-missing}, $keys partitions=${k:-missing}"
  if [ "$u" = 12 ] && [ "$k" = 1 ]; then
    echo "kafka-topics-wait: ready: $state"
    exit 0
  fi
  if (( SECONDS >= timeout )); then
    echo "kafka-topics-wait: TIMEOUT after ${timeout}s on $bs: $state. Deploy the DMZ first (its kafka-init creates both topics)." >&2
    exit 1
  fi
  echo "kafka-topics-wait: waiting: $state"
  sleep 5
done
