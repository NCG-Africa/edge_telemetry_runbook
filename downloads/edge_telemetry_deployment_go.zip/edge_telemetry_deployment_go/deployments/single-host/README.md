# Single-Host Deployment (Go)

Everything on one host: Kafka, Zookeeper, Redis, Collector-Go, Processor-Go,
RUM Analytics Go, Kafka UI. No auth-plane split — Collector-Go runs `AUTH_MODE=api_key` against
an external PostgreSQL. Use this for dev, staging, or any production
environment without a network-segmentation requirement.

Drop-in replacement for the Python `EdgeTelemetryDeployment` single-host
stack: same container names (`telemetry-*`), network (`telemetry-network`),
host ports and data dir (`/opt/edge-telemetry`) — only the images are Go. Stop
the Python stack (`make down` in its single-host dir) before `make deploy` here;
the two cannot run side by side.

## Quick start

```bash
cp configs/single-host.env.example configs/single-host.env
# Edit configs/single-host.env: the single env file for all three Go services. Set DATABASE_URL
# to your external PostgreSQL and EDGE_JWT_SECRET (required when EDGE_ENV=prod).
make deploy
```

## Service URLs

| Service | URL |
|---|---|
| Collector-Go | http://localhost:8001 |
| Processor-Go | http://localhost:8002 |
| RUM Analytics Go | http://localhost:8003 |
| Kafka UI | Not publicly exposed. `ssh -p 2222 -L 8080:localhost:8080 jonathan@<host>` then http://localhost:8080 (login: `admin` / `SPRING_SECURITY_USER_PASSWORD`) |
| Redis | not published — reach it with `docker compose exec telemetry-redis redis-cli` |

The Kafka UI is bound to `127.0.0.1` on the host and runs in read-only mode with
a login password (`SPRING_SECURITY_USER_PASSWORD` in `configs/kafka-ui.env` —
`make config-check` fails the deploy if it is unset). Reach it by opening an SSH
local-forward to the host, then browsing to the forwarded port. Rationale and
rollout: [`../../docs/2026-09-08-secure-kafka-ui-design.md`](../../docs/2026-09-08-secure-kafka-ui-design.md).

## Commands

```bash
make deploy           # Build + start
make down              # Stop
make logs               # Tail all logs
make health              # Quick health check
make health-detailed      # Detailed health check
make status                # Container status
make test-deployment        # Send a sample telemetry event
make monitor                  # Live health/resource dashboard
```

See the root [`Makefile`](../../Makefile) and [`README.md`](../../README.md) for
the full command reference and the local-dev workflow (building from sibling
source instead of registry images).

## PostgreSQL

Never bundled in this compose file. Point `DATABASE_URL` in `configs/single-host.env` at a
managed or external instance (a `postgresql+asyncpg://` scheme is accepted).
Collector-Go and Processor-Go must reach the same `edge_db` database; Collector-Go reads
`rum_api_keys`, Processor-Go writes the RUM tables.

RUM Analytics Go reads the same `DATABASE_URL`. It requires the same RUM schema and Redis instance, exposes health
at `http://localhost:8003/api/v1/health`, browser API docs at
`http://localhost:8003/api/docs`, and the raw OpenAPI document at
`http://localhost:8003/api/openapi.json`.

The Go service image is `papijo/edge_telemetry_rum_analytics_go:latest`. It
uses `EDGE_ENV`, `EDGE_JWT_SECRET` (must equal edge_platform's), `EDGE_JWT_ALG`,
`EDGE_ALLOW_JWT_FALLBACK`, `ALLOWED_ORIGINS`,
`REDIS_CACHE_TTL`, and `DB_POOL_SIZE` from `configs/single-host.env`.
Production mode requires `EDGE_JWT_SECRET` and rejects
`EDGE_ALLOW_JWT_FALLBACK=true`.
