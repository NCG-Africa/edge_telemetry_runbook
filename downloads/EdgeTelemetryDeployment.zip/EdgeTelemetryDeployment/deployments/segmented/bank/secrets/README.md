# Bank Secrets

This directory holds secret material for the bank deployment. **Never commit these files to git.**

## `jwt-signing-keys/`

Place JWT keypair here for the RUM Analytics service to sign tokens.

- `private.pem` — RS256 private key used to sign JWTs
- `public.pem` — RS256 public key (also deployed to DMZ for verification)
- Generate with `shared/scripts/generate-jwt-keypair.sh`

## `kafka-tls/`

Place Kafka client TLS material here for the Processor to connect to DMZ Kafka via mTLS.

- `client.keystore.jks` — Client keystore (contains client cert + private key)
- `client.truststore.jks` — Truststore containing the CA cert (used to verify Kafka server cert)

Generate with `shared/scripts/issue-kafka-client-cert.sh`.
