# shellcheck shell=bash
# X1: a 4.0 batch with a bound key lands with the key's app_id and environment on its
# session, contract_version header 4.0.0, and a rum_app_versions row (A4, C9, P13, P15, P16).
x1() {
  X1_DEVICE=$DEV_PREFIX-x1 X1_SESSION=$DEV_PREFIX-x1-s1 X1_VERSION=1.0.$RUN_ID
  create_app x1 android || return 1
  X1_APP=$APP_ID
  issue_key x1 "$X1_APP" production || return 1
  wait_for "collector to load key x1" 15 key_known x1 || return 1

  local before msg hdrs ok=0
  before=$(ends)
  post_batch x1 /telemetry "$(render batch-4.0.json "$X1_DEVICE" "$X1_SESSION" "$PKG_PREFIX.x1" "$(iso)")" || return 1
  msg=$(kfind "$X1_DEVICE" "$before")
  check "Kafka messages for $X1_DEVICE" 1 "$(printf '%s' "$msg" | grep -c .)" || return 1
  X1_PART=$(printf '%s' "$msg" | cut -f1) X1_OFF=$(printf '%s' "$msg" | cut -f2)
  hdrs=$(printf '%s' "$msg" | cut -f3)
  log "    batch at partition $X1_PART offset $X1_OFF"
  check "header contract_version" 4.0.0 "$(header contract_version "$hdrs")" || ok=1
  check "header app_id" "$X1_APP" "$(header app_id "$hdrs")" || ok=1
  check "header environment" production "$(header environment "$hdrs")" || ok=1

  wait_for "X1 session in rum_sessions" 60 events_are "$X1_DEVICE" 2 || return 1
  local row version_id
  row=$(session_row "$X1_SESSION")
  version_id=$(q "SELECT id FROM rum_app_versions WHERE app_id = $X1_APP AND version = '$X1_VERSION' AND build_number = '7'")
  check "rum_sessions app_id" "$X1_APP" "$(echo "$row" | cut -d'|' -f1)" || ok=1
  check "rum_sessions environment" production "$(echo "$row" | cut -d'|' -f2)" || ok=1
  check "rum_app_versions row ($X1_VERSION, 7)" yes "$([ -n "$version_id" ] && echo yes || echo no)" || ok=1
  check "rum_sessions app_version_id" "$version_id" "$(echo "$row" | cut -d'|' -f3)" || ok=1
  return $ok
}
