#!/bin/bash
# Install Docker Engine + Compose from static binaries — no package manager,
# no repos, no RHEL subscription. For hosts that can reach the internet but
# have no enabled dnf/apt repos.
#
# Usage: sudo bash install-docker-norepo.sh [docker-version]
set -e

DOCKER_VER="${1:-28.0.1}"
ARCH=$(uname -m)
CLI_PLUGINS=/usr/local/lib/docker/cli-plugins

[ "$EUID" -eq 0 ] || { echo "Run with sudo: sudo bash $0"; exit 1; }
[ "$ARCH" = "x86_64" ] || [ "$ARCH" = "aarch64" ] || { echo "Unsupported arch: $ARCH"; exit 1; }

# Docker needs iptables for bridge networking; it is not in the static tarball
if ! command -v iptables > /dev/null; then
  echo "ERROR: iptables is missing and cannot be installed without repos."
  echo "       Bridge networking will not work. Use podman instead, or get"
  echo "       iptables-nft installed by whoever manages this host."
  exit 1
fi

echo "==> Downloading Docker ${DOCKER_VER} (${ARCH}) static binaries..."
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
curl -fsSL "https://download.docker.com/linux/static/stable/${ARCH}/docker-${DOCKER_VER}.tgz" \
  -o "$TMP/docker.tgz"
tar -xzf "$TMP/docker.tgz" -C "$TMP"
install -m 0755 "$TMP"/docker/* /usr/bin/

echo "==> Installing the Compose plugin..."
mkdir -p "$CLI_PLUGINS"
curl -fsSL "https://github.com/docker/compose/releases/latest/download/docker-compose-linux-${ARCH}" \
  -o "$CLI_PLUGINS/docker-compose"
chmod +x "$CLI_PLUGINS/docker-compose"

echo "==> Creating the systemd unit..."
cat > /etc/systemd/system/docker.service <<'UNIT'
[Unit]
Description=Docker Application Container Engine
After=network-online.target
Wants=network-online.target

[Service]
Type=notify
ExecStart=/usr/bin/dockerd -H unix:///var/run/docker.sock
ExecReload=/bin/kill -s HUP $MAINPID
Restart=always
RestartSec=2
LimitNOFILE=infinity
LimitNPROC=infinity
LimitCORE=infinity
TasksMax=infinity
Delegate=yes
KillMode=process
OOMScoreAdjust=-500

[Install]
WantedBy=multi-user.target
UNIT

groupadd -f docker
[ -n "${SUDO_USER:-}" ] && usermod -aG docker "$SUDO_USER"

systemctl daemon-reload
systemctl enable --now docker

# firewalld is on by default on RHEL and blocks the service ports
if systemctl is-active --quiet firewalld 2>/dev/null; then
  for P in 80 443 8001 8002 8003 8080; do
    firewall-cmd --permanent --add-port="${P}/tcp" > /dev/null
  done
  firewall-cmd --reload > /dev/null
  echo "==> Opened ports 80 443 8001 8002 8003 8080 in firewalld"
fi

echo ""
docker --version
docker compose version
echo ""
echo "Done. Log out and back in (or run 'newgrp docker') to use docker without sudo."
