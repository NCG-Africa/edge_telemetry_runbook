#!/bin/bash
# EdgeTelemetry Go — Ubuntu host bootstrap
# Installs Docker + Docker Compose, verifies Go toolchain availability (for
# local dev only — not required on a pure deployment server), and prepares
# the /opt/edge-telemetry data directories used by the single-host Makefile.

set -euo pipefail

echo "EdgeTelemetry Go — host bootstrap"
echo "=================================="

if ! command -v docker &> /dev/null; then
    echo "[1/4] Installing Docker from Docker's official apt repository..."
    # Deliberately NOT `curl https://get.docker.com | sh` — that pipes unverified
    # remote code into a root shell. The apt path verifies every package against
    # Docker's GPG key instead. Ubuntu/Debian only, which this script already assumes.
    sudo apt-get update
    sudo apt-get install -y ca-certificates curl
    sudo install -m 0755 -d /etc/apt/keyrings
    sudo curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
    sudo chmod a+r /etc/apt/keyrings/docker.asc
    # shellcheck source=/dev/null
    . /etc/os-release
    sudo tee /etc/apt/sources.list.d/docker.sources > /dev/null <<EOF
Types: deb
URIs: https://download.docker.com/linux/ubuntu
Suites: ${UBUNTU_CODENAME:-$VERSION_CODENAME}
Components: stable
Architectures: $(dpkg --print-architecture)
Signed-By: /etc/apt/keyrings/docker.asc
EOF
    sudo apt-get update
    sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
    # Membership of the docker group is equivalent to root on this host — only add
    # accounts that are already trusted with root.
    sudo usermod -aG docker "$USER"
    echo "  Docker installed. Log out and back in for docker-group membership to apply."
else
    echo "[1/4] Docker already installed: $(docker --version)"
fi

if ! docker compose version &> /dev/null; then
    echo "ERROR: Docker Compose v2 plugin not found. Install it before continuing."
    exit 1
else
    echo "[2/4] Docker Compose already installed: $(docker compose version)"
fi

if command -v go &> /dev/null; then
    echo "[3/4] Go toolchain found: $(go version) (only needed for local dev / building from source)"
else
    echo "[3/4] Go toolchain not found (only needed for local dev / building from source, not for deployment)"
fi

echo "[4/4] Preparing data directories..."
sudo mkdir -p /opt/edge-telemetry/data/{kafka,zookeeper,redis}
sudo mkdir -p /opt/edge-telemetry/logs/{zookeeper,redis}
sudo chown -R 1000:1000 /opt/edge-telemetry/

echo ""
echo "Bootstrap complete."
echo ""
echo "Next steps:"
echo "  Single-host: cd deployments/single-host && cp configs/single-host.env.example configs/single-host.env && make deploy"
echo "  Segmented:   see shared/README.md for CA and Kafka mTLS cert provisioning, then deploy dmz/ and bank/ separately."
