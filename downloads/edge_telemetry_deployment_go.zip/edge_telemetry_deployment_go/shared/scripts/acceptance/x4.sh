# shellcheck shell=bash
# X4: replaying the same Kafka message, or the same DLQ batch row, twice creates no
# duplicate rows (P5, P18). Needs X1 and X2 earlier in the same run.
x4() {
  if [ -z "${X1_OFF:-}" ] || [ -z "${X2_DLQ_ID:-}" ]; then log "    FAIL needs X1 and X2 earlier in the same run"; return 1; fi
  local before ok=0
  wait_for "processor to drain" 120 lag_zero || return 1

  # Rewind the group to X1's message so the processor consumes it a second time.
  before=$(device_counts "$X1_DEVICE")
  log "    $X1_DEVICE before: $before"
  "${DC[@]}" stop telemetry-processor >/dev/null 2>&1 || { log "    FAIL stop processor"; return 1; }
  "${DC[@]}" exec -T kafka kafka-consumer-groups --bootstrap-server localhost:29092 --group "$GROUP" \
    --topic "$TOPIC:$X1_PART" --reset-offsets --to-offset "$X1_OFF" --execute >/dev/null 2>&1 \
    || { log "    FAIL reset $GROUP to $X1_PART:$X1_OFF"; "${DC[@]}" start telemetry-processor >/dev/null 2>&1; return 1; }
  check "committed offset on partition $X1_PART after the rewind" "$X1_OFF" "$(committed "$X1_PART")" || ok=1
  "${DC[@]}" up -d --wait telemetry-processor >/dev/null 2>&1 || { log "    FAIL start processor"; return 1; }
  wait_for "processor to re-consume $X1_PART:$X1_OFF" 120 lag_zero || return 1
  check "committed offset on partition $X1_PART moved past X1" yes \
    "$([ "$(committed "$X1_PART")" -gt "$X1_OFF" ] && echo yes || echo no)" || ok=1
  check "$X1_DEVICE rows after re-consuming X1" "$before" "$(device_counts "$X1_DEVICE")" || ok=1

  # Replay X2's dead-letter row a second time.
  before=$(device_counts "$X2_DEVICE")
  log "    $X2_DEVICE before: $before"
  replay "$X2_DLQ_ID" || return 1
  check "second replay succeeded" 1 "$(printf '%s' "$HTTP_BODY" | jq -r .succeeded)" || ok=1
  check "$X2_DEVICE rows after the second replay" "$before" "$(device_counts "$X2_DEVICE")" || ok=1
  check "DLQ rows for $X2_DEVICE" 1 "$(dlq_count "$X2_DEVICE")" || ok=1
  return $ok
}
