# Single-Host Deployment

All EdgeTelemetry services run on a single host. Suitable for development, staging, or single-server production where there is no network segmentation requirement.

**No authentication.** The collector accepts telemetry without JWT or API key checks. Only run this mode behind a trusted network boundary, or in front of a reverse proxy that enforces auth.

## Services

- Zookeeper + Kafka (message broker)
- Telemetry Collector (port 8001)
- Telemetry Processor (port 8002)
- RUM Analytics API (port 8003)
- Redis Cache (port 6379)
- Kafka UI (port 8080)

## Prerequisites

- Docker 27.5+ and Docker Compose v2
- 4GB+ RAM
- Access to PostgreSQL database
- Ports 8001-8003, 8080, 6379 available

## Setup

1. **Configure environment:**
   ```bash
   cp configs/single-host.env.example configs/single-host.env
   nano configs/single-host.env
   ```

   Required: set `DATABASE_URL` to your PostgreSQL connection string.

2. **Deploy:**
   ```bash
   make deploy
   ```

3. **Verify:**
   ```bash
   make health
   ```

## Commands

```bash
make deploy              # Deploy all services
make down                # Stop all services
make logs                # View all logs
make restart             # Restart services
make update              # Pull latest images and redeploy
make health              # Quick health check
make health-detailed     # Health check with DB/cache status
make test-deployment     # Send test telemetry data
make test-rum-analytics  # Test RUM Analytics API
make test-full           # Full integration test
make monitor             # Real-time monitoring dashboard
make backup              # Backup data volumes
make config-check        # Validate configuration
```

## Service URLs

| Service | URL |
|---------|-----|
| Collector API | http://localhost:8001 |
| Processor API | http://localhost:8002 |
| RUM Analytics API | http://localhost:8003 |
| Kafka UI | http://localhost:8080 |

## Troubleshooting

**Services unhealthy after deploy?** The deploy target includes auto-recovery. Check `make health-detailed` for specific issues.

**Database connection issues?** Verify `DATABASE_URL` in `configs/single-host.env` and ensure the database is reachable from the host.

**Port conflicts?** Check `docker compose ps` and adjust port mappings in `docker-compose.yml` if needed.
