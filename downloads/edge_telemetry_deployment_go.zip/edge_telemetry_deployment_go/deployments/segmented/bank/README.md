# Segmented Deployment — Bank (Go)

Internal half of the segmented topology: Redis, Processor-Go and RUM
Analytics Go — same layout, names and ports as the Python bank deployment.
Processor-Go (consumes `telemetry-upsert`) and RUM Analytics (produces API keys
to `rum-api-keys`) connect outward to the DMZ's external Kafka listener over
mTLS, each with its own client cert; both connect outward to an external
PostgreSQL.

## Prerequisites

Provision two Kafka client certificates once via `shared/scripts/` (see
`../../../shared/README.md`):

- `secrets/kafka-tls/` — `ca.cert.pem`, `client.cert.pem`, `client.key.pem`
  for the processor (`--client-name bank-processor`); `kafka-topics-wait` uses
  it too.
- `secrets/kafka-tls-analytics/` — the same three files for RUM Analytics,
  issued with `--client-name bank-analytics`. `make config-check` fails if it
  is missing or is a copy of the processor's cert.

The containers run as uid `65534`, so each `client.key.pem` (mode 600)
must be owned by that uid — `issue-kafka-client-cert.sh` does the `chown`, or
prints the `sudo` command to run if it cannot.

## Quick start

```bash
cp configs/bank.env.example configs/bank.env
# then edit configs/bank.env — set POSTGRES_*, DATABASE_URL, EDGE_JWT_SECRET,
# REDIS_PASSWORD and DMZ_KAFKA_EXTERNAL_FQDN
make deploy
```

**Deploy the DMZ first.** The bank can't depend on the DMZ's `kafka-init`, so
the one-shot `kafka-topics-wait` polls the DMZ Kafka over mTLS until
`telemetry-upsert` has 12 partitions and `rum-api-keys` has 1. The processor and
analytics start only after it exits 0; after `KAFKA_TOPICS_WAIT_SECONDS`
(default 300) it exits 1 and they stay down. It never creates or alters a topic.

`PROCESSOR_WORKERS` (default 4, max 12) sets the processor's Kafka Readers;
`PG_POOL_MAX_CONNS` must be at least that. `make config-check` enforces both.

Analytics without its Kafka env fails closed: key create and revoke answer 503.
The DMZ runs `kafka-lag-watch` for the processor group, not the bank.
No broker ACLs protect `rum-api-keys` (known limit, see
[`shared/README.md`](../../../shared/README.md#known-limit-no-acls-on-rum-api-keys)).

`DMZ_KAFKA_EXTERNAL_FQDN` must match the FQDN the DMZ Kafka broker's server
certificate was issued for (see `deployments/segmented/dmz/README.md`).

## Upgrade

`make update` runs in phases across both hosts (DMZ stop, bank drain, DMZ
topics, bank start, DMZ start). The runbook is in
[`../dmz/README.md`](../dmz/README.md#upgrade-make-update-both-hosts).
`make kafka-lag` shows the processor group's lag, read over mTLS.

## Service URLs

| Service | URL |
|---|---|
| Processor-Go | http://127.0.0.1:8002 (loopback only — health endpoint) |
| RUM Analytics Go | http://127.0.0.1:8003 (loopback only — front it with a host reverse proxy) |
| Redis | not published — reach it with `docker compose exec telemetry-redis redis-cli` |

## PostgreSQL

Never bundled in this compose file. Processor-Go has no `DATABASE_URL`
support — set the discrete `POSTGRES_HOST` / `POSTGRES_PORT` /
`POSTGRES_DATABASE` / `POSTGRES_USER` / `POSTGRES_PASSWORD` / `POSTGRES_SSLMODE`
vars in `configs/bank.env`.

RUM Analytics Go reads `DATABASE_URL` instead — point it at the same `edge_db`.
