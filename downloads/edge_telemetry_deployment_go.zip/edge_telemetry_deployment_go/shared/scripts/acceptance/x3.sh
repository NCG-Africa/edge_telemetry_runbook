# shellcheck shell=bash
# X3: a revoked key is rejected by the collector within seconds of the revoke, with no
# restart (A9, C2, C4).
x3() {
  local started i ok=0
  create_app x3 ios || return 1
  issue_key x3 "$APP_ID" staging || return 1
  wait_for "collector to load key x3" 15 key_known x3 || return 1
  started=$(docker inspect -f '{{.State.StartedAt}}' telemetry-collector)

  api PATCH "/api/v1/rum/mobile/apps/$APP_ID/api-keys/$KEY_ID/revoke"
  check "revoke HTTP" 200 "$HTTP_CODE" || return 1
  # Every 500ms for 10s.
  for i in $(seq 1 20); do
    sleep 0.5
    key_rejected x3 && break
  done
  check "collector answer to the revoked key" 401 "$HTTP_CODE" || ok=1
  [ "$HTTP_CODE" = 401 ] && log "    401 after $(( i * 500 ))ms"
  check "collector StartedAt (no restart)" "$started" "$(docker inspect -f '{{.State.StartedAt}}' telemetry-collector)" || ok=1
  return $ok
}
