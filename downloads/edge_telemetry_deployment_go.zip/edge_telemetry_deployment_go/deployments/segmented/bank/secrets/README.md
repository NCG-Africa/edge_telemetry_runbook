# Bank Secrets

- `kafka-tls/` — `ca.cert.pem`, `client.cert.pem`, `client.key.pem`, from
  `shared/scripts/issue-kafka-client-cert.sh`. PEM, not JKS — Processor-Go's
  Go TLS stack reads these directly. Used by the processor and kafka-topics-wait.
- `kafka-tls-analytics/` — the same three files for RUM Analytics, issued with
  `--client-name bank-analytics`. Its own cert, never a copy of the processor's
  (`make config-check` refuses one): `CN=bank-analytics` is the principal a
  future `StandardAuthorizer` would grant write on `rum-api-keys`.

Never commit real files here — only this README is tracked; `.gitignore` at
the repo root blocks `*.pem`.
