# shellcheck shell=bash disable=SC2034  # globals are read by the x*.sh checks
# Shared helpers for the acceptance run (sourced by run.sh and clean.sh).
# Runs from deployments/single-host. Needs: docker, curl, jq, openssl.
#
# Env:
#   ACCEPTANCE_OK=yes          required: this writes Apps, keys and telemetry to the install
#   ACCEPTANCE_TENANT_ID       core.tenants id the run's Apps and keys belong to
#   ACCEPTANCE_USER_ID         active core.users id; the JWT's sub (RequireVerifiedUser)
#   RUN_ID                     defaults to a timestamp; tags every device, package and App

if [ "${ACCEPTANCE_OK:-}" != yes ]; then
  echo "acceptance: refusing to run. It writes Apps, API keys and telemetry into this install's" >&2
  echo "acceptance: database and Kafka. Only with the operator's consent: ACCEPTANCE_OK=yes" >&2
  exit 2
fi
for bin in docker curl jq openssl; do
  command -v "$bin" >/dev/null || { echo "acceptance: $bin is required" >&2; exit 2; }
done
: "${ACCEPTANCE_TENANT_ID:?set ACCEPTANCE_TENANT_ID (core.tenants id)}"
: "${ACCEPTANCE_USER_ID:?set ACCEPTANCE_USER_ID (active core.users id, the JWT sub)}"

ENV_FILE=configs/single-host.env
[ -f "$ENV_FILE" ] || { echo "acceptance: run from deployments/single-host ($ENV_FILE missing)" >&2; exit 2; }
DC=(docker compose --env-file "$ENV_FILE")
COLLECTOR=http://127.0.0.1:8001
PROCESSOR=http://127.0.0.1:8002
ANALYTICS=http://127.0.0.1:8003
TOPIC=telemetry-upsert
GROUP=edge-telemetry-processor
# Same pinned client as db-baseline.sh; no bundled container has psql.
PSQL_IMAGE=postgres:18.1-alpine

RUN_ID=${RUN_ID:-$(date -u +%Y%m%d%H%M%S)}
DEV_PREFIX=acc-$RUN_ID
PKG_PREFIX=com.acceptance.r$RUN_ID
APP_PREFIX=acceptance-$RUN_ID

mkdir -p backups
LOG=backups/acceptance-$RUN_ID.log
TMPD=$(mktemp -d)
chmod 700 "$TMPD"
trap 'rm -rf "$TMPD"' EXIT

env_value() { sed -n "s/^$1=//p" "$ENV_FILE" | tail -1; }
DBURL=$(env_value DATABASE_URL | sed 's/+asyncpg//')

# Every log line goes through mask: API keys and JWTs never reach the terminal or the log.
mask() { sed -E -e 's/(edge_[A-Za-z0-9]{8})_[A-Za-z0-9_-]+/\1_***/g' -e 's/eyJ[A-Za-z0-9_-]*\.[A-Za-z0-9_-]*\.[A-Za-z0-9_-]*/<jwt>/g'; }
log() { printf '%s\n' "$*" | mask | tee -a "$LOG"; }

# check <what> <want> <got>: logs ok/FAIL, returns 1 on a mismatch.
check() {
  if [ "$2" = "$3" ]; then log "    ok   $1 = $3"; return 0; fi
  log "    FAIL $1: want '$2', got '$3'"
  return 1
}

# wait_for <what> <seconds> <cmd...>: polls cmd every second until it succeeds.
wait_for() {
  local what=$1 secs=$2; shift 2
  local deadline=$(( $(date +%s) + secs ))
  until "$@" >/dev/null 2>&1; do
    if [ "$(date +%s)" -ge "$deadline" ]; then log "    FAIL timed out after ${secs}s waiting for $what"; return 1; fi
    sleep 1
  done
}

b64url() { openssl base64 -A | tr '+/' '-_' | tr -d '='; }
mint_jwt() {
  local secret h p s
  secret=$(env_value EDGE_JWT_SECRET)
  [ -n "$secret" ] || { echo "acceptance: EDGE_JWT_SECRET missing in $ENV_FILE" >&2; exit 2; }
  h=$(printf '{"alg":"HS256","typ":"JWT"}' | b64url)
  p=$(printf '{"sub":"%s","tenant_id":"%s","exp":%d}' "$ACCEPTANCE_USER_ID" "$ACCEPTANCE_TENANT_ID" $(( $(date +%s) + 3600 )) | b64url)
  s=$(printf '%s.%s' "$h" "$p" | openssl dgst -sha256 -hmac "$secret" -binary | b64url)
  # Header file, not argv: the token never shows in ps or the log.
  printf 'Authorization: Bearer %s.%s.%s\n' "$h" "$p" "$s" > "$TMPD/jwt.h"
}

# http <method> <url> [body] [curl args...]: sets HTTP_CODE and HTTP_BODY.
http() {
  local m=$1 u=$2 d=${3:-} out
  shift; shift; [ $# -gt 0 ] && shift
  out=$(curl -sS -X "$m" "$u" -H 'Content-Type: application/json' ${d:+--data-binary "$d"} "$@" -w '\n%{http_code}' 2>&1) || true
  HTTP_CODE=${out##*$'\n'}
  HTTP_BODY=${out%$'\n'*}
}
api() { http "$1" "$ANALYTICS$2" "${3:-}" -H "@$TMPD/jwt.h"; }

# key files hold "X-API-Key: <key>" (mode 600 in TMPD) so keys never hit argv.
save_key() { printf 'X-API-Key: %s\n' "$2" > "$TMPD/$1.key"; }
# collect <key name> <path> <body> [x-forwarded-for]
collect() {
  local extra=()
  [ -n "${4:-}" ] && extra=(-H "X-Forwarded-For: $4")
  http POST "$COLLECTOR$2" "$3" -H "@$TMPD/$1.key" ${4:+"${extra[@]}"}
}

# q <sql>: one psql call, unaligned tuples only.
q() {
  docker run --rm -i --network host -e DBURL="$DBURL" "$PSQL_IMAGE" \
    sh -c 'psql "$DBURL" -XAtq -v ON_ERROR_STOP=1' <<< "$1"
}

# ends: "<partition> <end offset>" for every telemetry-upsert partition.
ends() {
  "${DC[@]}" exec -T kafka kafka-get-offsets --bootstrap-server localhost:29092 --topic "$TOPIC" --time -1 \
    | awk -F: '{print $2, $3}'
}
# kfind <device id> <ends snapshot>: the messages keyed by this device written since the
# snapshot, one per line in offset order: "<partition>\t<offset>\t<headers>\t<key>\t<value>".
# Found by key, not from the collector's response: its metadata.partition/offset are
# always 0 (edge_telemetry_collector_go, Publish reads kafka-go fields Writer never sets).
kfind() {
  local p to from
  ends | while read -r p to; do
    from=$(printf '%s\n' "$2" | awk -v p="$p" '$1 == p {print $2}')
    [ "${to:-0}" -gt "${from:-0}" ] || continue
    "${DC[@]}" exec -T kafka kafka-console-consumer --bootstrap-server localhost:29092 --topic "$TOPIC" \
      --partition "$p" --offset "$from" --max-messages $(( to - from )) --timeout-ms 20000 \
      --property print.offset=true --property print.headers=true --property print.key=true 2>/dev/null \
      | awk -F'\t' -v OFS='\t' -v d="$1" -v p="$p" '$3 == d {sub(/^Offset:/, "", $1); print p, $0}'
  done
}
# header <name> <headers>: value of one Kafka header from a "k:v,k:v" list.
header() { printf '%s\n' "$2" | tr ',' '\n' | sed -n "s/^$1://p" | head -1; }

lag_total() { make -s kafka-lag | sed -n 's/^total //p'; }
lag_zero() { [ "$(lag_total)" = 0 ]; }
# committed <partition>: the group's committed offset there ("-" if none).
committed() { make -s kafka-lag 2>/dev/null | awk -v p="$1" '$1 == "partition" && $2 == p {print $4}'; }

# render <fixture> <device> <session> <package> <event time> [locale]: a batch body.
FIXTURES=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
render() {
  sed -e "s/__DEVICE_ID__/$2/g" -e "s/__SESSION_ID__/$3/g" -e "s/__USER_ID__/$2-user/g" \
      -e "s/__PACKAGE__/$4/g" -e "s/__TS__/$5/g" -e "s/__LOCALE__/${6:-en-US}/g" \
      -e "s/__VERSION__/1.0.$RUN_ID/g" -e "s/__BUILD__/7/g" "$FIXTURES/$1" | jq -c .
}
# iso [offset seconds]: UTC RFC3339 with millis, now + offset (BSD and GNU date).
iso() {
  local t=$(( $(date +%s) + ${1:-0} ))
  date -u -r "$t" +%Y-%m-%dT%H:%M:%S.000Z 2>/dev/null || date -u -d "@$t" +%Y-%m-%dT%H:%M:%S.000Z
}

# create_app <suffix> <platform> [package]: sets APP_ID.
create_app() {
  api POST /api/v1/rum/apps "$(jq -nc --arg n "$APP_PREFIX-$1" --arg p "${3:-$PKG_PREFIX.$1}" --arg pl "$2" \
    '{name:$n, package_name:$p, platform:$pl}')"
  APP_ID=$(printf '%s' "$HTTP_BODY" | jq -r '.data.id // empty' 2>/dev/null)
  if [ "$HTTP_CODE" != 201 ] || [ -z "$APP_ID" ]; then log "    FAIL create App $1: HTTP $HTTP_CODE $HTTP_BODY"; return 1; fi
  log "    App $APP_PREFIX-$1 id=$APP_ID"
}
# issue_key <name> <app id> <environment>: saves the key as <name>, sets KEY_ID.
issue_key() {
  api POST "/api/v1/rum/mobile/apps/$2/api-keys" "$(jq -nc --arg n "$APP_PREFIX-$1" --arg e "$3" \
    '{name:$n, environment:$e, non_expiring:true}')"
  KEY_ID=$(printf '%s' "$HTTP_BODY" | jq -r '.data.key_id // empty' 2>/dev/null)
  if [ "$HTTP_CODE" != 201 ] || [ -z "$KEY_ID" ]; then log "    FAIL issue key $1: HTTP $HTTP_CODE $(printf '%s' "$HTTP_BODY" | mask)"; return 1; fi
  save_key "$1" "$(printf '%s' "$HTTP_BODY" | jq -r .data.api_key)"
  log "    key $1 id=$KEY_ID ($3)"
}
# legacy_key <name>: a pre-4.0 tenant-wide key (app_id NULL), saved as <name>. Minting one
# through the API returns 410 (A6), so the row goes in by SQL and analytics restarts to
# republish rum_api_keys to rum-api-keys (A10); the collector never reads Postgres.
legacy_key() {
  local lookup secret
  lookup=$(openssl rand -hex 4)
  secret=$(openssl rand -base64 36 | tr '+/' '-_' | tr -d '=')
  q "INSERT INTO rum_api_keys (tenant_id, user_id, api_key_id, api_key_hash, api_key_name)
     VALUES ('$ACCEPTANCE_TENANT_ID', '$ACCEPTANCE_USER_ID', 'edge_$lookup',
             '$(printf %s "$secret" | openssl dgst -sha256 -r | cut -d' ' -f1)', '$APP_PREFIX-$1')" || return 1
  save_key "$1" "edge_${lookup}_$secret"
  log "    legacy key $1 edge_$lookup (SQL), restarting analytics to republish it"
  "${DC[@]}" restart telemetry-rum-analytics >/dev/null 2>&1 || { log "    FAIL restart analytics"; return 1; }
  wait_for "collector to load legacy key $1" 90 key_known "$1"
}
# key_known <name>: the collector's key map has the key. A non-JSON body gets 400 after
# auth passes and 401 before, so probing writes nothing to Kafka.
key_known() { collect "$1" /telemetry 'not-json'; [ "$HTTP_CODE" = 400 ]; }
key_rejected() { collect "$1" /telemetry 'not-json'; [ "$HTTP_CODE" = 401 ]; }
# post_batch <key> <path> <body> [xff]: the collector must answer 200.
post_batch() {
  collect "$@"
  [ "$HTTP_CODE" = 200 ] || { log "    FAIL POST $2: HTTP $HTTP_CODE $HTTP_BODY"; return 1; }
}

# One session's (app_id, environment, app_version_id) as "a|e|v".
session_row() { q "SELECT app_id, coalesce(environment::text,''), coalesce(app_version_id::text,'') FROM rum_sessions WHERE session_id = '$1'"; }
# Rows a device has in rum_telemetry_events and every child table, as one line.
device_counts() {
  q "WITH e AS (SELECT e.id FROM rum_telemetry_events e JOIN rum_sessions s ON s.id = e.session_id
                JOIN rum_devices d ON d.id = s.device_id WHERE d.device_id = '$1'),
          dv AS (SELECT id FROM rum_devices WHERE device_id = '$1')
     SELECT 'events=' || (SELECT count(*) FROM e)
       || ' metrics=' || (SELECT count(*) FROM rum_performance_metrics WHERE telemetry_event_id IN (SELECT id FROM e))
       || ' perf_events=' || (SELECT count(*) FROM rum_performance_events WHERE telemetry_event_id IN (SELECT id FROM e))
       || ' errors=' || (SELECT count(*) FROM rum_errors WHERE telemetry_event_id IN (SELECT id FROM e))
       || ' navigations=' || (SELECT count(*) FROM rum_navigations WHERE telemetry_event_id IN (SELECT id FROM e))
       || ' ui=' || (SELECT count(*) FROM rum_ui_interactions WHERE telemetry_event_id IN (SELECT id FROM e))
       || ' http=' || (SELECT count(*) FROM rum_http_requests WHERE device_id IN (SELECT id FROM dv))
       || ' screens=' || (SELECT count(*) FROM rum_screen_durations WHERE device_id IN (SELECT id FROM dv))
       || ' sessions=' || (SELECT count(*) FROM rum_sessions WHERE device_id IN (SELECT id FROM dv))"
}
# The <app-not-registered> dead-letter row for a device's batch (GET /dead-letter only counts).
dlq_id() {
  q "SELECT min(id) FROM processor_dead_letter_events WHERE event_name = '<app-not-registered>'
       AND kafka_headers IS NOT NULL AND event_json::text LIKE '%\"$1\"%'"
}
dlq_row() { [ -n "$(dlq_id "$1")" ]; }
dlq_count() { q "SELECT count(*) FROM processor_dead_letter_events WHERE event_json::text LIKE '%\"$1\"%'"; }
# replay <dlq id>: POST /dead-letter/replay for that one row; the processor must answer 200.
replay() {
  http POST "$PROCESSOR/dead-letter/replay" "{\"ids\":[$1]}"
  [ "$HTTP_CODE" = 200 ] || { log "    FAIL replay $1: HTTP $HTTP_CODE $HTTP_BODY"; return 1; }
  log "    replay $1: $HTTP_BODY"
}
events_of() { q "SELECT count(*) FROM rum_telemetry_events e JOIN rum_sessions s ON s.id = e.session_id JOIN rum_devices d ON d.id = s.device_id WHERE d.device_id = '$1'"; }
events_are() { [ "$(events_of "$1")" = "$2" ]; }
