#!/usr/bin/env bash
# Lag alert (spec K7), run by the kafka-lag-watch compose service in a
# confluentinc/cp-kafka:7.4.0 container next to kafka-lag.sh.
#
# Every LAG_CHECK_SECONDS (300) it sums the processor group's lag on
# telemetry-upsert and logs one "WARN kafka_lag_high lag=<n>" line when the
# total exceeds LAG_ALERT_MESSAGES (1000000, ~48 min of backlog at 350
# batches/s). Silent otherwise. A failed read logs "WARN kafka_lag_check_failed"
# and the loop goes on; it never exits. Log-only: ops grep for kafka_lag_high.
#
# Env: LAG_ALERT_MESSAGES, LAG_CHECK_SECONDS, KAFKA_GROUP_ID, plus kafka-lag.sh's
#      KAFKA_BOOTSTRAP_SERVERS and KAFKA_TOPIC.
set -uo pipefail

group=${KAFKA_GROUP_ID:-edge-telemetry-processor}
threshold=${LAG_ALERT_MESSAGES:-1000000}
interval=${LAG_CHECK_SECONDS:-300}

while :; do
  if out=$(bash /kafka-lag.sh "$group" 2>&1); then
    total=$(sed -n 's/^total //p' <<< "$out")
    if [[ $total =~ ^[0-9]+$ ]] && (( total > threshold )); then
      echo "WARN kafka_lag_high lag=$total"
    fi
  else
    echo "WARN kafka_lag_check_failed $(tail -1 <<< "$out")"
  fi
  sleep "$interval"
done
