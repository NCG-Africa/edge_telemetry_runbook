#!/usr/bin/env bash
# Bring an existing edge_db (v012) up to the schema the Go services need.
# Manual, one-time, before the first Go deploy. Idempotent: re-running is a no-op.
#
#   db-baseline.sh <env-file>          apply shared/sql/go_baseline.sql (asks first)
#   db-baseline.sh <env-file> check    exit 1 if the baseline hasn't been applied
#
# Uses DATABASE_URL from the env file; the role must own the public rum_* tables
# and analytics.v_mobile_rum_rca_evidence (it is dropped and recreated).
set -euo pipefail

env_file=$1
sql="$(cd "$(dirname "$0")/../sql" && pwd)/go_baseline.sql"
url=$(grep -E '^DATABASE_URL=' "$env_file" | cut -d= -f2- | sed 's/+asyncpg//')
[ -n "$url" ] || { echo "DATABASE_URL missing in $env_file"; exit 1; }

psql() {
  docker run --rm -i --network host -e DBURL="$url" -v "$sql:/baseline.sql:ro" postgres:18.1-alpine \
    sh -c 'psql "$DBURL" -X -v ON_ERROR_STOP=1 "$@"' psql "$@"
}

if [ "${2:-}" = check ]; then
  # rum_action_envelopes is created last by the baseline, so it marks a complete run.
  applied=$(psql -Atc "select to_regclass('public.rum_action_envelopes') is not null")  # set -e: unreachable DB fails here
  if [ "$applied" = t ]; then
    echo "  DB baseline: applied"
  else
    echo "  DB baseline: NOT applied -- run: make db-baseline"
    exit 1
  fi
  exit 0
fi

echo "Target: ${url#*@}"

# Pre-flight: the baseline adds UNIQUE indexes on rum_apps(package_name) and
# rum_users(user_id); existing duplicates would abort it (issue #25).
dups=$(psql -At <<'SQL'
SELECT to_regclass('public.rum_apps') IS NOT NULL AS has_apps,
       to_regclass('public.rum_users') IS NOT NULL AS has_users \gset
\if :has_apps
SELECT 'rum_apps.package_name=' || package_name || '  rows=' || count(*) || '  ids=' || string_agg(id::text, ',' ORDER BY id)
FROM public.rum_apps WHERE package_name IS NOT NULL GROUP BY package_name HAVING count(*) > 1;
\endif
\if :has_users
SELECT 'rum_users.user_id=' || user_id || '  rows=' || count(*) || '  ids=' || string_agg(id::text, ',' ORDER BY id)
FROM public.rum_users WHERE user_id IS NOT NULL GROUP BY user_id HAVING count(*) > 1;
\endif
SQL
)
if [ -n "$dups" ]; then
  echo "Pre-flight FAILED: duplicates would block the baseline's unique indexes. Merge these first:"
  echo "$dups"
  exit 1
fi
echo "Pre-flight: no duplicate rum_apps.package_name / rum_users.user_id"

read -rp "Apply the Go baseline schema now? [y/N] " answer
[ "$answer" = y ] || { echo "Aborted"; exit 1; }
psql --single-transaction -q -f /baseline.sql
echo "DB baseline applied. Processor-Go's own migrations run on its next start."
