#!/usr/bin/env python3
"""Turn a schema-only pg_dump of the reference (demo) edge_db public schema into
an idempotent bring-up script that upgrades an older client DB (v012) to it.

    shared/scripts/gen-baseline-sql.py edge_db_public_schema.sql > shared/sql/go_baseline.sql

Only RUM/processor objects are kept (the demo also hosts the license/deployment
tool's tables, which client DBs don't need). Nothing is dropped and no existing
column is retyped except the hand-listed widenings in WIDEN.
"""
import re
import sys

KEEP = re.compile(r"^(rum_|processor_|v_trace_|trace_injection_outcome|_set_updated_at)")

# Existing v012 columns too narrow for what Go writes (22001 otherwise).
# Pinned by analytics.v_mobile_rum_rca_evidence, hence the drop/recreate dance.
# ponytail: int->bigint ids and numeric->double drift left alone; full-table rewrites,
# only matters past 2^31 rows. Add here if a client gets near that.
WIDEN = [
    ("rum_performance_metrics", "metric_name", "character varying(255)"),
    ("rum_performance_events", "event_name", "character varying(255)"),
    ("rum_performance_events", "memory_pressure_level", "character varying(50)"),
    ("rum_sessions", "network_type", "character varying(50)"),
]
# v012 NOT NULLs the Go services may leave empty.
DROP_NOT_NULL = [("rum_api_keys", "api_expires_at"), ("rum_crash_events", "crash_hash")]


def blocks(dump):
    """Yield (name, type, body) for each pg_dump TOC entry."""
    parts = re.split(r"^--\n-- Name: (.+?); Type: (.+?); Schema: .*?\n--\n", dump, flags=re.M)
    for i in range(1, len(parts), 3):
        body = re.sub(r"^\\(un)?restrict .*$", "", parts[i + 2], flags=re.M).strip()
        yield parts[i], parts[i + 1], body


def q(s):
    return "'" + s.replace("'", "''") + "'"


def guarded_constraint(table, name, definition):
    # Skip when the name or an identical definition already exists (v012 names differ).
    # NOT VALID on CHECK/FK so existing v012 rows can't abort the bring-up.
    nv = " NOT VALID" if definition.startswith(("CHECK", "FOREIGN KEY")) else ""
    return f"""DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid = 'public.{table}'::regclass
                 AND (conname = {q(name)} OR pg_get_constraintdef(oid) = {q(definition)})) THEN
    ALTER TABLE public.{table} ADD CONSTRAINT {name} {definition}{nv};
  END IF;
EXCEPTION WHEN invalid_table_definition THEN NULL;  -- second PRIMARY KEY: keep v012's
END $$;"""


def main(path):
    head, types, tables, columns, seqs, views, defaults, cons, idx = ([] for _ in range(9))
    for name, typ, body in blocks(open(path).read()):
        obj = name.split()[0].split("(")[0]
        if typ == "INDEX":  # named idx_*, filter by the table it's on
            obj = re.search(r" ON (?:ONLY )?public\.(\w+)", body).group(1)
        if not KEEP.match(obj):
            continue
        if typ == "TYPE":
            types.append(f"DO $$ BEGIN\n{body}\nEXCEPTION WHEN duplicate_object THEN NULL; END $$;")
        elif typ == "FUNCTION":
            head.append(body.replace("CREATE FUNCTION", "CREATE OR REPLACE FUNCTION", 1))
        elif typ == "TABLE":
            m = re.match(r"CREATE TABLE public\.(\w+) \(\n(.*)\n\);", body, re.S)
            t, lines = m.group(1), [l.strip().rstrip(",") for l in m.group(2).split("\n")]
            tables.append(f"CREATE TABLE IF NOT EXISTS public.{t} (\n" + m.group(2) + "\n);")
            for l in lines:
                c = re.match(r"CONSTRAINT (\w+) (.*)", l)
                if c:
                    cons.append(guarded_constraint(t, c.group(1), c.group(2)))
                    continue
                if "GENERATED ALWAYS" in l:
                    columns.append(f"ALTER TABLE public.{t} ADD COLUMN IF NOT EXISTS {l};")
                    continue
                # Existing tables may have rows: keep NOT NULL only when a default fills them.
                if " DEFAULT " not in l:
                    l = l.replace(" NOT NULL", "")
                columns.append(f"ALTER TABLE public.{t} ADD COLUMN IF NOT EXISTS {l};")
        elif typ == "SEQUENCE":
            seqs.append(body.replace("CREATE SEQUENCE", "CREATE SEQUENCE IF NOT EXISTS", 1))
        elif typ in ("SEQUENCE OWNED BY", "DEFAULT", "COMMENT"):
            defaults.append(body)
        elif typ == "VIEW":
            views.append(body.replace("CREATE VIEW", "CREATE OR REPLACE VIEW", 1))
        elif typ in ("CONSTRAINT", "FK CONSTRAINT"):
            m = re.match(r"ALTER TABLE ONLY public\.(\w+)\s+ADD CONSTRAINT (\w+) (.*);", body, re.S)
            cons.append(guarded_constraint(m.group(1), m.group(2), m.group(3)))
        elif typ == "INDEX":
            m = re.match(r"CREATE (UNIQUE )?INDEX (\w+) ON (.*);", body, re.S)
            shape = f"CREATE {m.group(1) or ''}INDEX ON {m.group(3)}"
            idx.append(f"""DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE schemaname = 'public' AND
                 (indexname = {q(m.group(2))} OR regexp_replace(indexdef, ' INDEX \\S+ ON ', ' INDEX ON ') = {q(shape)})) THEN
    {body}
  END IF;
END $$;""")
        else:
            sys.exit(f"unhandled pg_dump entry type: {typ} ({name})")

    widen = "\n".join(f"ALTER TABLE public.{t} ALTER COLUMN {c} TYPE {ty};" for t, c, ty in WIDEN)
    widen += "\n" + "\n".join(f"ALTER TABLE public.{t} ALTER COLUMN {c} DROP NOT NULL;" for t, c in DROP_NOT_NULL)
    out = [
        "-- GENERATED by shared/scripts/gen-baseline-sql.py from the demo edge_db public schema dump.",
        "-- Brings a v012 (or empty) edge_db up to the schema the Go services run on. Idempotent;",
        "-- run once, by hand, before the first Go deploy:  make db-baseline",
        "SET search_path = '';",
        "SET lock_timeout = '30s';",
        "\n-- types & functions", *types, *head,
        "\n-- sequences & tables", *seqs, *tables,
        "\n-- columns missing from older tables", *columns,
        "\n-- widen v012 columns (other-team views that pin them are dropped and recreated)",
        VIEW_DANCE.replace("%WIDEN%", widen),
        "\n-- defaults, ownership, comments", *defaults,
        "\n-- constraints", *cons,
        "\n-- indexes (UNIQUE ones fail on pre-existing duplicates: see issue #25)", *idx,
        "\n-- views", *views,
    ]
    print("\n\n".join(out))


# Same capture/drop/recreate pattern as Processor-Go 0003: any view outside public
# that depends on a widened column is saved, dropped, and recreated afterwards.
VIEW_DANCE = """CREATE TEMP TABLE _pinned_views ON COMMIT DROP AS
  SELECT DISTINCT v.oid::regclass::text AS name, pg_get_viewdef(v.oid) AS def, v.relkind
  FROM pg_depend d JOIN pg_rewrite r ON r.oid = d.objid JOIN pg_class v ON v.oid = r.ev_class
  WHERE d.refobjid IN ('public.rum_performance_metrics'::regclass, 'public.rum_performance_events'::regclass,
                       'public.rum_sessions'::regclass, 'public.rum_api_keys'::regclass, 'public.rum_crash_events'::regclass)
    AND v.oid <> d.refobjid AND v.relnamespace <> 'public'::regnamespace;
DO $$ DECLARE v record; BEGIN
  FOR v IN SELECT * FROM _pinned_views LOOP EXECUTE format('DROP VIEW IF EXISTS %s', v.name); END LOOP;
END $$;
%WIDEN%
DO $$ DECLARE v record; BEGIN
  FOR v IN SELECT * FROM _pinned_views LOOP EXECUTE format('CREATE VIEW %s AS %s', v.name, v.def); END LOOP;
END $$;"""

if __name__ == "__main__":
    main(sys.argv[1])
