#!/usr/bin/env bash
# Clear a dirty Processor-Go migration so the processor can start again (issue #28).
# A dirty version N means migration N failed and was rolled back in full, so
# setting the version back to N-1 makes the processor re-run it on next start.
# Fix the cause of the failure first (see: make logs-processor).
#
#   db-force.sh <env-file>
#
# Uses DATABASE_URL from the env file, like db-baseline.sh.
set -euo pipefail

env_file=$1
url=$(grep -E '^DATABASE_URL=' "$env_file" | cut -d= -f2- | sed 's/+asyncpg//')
[ -n "$url" ] || { echo "DATABASE_URL missing in $env_file"; exit 1; }

psql() {
  docker run --rm -i --network host -e DBURL="$url" postgres:18.1-alpine \
    sh -c 'psql "$DBURL" -X -v ON_ERROR_STOP=1 "$@"' psql "$@"
}

echo "Target: ${url#*@}"
row=$(psql -At -F ' ' -c "select version, dirty from public.schema_migrations" </dev/null 2>/dev/null) || {
  echo "No schema_migrations table: Processor-Go has never run migrations here. Nothing to clear."; exit 0; }
read -r version dirty <<<"$row"
echo "schema_migrations: version=${version:-none} dirty=${dirty:-n/a}"
[ "$dirty" = t ] || { echo "Not dirty. Nothing to clear."; exit 0; }

prev=$((version - 1))
read -rp "Migration $version failed. Cause fixed? Set version to $prev, dirty false, so it re-runs on next start? [y/N] " answer
[ "$answer" = y ] || { echo "Aborted"; exit 1; }
if [ "$prev" -lt 1 ]; then
  psql -qc "delete from public.schema_migrations"  # first migration failed: no version applied
else
  psql -qc "update public.schema_migrations set version = $prev, dirty = false"
fi
echo "Cleared. Restart the processor: docker compose --env-file configs/single-host.env restart telemetry-processor"
