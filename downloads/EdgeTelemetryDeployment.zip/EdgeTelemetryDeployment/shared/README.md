# Shared Scripts

Utility scripts for setting up TLS certificates, JWT keys, and development hooks. Used by the **segmented** deployment (DMZ + bank). The single-host deployment does not need these.

## Scripts

### `generate-ca.sh`

Creates a self-signed Certificate Authority (CA) for Kafka mTLS.

```bash
./scripts/generate-ca.sh --output-dir ./ca --validity-days 3650
```

Outputs: `ca-cert.pem`, `ca-key.pem`

### `issue-kafka-server-cert.sh`

Issues a Kafka server certificate signed by the CA. Creates JKS keystores for the DMZ Kafka broker.

```bash
./scripts/issue-kafka-server-cert.sh \
  --ca-cert ./ca/ca-cert.pem \
  --ca-key ./ca/ca-key.pem \
  --fqdn kafka.dmz.example.com \
  --output-dir ../deployments/segmented/dmz/secrets/kafka-tls
```

Outputs: `kafka.server.keystore.jks`, `kafka.server.truststore.jks`

### `issue-kafka-client-cert.sh`

Issues a Kafka client certificate signed by the CA. Creates JKS keystores for the bank-side processor.

```bash
./scripts/issue-kafka-client-cert.sh \
  --ca-cert ./ca/ca-cert.pem \
  --ca-key ./ca/ca-key.pem \
  --client-name bank-processor \
  --output-dir ../deployments/segmented/bank/secrets/kafka-tls
```

Outputs: `client.keystore.jks`, `client.truststore.jks`

### `generate-jwt-keypair.sh`

Generates an RS256 keypair for JWT authentication.

```bash
./scripts/generate-jwt-keypair.sh --output-dir ./jwt-keys
```

Outputs: `private.pem`, `public.pem`

After generation:
- Copy `public.pem` to `deployments/segmented/dmz/secrets/jwt-public-keys/`
- Copy both files to `deployments/segmented/bank/secrets/jwt-signing-keys/`

### `verify-key-fingerprint.sh`

Compares SHA-256 fingerprints of key files to verify they match across deployments.

```bash
# Print fingerprint of a single key
./scripts/verify-key-fingerprint.sh deployments/segmented/dmz/secrets/jwt-public-keys/public.pem

# Compare two keys
./scripts/verify-key-fingerprint.sh \
  deployments/segmented/dmz/secrets/jwt-public-keys/public.pem \
  deployments/segmented/bank/secrets/jwt-signing-keys/public.pem
```

### `install-pre-commit-hook.sh`

Installs a git pre-commit hook that prevents accidental commit of `.pem`, `.key`, `.p12`, or `.jks` files.

```bash
./scripts/install-pre-commit-hook.sh
```

## End-to-End Setup Walkthrough

Complete setup for the segmented (DMZ + bank) deployment:

```bash
cd shared

# 1. Generate CA
./scripts/generate-ca.sh --output-dir /tmp/edge-ca

# 2. Issue Kafka server cert for DMZ
./scripts/issue-kafka-server-cert.sh \
  --ca-cert /tmp/edge-ca/ca-cert.pem \
  --ca-key /tmp/edge-ca/ca-key.pem \
  --fqdn kafka.dmz.yourcompany.com \
  --output-dir ../deployments/segmented/dmz/secrets/kafka-tls

# 3. Issue Kafka client cert for bank processor
./scripts/issue-kafka-client-cert.sh \
  --ca-cert /tmp/edge-ca/ca-cert.pem \
  --ca-key /tmp/edge-ca/ca-key.pem \
  --client-name bank-processor \
  --output-dir ../deployments/segmented/bank/secrets/kafka-tls

# 4. Generate JWT keypair
./scripts/generate-jwt-keypair.sh --output-dir /tmp/edge-jwt

# 5. Distribute JWT keys
cp /tmp/edge-jwt/public.pem ../deployments/segmented/dmz/secrets/jwt-public-keys/
cp /tmp/edge-jwt/private.pem ../deployments/segmented/bank/secrets/jwt-signing-keys/
cp /tmp/edge-jwt/public.pem ../deployments/segmented/bank/secrets/jwt-signing-keys/

# 6. Verify keys match
./scripts/verify-key-fingerprint.sh \
  ../deployments/segmented/dmz/secrets/jwt-public-keys/public.pem \
  ../deployments/segmented/bank/secrets/jwt-signing-keys/public.pem

# 7. Clean up CA private key (store securely offline)
echo "Store /tmp/edge-ca/ca-key.pem securely. It's needed to issue new client certs."

# 8. Install pre-commit hook
./scripts/install-pre-commit-hook.sh

# 9. Deploy DMZ (on DMZ server)
cd ../deployments/segmented/dmz
# Edit .env and configs/dmz.env
make deploy

# 10. Deploy Bank (on bank server)
cd ../bank
# Edit .env and configs/bank.env
make deploy
```
