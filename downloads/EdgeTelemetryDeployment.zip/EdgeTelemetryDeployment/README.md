# EdgeTelemetry Deployment

Production deployment for the EdgeTelemetry pipeline (Collector → Kafka → Processor → PostgreSQL, with a Redis-backed RUM analytics API).

There are **two supported deployments**:

| Deployment | When to use | Auth |
|------------|-------------|------|
| **single-host** | Dev, staging, or any environment without a network-segmentation requirement. Everything on one box. | None (collector is open — sit it behind a trusted boundary) |
| **segmented** | Production with a DMZ/internal split. Collector and Kafka live in the DMZ; Processor, Redis, and the analytics API live in the bank network. The two zones talk over Kafka:9093 with mTLS. | RS256 JWT (DMZ has the public key, bank holds the private key) |

```
deployments/
├── single-host/                # Deployment 1: everything on one host
└── segmented/                  # Deployment 2: DMZ + Bank
    ├── dmz/                    #   Internet-facing (Collector + Kafka)
    └── bank/                   #   Internal (Processor + RUM API + Redis)
```

## Quick start

### Single-host

```bash
cd deployments/single-host
cp configs/single-host.env.example configs/single-host.env   # set DATABASE_URL
make deploy
```

See [`deployments/single-host/README.md`](deployments/single-host/README.md).

### Segmented

Provision the keys once (CA, Kafka mTLS server+client certs, JWT keypair) — see [`shared/README.md`](shared/README.md) for the end-to-end walkthrough.

Then on each host:

```bash
# DMZ host
cd deployments/segmented/dmz
cp configs/dmz.env.example configs/dmz.env       # tweak FQDN / rate limits
cp .env.example .env                             # set keystore passwords
make deploy

# Bank host
cd deployments/segmented/bank
cp configs/bank.env.example configs/bank.env     # set DATABASE_URL, DMZ FQDN
cp .env.example .env                             # set keystore passwords
make deploy
```

See [`deployments/segmented/dmz/README.md`](deployments/segmented/dmz/README.md) and [`deployments/segmented/bank/README.md`](deployments/segmented/bank/README.md).

## Architecture

```
single-host                        segmented (production)
─────────────                      ────────────────────────────────────────────────────
                                       DMZ                  Bank network
Client → Collector                 Client → Collector
            ↓                                  ↓
          Kafka                              Kafka  ──── mTLS :9093 ────→  Processor → DB
            ↓                                                                  ↓
        Processor → DB                                                       Redis ← RUM API
            ↓
        Redis ← RUM API
```

| Component | Port | Single-host | Segmented |
|-----------|------|-------------|-----------|
| Collector | 8001 | ✓ | DMZ |
| Processor | 8002 | ✓ | Bank |
| RUM Analytics API | 8003 | ✓ | Bank |
| Redis | 6379 | ✓ | Bank |
| Kafka (internal) | 29092 | ✓ | DMZ |
| Kafka (mTLS, external) | 9093 | — | DMZ |
| Kafka UI | 8080 | ✓ | DMZ |
| Zookeeper | 2181 | ✓ | DMZ |

## Security

- **JWT** — RS256, segmented mode only. Bank holds private key (signs); DMZ holds public key (verifies).
- **Kafka mTLS** — required between DMZ Kafka (port 9093) and the bank-side processor; both sides issued from a shared private CA.
- **Secrets** — never committed. `.gitignore` blocks `*.pem`, `*.key`, `*.jks`, `*.p12`, and real `.env` files. Only `.env.example` files are tracked. A pre-commit hook (`shared/scripts/install-pre-commit-hook.sh`) backs this up.

Generate everything via `shared/scripts/` — see [`shared/README.md`](shared/README.md).

## Local development

If you're iterating on a service's source (sibling dirs `../EdgeTelemetryCollector`, `../EdgeTelemetryProcessor`, `../EdgeTelemetryRumAnalytics`, etc.), the root `docker-compose.yml` builds those services from source.

```bash
cp .env.dev.example .env.dev    # then edit DATABASE_URL
make up-build                   # build + start dev stack
make logs                       # tail
make down                       # stop
```

This is **not** a deployment mode — it's a local build/run convenience. For production-shaped runs, use the `deployments/` Makefiles.

## Root Makefile shortcuts

```bash
make list-deployments    # Show available deployments
make deploy-single-host  # Forward to deployments/single-host
make deploy-dmz          # Forward to deployments/segmented/dmz
make deploy-bank         # Forward to deployments/segmented/bank
```

## System requirements

- Docker 27.5+ and Docker Compose v2
- 4 GB RAM minimum (single-host); per-host requirements similar for segmented
- 20 GB free disk
- Segmented mode: DNS for the DMZ Kafka FQDN, firewall allowing bank → DMZ:9093

## Support

Each deployment has its own README with troubleshooting, health checks, and command reference. For shared scripts (CA / TLS / JWT setup), see [`shared/README.md`](shared/README.md).
