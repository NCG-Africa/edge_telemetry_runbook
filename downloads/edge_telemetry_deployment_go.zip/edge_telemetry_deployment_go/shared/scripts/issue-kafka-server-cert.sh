#!/bin/bash
# Issue Kafka server certificate and create JKS keystores for DMZ deployment
# Usage: ./issue-kafka-server-cert.sh --ca-cert ./ca/ca-cert.pem --ca-key ./ca/ca-key.pem --fqdn kafka.dmz.example.com --output-dir ./dmz-certs

set -euo pipefail

CA_CERT=""
CA_KEY=""
FQDN=""
OUTPUT_DIR="./kafka-server-certs"
KEYSTORE_PASS=""
VALIDITY_DAYS=365

while [[ $# -gt 0 ]]; do
    case $1 in
        --ca-cert) CA_CERT="$2"; shift 2 ;;
        --ca-key) CA_KEY="$2"; shift 2 ;;
        --fqdn) FQDN="$2"; shift 2 ;;
        --output-dir) OUTPUT_DIR="$2"; shift 2 ;;
        --keystore-pass) KEYSTORE_PASS="$2"; shift 2 ;;
        --validity-days) VALIDITY_DAYS="$2"; shift 2 ;;
        -h|--help)
            echo "Usage: $0 [OPTIONS]"
            echo ""
            echo "Required:"
            echo "  --ca-cert FILE         CA certificate PEM file"
            echo "  --ca-key FILE          CA private key PEM file"
            echo "  --fqdn HOSTNAME        Kafka server FQDN (e.g., kafka.dmz.example.com)"
            echo "  --keystore-pass PASS   Keystore password — no default, by design."
            echo "                         Generate one with: openssl rand -base64 24"
            echo ""
            echo "Optional:"
            echo "  --output-dir DIR       Output directory (default: ./kafka-server-certs)"
            echo "  --validity-days DAYS   Certificate validity (default: 365)"
            exit 0
            ;;
        *) echo "Unknown option: $1"; exit 1 ;;
    esac
done

if [[ -z "$CA_CERT" || -z "$CA_KEY" || -z "$FQDN" ]]; then
    echo "ERROR: --ca-cert, --ca-key, and --fqdn are required"
    exit 1
fi

# No default keystore password. A documented default is a real credential — the
# old "changeit" shipped straight into the DMZ compose file.
if [[ -z "$KEYSTORE_PASS" ]]; then
    echo "ERROR: --keystore-pass is required (no default)"
    echo "       Generate one with: openssl rand -base64 24"
    exit 1
fi

mkdir -p "$OUTPUT_DIR"
WORK_DIR=$(mktemp -d)
trap 'rm -rf "$WORK_DIR"' EXIT

echo "Issuing Kafka server certificate..."
echo "  FQDN: $FQDN"
echo "  CA cert: $CA_CERT"
echo "  Output: $OUTPUT_DIR"

# Step 1: Generate server keystore with keypair
echo "[1/5] Generating server keystore..."
keytool -genkey -noprompt \
    -alias kafka-server \
    -dname "CN=$FQDN,O=EdgeTelemetry,OU=DMZ" \
    -keystore "$OUTPUT_DIR/kafka.server.keystore.jks" \
    -keyalg RSA \
    -keysize 2048 \
    -validity "$VALIDITY_DAYS" \
    -storepass "$KEYSTORE_PASS" \
    -keypass "$KEYSTORE_PASS" \
    -ext "SAN=DNS:$FQDN,DNS:kafka,DNS:localhost"

# Step 2: Generate CSR from keystore
echo "[2/5] Generating certificate signing request..."
keytool -certreq \
    -alias kafka-server \
    -keystore "$OUTPUT_DIR/kafka.server.keystore.jks" \
    -file "$WORK_DIR/server.csr" \
    -storepass "$KEYSTORE_PASS" \
    -keypass "$KEYSTORE_PASS" \
    -ext "SAN=DNS:$FQDN,DNS:kafka,DNS:localhost"

# Step 3: Sign the CSR with the CA
echo "[3/5] Signing certificate with CA..."
openssl x509 -req \
    -in "$WORK_DIR/server.csr" \
    -CA "$CA_CERT" \
    -CAkey "$CA_KEY" \
    -CAcreateserial \
    -out "$WORK_DIR/server-signed.pem" \
    -days "$VALIDITY_DAYS" \
    -extensions v3_req \
    -extfile <(cat <<EOF
[v3_req]
subjectAltName = DNS:$FQDN,DNS:kafka,DNS:localhost
EOF
)

# Step 4: Import CA cert and signed cert into keystore
echo "[4/5] Importing certificates into keystore..."
keytool -import -noprompt \
    -alias ca-root \
    -file "$CA_CERT" \
    -keystore "$OUTPUT_DIR/kafka.server.keystore.jks" \
    -storepass "$KEYSTORE_PASS"

keytool -import -noprompt \
    -alias kafka-server \
    -file "$WORK_DIR/server-signed.pem" \
    -keystore "$OUTPUT_DIR/kafka.server.keystore.jks" \
    -storepass "$KEYSTORE_PASS" \
    -keypass "$KEYSTORE_PASS"

# Step 5: Create truststore with CA cert
echo "[5/5] Creating truststore..."
keytool -import -noprompt \
    -alias ca-root \
    -file "$CA_CERT" \
    -keystore "$OUTPUT_DIR/kafka.server.truststore.jks" \
    -storepass "$KEYSTORE_PASS"

# The keystore holds the server private key.
chmod 600 "$OUTPUT_DIR/kafka.server.keystore.jks"
chmod 644 "$OUTPUT_DIR/kafka.server.truststore.jks"

# confluentinc/cp-kafka runs as uid 1000 (appuser), so a 600 keystore owned by
# the deploy user is unreadable inside the broker container.
if ! chown 1000:1000 "$OUTPUT_DIR/kafka.server.keystore.jks" 2>/dev/null; then
    echo "NOTE: could not chown the keystore to uid 1000 (the cp-kafka appuser)."
    echo "      The broker will fail to read it. Run:"
    echo "        sudo chown 1000:1000 $OUTPUT_DIR/kafka.server.keystore.jks"
fi

echo ""
echo "Kafka server certificates generated:"
echo "  Keystore:   $OUTPUT_DIR/kafka.server.keystore.jks  (600 permissions)"
echo "  Truststore: $OUTPUT_DIR/kafka.server.truststore.jks"
echo ""
echo "Copy these to: deployments/segmented/dmz/secrets/kafka-tls/"
echo "Set these in deployments/segmented/dmz/configs/dmz.env to the value you"
echo "passed as --keystore-pass (deliberately not echoed here — it would land in"
echo "terminal scrollback and any CI log):"
echo "  KAFKA_KEYSTORE_PASSWORD="
echo "  KAFKA_KEY_PASSWORD="
echo "  KAFKA_TRUSTSTORE_PASSWORD="
