# Secure the Kafka UI — Design

**Date:** 2026-09-08
**Status:** Shipped 2026-09-08 (commits f5cc29b, f757212 on `main`; deployed to the
app server). Kafka UI + follow-up #1 (sibling ports) both done. Follow-ups #2–#5 open.
See **Amendments** below for post-ship changes to the access path.
**Scope:** Kafka UI only, thorough. Sibling-service port exposure is flagged as
follow-up, not designed here.
**Repos touched:** `EdgeTelemetryDeploymentGo` only. The Python `EdgeTelemetryDeployment`
repo is retired (not deployed anywhere) and is out of scope.
**Production target:** `deployments/single-host/docker-compose.yml` is the only
live deployment. The segmented `dmz/bank` topology is not deployed; its compose
gets the same edits for consistency but no separate verification.

---

## Problem

`docker ps` on the production app server (`102.164.37.226`, public IP, **no host
firewall** — service ports are open to the internet) shows `telemetry-go-kafka-ui`
alongside `telemetry-go-kafka` and `telemetry-go-zookeeper`.

The Kafka UI service is defined identically in three compose files:

| File | Cluster name | Port line |
|---|---|---|
| `deployments/single-host/docker-compose.yml:179` | `telemetry-go-production` | `"8090:8080"` |
| `deployments/segmented/dmz/docker-compose.yml:106` | `telemetry-go-dmz` | `"8090:8080"` |
| `docker-compose.yml` (root, local dev) | `development-go` | `"8090:8080"` |

Every one of them:

- runs **`provectuslabs/kafka-ui:latest`**
- sets **no** `AUTH_TYPE` / `SPRING_SECURITY_*` — the UI never asks who you are
- sets **no** `KAFKA_CLUSTERS_0_READONLY` — the UI can produce, delete topics and
  records, reset consumer offsets, and edit broker/topic config
- publishes the container port with **no bind address**, so Docker forwards
  `0.0.0.0:8090` on the host

### Impact

`http://102.164.37.226:8090` is an unauthenticated, write-capable control plane
for the telemetry Kafka cluster, reachable from anywhere. An anonymous visitor
can:

- read every telemetry message flowing through `telemetry-upsert` (device IDs,
  IPs, app/session data)
- produce forged telemetry into the pipeline
- delete topics/records or reset the processor's consumer group offsets
  (data loss / reprocessing storm)
- read broker and topic configuration

### Additional risk: the image is abandoned

`provectuslabs/kafka-ui` development was paused by Provectus in late 2023. The
project was forked to **`kafbat/kafka-ui`** by the maintainer community
specifically because Provectus left security issues unpatched, including a
SpEL expression-evaluation RCE. `:latest` on the Provectus image is therefore
both unauthenticated **and** an unmaintained Spring Boot app with known
unpatched CVEs, on a public port.

### Why a firewall rule is not the fix

Docker's port publishing inserts its own `iptables` rules in the `DOCKER` chain,
which are evaluated **before** `ufw`'s `INPUT` rules. `ufw deny 8090` on a Docker
host silently has no effect on a published container port. Any fix has to act at
the Docker layer (bind address) or at a layer Docker doesn't bypass (loopback,
a separate network namespace, cloud security group).

---

## Access requirements (from stakeholder)

- **Who:** 1–2 operators, all of whom already hold SSH to the host (`-p 2222`).
- **Frequency:** occasional — consumer-lag checks, topic inspection during
  incidents (`docs/07-deployment.md` "is data flowing?" runbook).
- **No** always-on public URL is needed. SSH-tunnel friction is acceptable.

---

## Approaches considered

### A. Unpublish the port + SSH tunnel + in-container hardening — **CHOSEN**

Remove the public binding; operators reach the UI through an SSH local-forward
over the connection they already use. Layer on: maintained image, read-only
cluster, and a login password.

- **Pros:** removes the public surface entirely; no new component to run or
  patch; matches the actual (occasional, SSH-holding) access pattern; defence in
  depth so any single mistake still isn't an exposure.
- **Cons:** operators must remember one `ssh -L` command; no shareable URL.

### B. Public reverse proxy with basic-auth + TLS

Add Caddy/nginx (none exists in the stack today), terminate TLS, basic-auth in
front, proxy to an unpublished kafka-ui.

- **Pros:** shareable URL; familiar pattern.
- **Cons:** introduces a new internet-facing component to configure and keep
  patched; the abandoned kafka-ui app is still reachable (behind one password)
  from the internet; DNS record + cert management overhead; disproportionate for
  1–2 occasional users.

### C. WireGuard admin network

Put a VPN on the host; bind all internal admin surfaces to the VPN interface;
firewall the public interface down to SSH + collector ingest.

- **Pros:** correct long-term end state; fixes every admin surface at once.
- **Cons:** host-level networking change touching every service — this is the
  "full host port audit" scope that was explicitly declined for this workstream.
  Recorded as a follow-up.

---

## Design (Approach A)

Four changes to the kafka-ui service block, applied to
**`deployments/single-host/docker-compose.yml`** (production) and
**`deployments/segmented/dmz/docker-compose.yml`**. The root `docker-compose.yml`
(local dev) gets the image pin and read-only change but keeps its published port
(dev convenience, not internet-facing).

### Change 1 — Bind the published port to loopback

```yaml
    ports:
      - "127.0.0.1:8090:8080"     # was: "8090:8080"
```

The container port becomes reachable only from the host itself. Docker's
`iptables` rules honour the bind address, so this holds regardless of `ufw`
state. `http://102.164.37.226:8090` stops responding.

### Change 2 — Replace the abandoned image with a pinned maintained one

```yaml
    image: ghcr.io/kafbat/kafka-ui:v1.1.0   # was: provectuslabs/kafka-ui:latest
```

`kafbat/kafka-ui` is the community continuation of the same codebase — identical
configuration schema and UI, active security patching. Pinned to a fixed tag so
`docker compose pull` / `make update` cannot silently move it.

> Implementation note: confirm the latest stable `kafbat/kafka-ui` tag at build
> time and pin to it (and ideally its digest). `v1.1.0` is the placeholder in
> this design.

### Change 3 — Read-only cluster

```yaml
    environment:
      KAFKA_CLUSTERS_0_NAME: telemetry-go-production   # unchanged
      KAFKA_CLUSTERS_0_BOOTSTRAPSERVERS: kafka:29092    # unchanged
      KAFKA_CLUSTERS_0_ZOOKEEPER: zookeeper:2181        # unchanged
      KAFKA_CLUSTERS_0_READONLY: "true"                 # new
```

Disables, from the UI: message production, topic creation/deletion, record
deletion, consumer-group offset resets, and config edits. Topic browsing,
message viewing, and consumer-lag inspection — the actual operational use —
are unaffected.

Kafka itself runs `PLAINTEXT` with no ACLs, so a genuinely read-only Kafka
*principal* is not possible without introducing broker auth (out of scope).
`READONLY: "true"` is the UI-level equivalent and the best available control
here.

### Change 4 — Login-form password (second layer)

```yaml
    environment:
      # ...cluster vars above...
      AUTH_TYPE: LOGIN_FORM
      SPRING_SECURITY_USER_NAME: admin
      SPRING_SECURITY_USER_PASSWORD: ${KAFKA_UI_PASSWORD:?KAFKA_UI_PASSWORD must be set in configs/<env>.env}
    env_file:
      - ./configs/single-host.env      # dmz: ./configs/dmz.env
```

- kafka-ui currently has **no** `env_file`; add it so the service reads the same
  config file as its siblings and Compose can interpolate `${KAFKA_UI_PASSWORD}`.
- `configs/single-host.env.example` and `configs/dmz.env.example` gain a new
  commented block:

  ```bash
  # ===== Kafka UI =====
  # Login password for the Kafka UI (user: admin). Reachable only via SSH tunnel;
  # this is a second layer so host access alone does not grant UI access.
  # Generate: openssl rand -base64 24
  KAFKA_UI_PASSWORD=
  ```

- The real value goes in the gitignored `configs/single-host.env` /
  `configs/dmz.env`. The `:?` guard makes the deploy fail fast with a clear
  message if it is missing.
- kafbat basic auth supports exactly one local user and is incompatible with
  RBAC/OAuth — acceptable for this access model.

### Change 5 — Access runbook, Makefile, README

**Operator access path** (replaces "open `http://<host>:8090`"):

```bash
# From the operator's laptop
ssh -p 2222 -L 8090:localhost:8090 jonathan@102.164.37.226
# then open http://localhost:8090 in a local browser, log in as admin
```

- `deployments/single-host/Makefile` — the `deploy` and `deploy-rhel` closing
  banners (`Makefile:84`, `Makefile:332`) print
  `Kafka UI:  http://localhost:8090`. Replace with the tunnel one-liner and a
  note that the UI is not publicly reachable by design.
- `deployments/single-host/README.md` and
  `deployments/segmented/dmz/README.md` — same substitution wherever the
  `:8090` URL appears.
- `docs/07-deployment.md` (in the platform docs repo, `docs/07-deployment.md`)
  step 2 of the "is data flowing?" runbook references
  "Kafka UI on :8080" — update to the tunnel instruction. (Cross-repo; note in
  the plan, may be a separate small PR.)

---

## Amendments

**2026-09-09 — public nginx path replaces the SSH tunnel.** Change 5's
tunnel-only access (`ssh -L 8090:…`) was superseded by an nginx reverse-proxy
vhost on the host: `https://telemetry.ncgafrica.com/kafka-ui/` (TLS via Certbot,
`SERVER_SERVLET_CONTEXT_PATH: /kafka-ui` so the app builds correct URLs under the
sub-path — compose commit `40a3e38`). The loopback port bind (`127.0.0.1:8090`)
is unchanged; nginx is the only client.

**2026-09-09 — nginx basic-auth layer removed.** The `/kafka-ui/` location
briefly carried an `auth_basic` htpasswd gate in front of Kafka-UI's own
`LOGIN_FORM`. That second layer was removed at the owner's request. Access
control is now single-layer: Kafka-UI `LOGIN_FORM` (`admin` +
`SPRING_SECURITY_USER_PASSWORD` from `configs/kafka-ui.env`), plus
`KAFKA_CLUSTERS_0_READONLY: "true"` and TLS. To apply on the host: delete the
`auth_basic` / `auth_basic_user_file` lines from the `location /kafka-ui/` block
in `/etc/nginx/sites-available/telemetry.ncgafrica.com`, then
`sudo nginx -t && sudo systemctl reload nginx`.

---

## Verification

Run after deploy:

| Check | Command | Expected |
|---|---|---|
| Not publicly reachable | from an external host: `curl -sS -m5 http://102.164.37.226:8090` | connection refused / timeout |
| Bound to loopback | on host: `docker compose ps` | `127.0.0.1:8090->8080/tcp` |
| Image swapped | on host: `docker compose images kafka-ui` | `ghcr.io/kafbat/kafka-ui:<pin>` |
| Tunnel works | `ssh -L 8090:localhost:8090 …` then `curl -I localhost:8090` | `200` or redirect to `/login` |
| Auth enforced | through tunnel, browser to `http://localhost:8090` | login form; wrong password rejected |
| Read-only enforced | logged in, try to produce a message to any topic | UI rejects / control disabled |
| Pipeline unaffected | `curl -s localhost:8012/health`; processor logs | healthy; consuming normally |

---

## Rollout

1. Add `KAFKA_UI_PASSWORD` to the real `configs/single-host.env` on the host
   (and `configs/dmz.env` if that topology runs).
2. Apply the compose edits.
3. `docker compose up -d kafka-ui` (or `make update`).
4. Only the kafka-ui container restarts (~30 s). It is **not** in the data path —
   no collector, Kafka, processor, or DB impact.
5. Run the verification table.

Rollback: revert the compose block and `docker compose up -d kafka-ui`. No state
to migrate (kafka-ui is stateless).

---

## Follow-ups (flagged, not designed here)

1. **Sibling ports on `0.0.0.0`** — Redis `6381`, Collector `8011`, Processor
   `8012`, RUM Analytics `8013` are all published without a bind address on the
   same public host. Redis (`6381`, no password in `single-host.env.example`) is
   the next-most-urgent after this. Same loopback treatment, or Approach C.
2. **`:latest` image pins everywhere** — collector/processor/analytics/kafka/
   zookeeper/redis all float on mutable tags; `docs/07-deployment.md` already
   calls this out. Pin all of them.
3. **WireGuard admin network (Approach C)** — proper end state for every admin
   surface; revisit when the host port audit is scheduled.
4. **`dmz` topology** — not currently deployed. If the segmented split is ever
   brought up, reconsider whether kafka-ui belongs in an internet-facing zone at
   all. The compose gets the same edits now so it is not left as a landmine.
5. **Kafka broker auth / ACLs** — `PLAINTEXT` + no ACLs means no real read-only
   principal is possible; prerequisite for any stronger control than UI-level
   read-only.
