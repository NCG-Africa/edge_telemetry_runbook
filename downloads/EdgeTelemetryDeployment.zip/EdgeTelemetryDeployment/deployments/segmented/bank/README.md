# Bank Deployment Mode

Internal bank network services: Redis + Telemetry Processor + RUM Analytics API. The processor connects to the DMZ Kafka on port 9093 via mutual TLS (mTLS).

## Services

- Redis Cache (port 6379)
- Telemetry Processor (port 8002)
- RUM Analytics API (port 8003)

**Not included:** Zookeeper, Kafka, Collector, Kafka UI (these run in DMZ mode).

## Prerequisites

- Docker 27.5+ and Docker Compose v2
- Access to PostgreSQL database
- Kafka client TLS certificates signed by the same CA as the DMZ Kafka server
- JWT signing keypair (private + public)
- Network connectivity to DMZ Kafka on port 9093
- Firewall rule allowing outbound traffic to DMZ Kafka FQDN:9093

## Security Setup

### Kafka Client TLS (mTLS)

```bash
# Issue client certificate (using the same CA as the DMZ server cert)
../../../shared/scripts/issue-kafka-client-cert.sh \
  --ca-cert /path/to/ca-cert.pem \
  --ca-key /path/to/ca-key.pem \
  --client-name bank-processor \
  --output-dir secrets/kafka-tls
```

Expected files in `secrets/kafka-tls/`:
- `client.keystore.jks` -- client keystore
- `client.truststore.jks` -- truststore (contains CA cert for verifying Kafka server)

### JWT Signing Keys

```bash
# Generate keypair (if not already done)
../../../shared/scripts/generate-jwt-keypair.sh --output-dir secrets/jwt-signing-keys
```

Expected files in `secrets/jwt-signing-keys/`:
- `private.pem` -- RS256 private key (for signing tokens)
- `public.pem` -- RS256 public key (also deployed to DMZ for verification)

**Important:** Copy `public.pem` to the DMZ deployment's `secrets/jwt-public-keys/` directory and verify fingerprints match:
```bash
../../../shared/scripts/verify-key-fingerprint.sh \
  secrets/jwt-signing-keys/public.pem \
  /path/to/dmz/secrets/jwt-public-keys/public.pem
```

## Configuration

1. **Edit `configs/bank.env`** with your database credentials and DMZ Kafka FQDN:
   ```env
   DATABASE_URL=postgresql+asyncpg://user:pass@host:port/dbname
   KAFKA_BOOTSTRAP_SERVERS=kafka.dmz.yourcompany.com:9093
   ```

2. **Edit `.env`** with the DMZ Kafka FQDN and keystore passwords:
   ```env
   DMZ_KAFKA_EXTERNAL_FQDN=kafka.dmz.yourcompany.com
   KAFKA_CLIENT_KEYSTORE_PASSWORD=<your-password>
   KAFKA_CLIENT_TRUSTSTORE_PASSWORD=<your-password>
   ```

## Deploy

```bash
make deploy
```

## Verification

```bash
# Health check (processor + RUM analytics)
make health

# Verify Kafka connectivity to DMZ
make verify-kafka-connection

# Test RUM Analytics API
make test-rum-analytics

# Detailed status with DB/cache checks
make health-detailed
```

## Commands

```bash
make deploy                  # Deploy bank services
make down                    # Stop services
make logs                    # View all logs
make health                  # Quick health check
make health-detailed         # Detailed check with DB/cache status
make verify-kafka-connection # Test connectivity to DMZ Kafka
make test-rum-analytics      # Test RUM Analytics API
make backup                  # Backup Redis data
make restore                 # Restore Redis from backup
make config-check            # Validate configuration and secrets
```

## Service URLs

| Service | URL |
|---------|-----|
| Processor API | http://localhost:8002 |
| RUM Analytics API | http://localhost:8003 |

## Troubleshooting

**Processor can't connect to Kafka?**
- Run `make verify-kafka-connection` to test connectivity
- Verify DMZ Kafka FQDN resolves: `nslookup <FQDN>`
- Verify port 9093 is reachable: `nc -zv <FQDN> 9093`
- Check client certs are in `secrets/kafka-tls/`
- Verify client cert was signed by the same CA as the server cert
- Check processor logs: `make logs-processor`

**Database connection issues?**
- Verify `DATABASE_URL` in `configs/bank.env`
- Ensure PostgreSQL is reachable from the Docker host
- Check processor logs: `make logs-processor | grep -i database`

**RUM Analytics unhealthy?**
- Check Redis: `docker exec telemetry-redis redis-cli ping`
- Check logs: `make logs-rum-analytics`
- The deploy target includes auto-recovery for timing issues
