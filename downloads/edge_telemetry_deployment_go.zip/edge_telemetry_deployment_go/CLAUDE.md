# CLAUDE.md - EdgeTelemetry Deployment (Go)

## Project Overview

EdgeTelemetry Deployment (Go) is a containerized system for collecting and
processing real-time telemetry from mobile/edge applications, using the Go
reimplementations of the collector and processor. The pipeline is:

```
Client → Collector-Go → Kafka → Processor-Go → PostgreSQL
```

Mirrors [`EdgeTelemetryDeployment`](../EdgeTelemetryDeployment) (the Python
deployment repo) — same structure, same Makefile target names, same two
topologies — adapted only where the Go services' capabilities require a
difference. Hard migration: drop-in replacement for the Python stack — same
container names (`telemetry-*`), network (`telemetry-network`) and host ports;
only images differ. Full rationale: `docs/2026-08-17-edge-telemetry-deployment-go-design.md`.

## Deployments

- **single-host** — everything on one host. `AUTH_MODE=api_key`.
- **segmented** — split across two network zones:
  - `segmented/dmz/` — internet-facing: Kafka (dual listener) + kafka-init +
    kafka-lag-watch + Collector-Go + Kafka UI
  - `segmented/bank/` — internal: kafka-topics-wait + Redis + Processor-Go + RUM Analytics Go
  - Cross-zone traffic flows over Kafka:9093 with mTLS, one client cert each
    for the processor (`CN=bank-processor`) and analytics (`CN=bank-analytics`).
    The collector runs `api_key` everywhere: analytics produces keys to
    `rum-api-keys` on the DMZ Kafka, the collector holds them in memory and
    reports `/ready` once caught up. No broker ACLs (known limit, upgrade path
    in `shared/README.md`). Deploy the DMZ first.
- **Lag alert** — `kafka-lag-watch` (root, single-host, DMZ) logs
  `WARN kafka_lag_high lag=<n>` every 5 min over `LAG_ALERT_MESSAGES`.

## Architecture

| Component | Port | Purpose |
|-----------|------|---------|
| Collector-Go | 8001 → 8000 | REST API for telemetry ingestion |
| Processor-Go | 8002 → 8000 | Kafka consumer; writes to PostgreSQL |
| RUM Analytics Go | 8003 → 8013 | Dashboard API (single-host + bank) |
| Kafka (internal) | 29092 | Plaintext, in-cluster |
| Kafka (mTLS) | 9093 | External SSL (segmented mode only) |
| Zookeeper | 2181 | Kafka coordination |
| Redis | not published (6379 in-cluster, `requirepass`) | API-key cache, rate limits, RUM cache (single-host + bank) |
| Kafka UI | 8080 (loopback, login) | Kafka monitoring |

## Tech Stack

- **Backend:** Go 1.22 (Collector-Go: Echo; Processor-Go: net/http via Echo)
- **Message broker:** Apache Kafka 7.4.0 + Zookeeper
- **Kafka client:** `segmentio/kafka-go`
- **Database:** PostgreSQL, external, never bundled
- **Cache:** Redis 7-alpine (single-host + bank)
- **Containerization:** Docker + Docker Compose
- **Automation:** Make, Bash

## Repository Structure

```
├── deployments/
│   ├── single-host/
│   │   ├── docker-compose.yml
│   │   ├── Makefile
│   │   └── configs/{single-host,kafka-ui}.env(.example)
│   └── segmented/
│       ├── dmz/
│       │   ├── docker-compose.yml
│       │   ├── Makefile
│       │   ├── configs/dmz.env(.example)
│       │   └── secrets/kafka-tls
│       └── bank/
│           ├── docker-compose.yml
│           ├── Makefile
│           ├── configs/bank.env(.example)
│           └── secrets/{kafka-tls, kafka-tls-analytics}
├── shared/
│   ├── scripts/        # CA / TLS / Kafka topic + lag / pre-commit hook
│   └── README.md
├── docker-compose.yml   # Local-dev: builds from sibling source dirs
├── Makefile             # Dev targets + deployment delegation
├── getstarted.sh        # Ubuntu host bootstrap
├── .github/workflows/validate.yml
└── .gitignore
```

Source code for individual services lives in sibling directories (used by the
root `docker-compose.yml` for local dev):
- `../edge_telemetry_collector_go`
- `../edge_telemetry_processor_go`

## Common Commands

```bash
# From repo root
make list-deployments
make deploy-single-host
make deploy-dmz
make deploy-bank

# Local dev
make up-build
make logs
make down

# Inside any deployment dir
make deploy
make down
make health
make config-check
```

## Security hardening (post Sep 3 2026 breach — map issue #2)

All host ports bind `127.0.0.1` except DMZ Kafka 9093. Every container is
`read_only` + `no-new-privileges`; the three `papijo/*` images and the bank `kafka-topics-wait`
(reads the 600 client key) run as `65534:65534`. Exception: the Kafka broker's `/tmp` tmpfs is `exec` (topic
`compression.type=zstd` makes it load zstd-jni's native lib from there).
First-party images pinned by digest, third-party by exact tag (CI
`image-pins` job enforces). Redis requires `REDIS_PASSWORD`.

## Configuration

Each deployment owns its own env file. Note Processor-Go has **no
`DATABASE_URL`** support — it only reads discrete `POSTGRES_HOST` /
`POSTGRES_PORT` / `POSTGRES_DATABASE` / `POSTGRES_USER` / `POSTGRES_PASSWORD` /
`POSTGRES_SSLMODE`. Collector-Go reads no database: its API keys come from `rum-api-keys`.

Real env files are gitignored — only `.env.example` files are committed.

## Security Scripts

Located in `shared/scripts/`:
- `generate-ca.sh` — private CA for Kafka mTLS (unchanged from Python)
- `issue-kafka-server-cert.sh` — Kafka server cert, JKS (DMZ, unchanged from Python)
- `issue-kafka-client-cert.sh` — Kafka client cert, **PEM** (bank processor and analytics — rewritten for Go's `crypto/tls`)
- `kafka-init.sh` — one-shot topic setup run by the `kafka-init` service (single-host, DMZ, dev)
- `kafka-topics-wait.sh` — bank one-shot gate: waits over mTLS for the DMZ topics
- `kafka-mtls-config.sh` — builds a Kafka CLI `--command-config` from the PEM client cert
- `kafka-lag.sh` — consumer-group lag per partition (`make kafka-lag`, `make update` drain)
- `kafka-lag-watch.sh` — the `kafka-lag-watch` service loop (`LAG_ALERT_MESSAGES`)
- `install-pre-commit-hook.sh` — installs hook blocking `*.pem`/`*.jks`/etc.

## Prerequisite Code Changes (not in this repo)

- `edge_telemetry_collector_go`: in-memory API-key map from `rum-api-keys`
  and `/ready` (collector#5). `AUTH_MODE=jwt` is gone.
- `EdgeTelemetryRUMAnalyticsGo`: `rum-api-keys` producer (`KAFKA_*` env, mTLS).
- `EdgeTelemetryProcessorGo`: Kafka mTLS client support added
  (`internal/config/config.go`, `internal/kafka/consumer.go`) — new
  `KAFKA_SECURITY_PROTOCOL` / `KAFKA_TLS_CA_CERT` / `KAFKA_TLS_CLIENT_CERT` /
  `KAFKA_TLS_CLIENT_KEY` env vars, `PLAINTEXT` default.

## Database

PostgreSQL `edge_db`, same schema as the Python deployment (`rum_api_keys`,
`rum_apps`, `rum_devices`, `rum_users`, `rum_sessions`) — this repo doesn't
change the schema, only which services connect to it.

## GitHub

Repository: (set once created — not yet pushed)

## Agent skills

### Issue tracker

GitHub Issues on `NCG-Africa/edge_telemetry_deployment_go` via `gh`; external PRs not a triage surface. See `docs/agents/issue-tracker.md`.

### Triage labels

Default vocabulary: `needs-triage`, `needs-info`, `ready-for-agent`, `ready-for-human`, `wontfix`. See `docs/agents/triage-labels.md`.

### Domain docs

Single-context: root `CONTEXT.md` + `docs/adr/` (created lazily). See `docs/agents/domain.md`.
