# shellcheck shell=bash
# X6: after `make update` from a pre-effort install with unconsumed traffic queued on SDKs, no
# events are lost or duplicated: partition 0's offset is preserved and partitions 1-11 start at
# earliest (U3, U4, P2). Disposable host only: it runs `make update` on the live install.
# Starts on the pre-effort install (1-partition telemetry-upsert); see README "Acceptance run".
X6_N=4 X6_M=8
x6() {
  local i c0 e0 before after pid rc queued=() body ok=0 update_log=backups/acceptance-$RUN_ID-update.log
  legacy_key x6 || return 1

  # N batches queued in partition 0 while the processor is paused. Container names, not
  # "${DC[@]}": the running containers came from the pre-effort compose file.
  docker stop telemetry-processor >/dev/null || { log "    FAIL stop processor"; return 1; }
  for i in $(seq 1 "$X6_N"); do
    post_batch x6 /telemetry "$(x6_batch "n$i")" || { docker start telemetry-processor >/dev/null; return 1; }
  done
  check "telemetry-upsert partitions before the update (pre-effort)" 1 "$(x6_partitions)" \
    || { docker start telemetry-processor >/dev/null; return 1; }
  c0=$(committed 0) e0=$(ends | awk '$1 == 0 {print $2}')
  log "    snapshot partition 0: committed ${c0:--} end $e0"
  docker start telemetry-processor >/dev/null || { log "    FAIL start processor"; return 1; }

  # make update; M batches posted while the collector is down stand in for SDK offline queues.
  # The drain lets the old processor consume the N batches; its committed offset is what
  # partition 0 must keep. Output is masked into update_log once make update is done.
  make update > "$TMPD/update.log" 2>&1 &
  pid=$!
  if ! wait_for "make update to stop the collector" 300 x6_collector_down; then
    wait "$pid"; x6_update_log; return 1
  fi
  for i in $(seq 1 "$X6_M"); do
    body=$(x6_batch "m$i")
    collect x6 /telemetry "$body"
    [ "$HTTP_CODE" = 200 ] && { log "    FAIL batch m$i accepted while the collector should be down"; ok=1; continue; }
    queued+=("$body")
  done
  log "    queued ${#queued[@]} batches while the collector was down (last answer: ${HTTP_CODE:-none})"
  wait "$pid"; rc=$?
  if [ "$rc" != 0 ]; then log "    FAIL make update exited $rc:"; x6_update_log; return 1; fi
  mask < "$TMPD/update.log" > "$update_log"
  before=$(sed -n 's/^update: offsets before -> //p' "$update_log") after=${before%-before.txt}-after.txt

  # The SDKs retry their queues once the collector is back. The processor is held stopped so
  # the batches sit on partitions 1-11 before its next assignment: only an earliest reset reads
  # them (a latest reset would skip them and the drain below times out). No App is registered
  # for the package: the pre-effort processor created it and the analytics migration kept it.
  wait_for "collector to load key x6 after the update" 120 key_known x6 || return 1
  docker stop telemetry-processor >/dev/null || { log "    FAIL stop processor"; return 1; }
  for body in "${queued[@]}"; do post_batch x6 /telemetry "$body" || { docker start telemetry-processor >/dev/null; return 1; }; done
  check "queued batches on partitions 1-11, none committed there" "yes -" \
    "$([ "$(ends | awk '$1 > 0 {s += $2} END {print s + 0}')" -gt 0 ] && echo yes || echo no) $(make -s kafka-lag 2>/dev/null \
       | awk '$1 == "partition" && $2 > 0 {print $4}' | sort -u | paste -sd' ' -)" || ok=1
  docker start telemetry-processor >/dev/null || { log "    FAIL start processor"; return 1; }
  wait_for "processor to read partitions 1-11 from earliest" 120 lag_zero || return 1

  check "telemetry-upsert partitions after the update" 12 "$(x6_partitions)" || ok=1
  check "partition 0 committed: $before vs $after" "$(x6_p0_committed "$before")" "$(x6_p0_committed "$after")" || ok=1
  check "partition 0 committed >= snapshot end $e0" yes "$([ "$(committed 0)" -ge "$e0" ] && echo yes || echo no)" || ok=1
  check "partitions 1-11 earliest offset" "0 0 0 0 0 0 0 0 0 0 0" \
    "$("${DC[@]}" exec -T kafka kafka-get-offsets --bootstrap-server localhost:29092 --topic "$TOPIC" --time -2 \
       | awk -F: '$2 > 0 {print $3}' | paste -sd' ' -)" || ok=1
  check "rum_telemetry_events for the run's X6 devices (2 per batch)" $(( 2 * (X6_N + X6_M) )) \
    "$(q "SELECT count(*) FROM rum_telemetry_events e JOIN rum_sessions s ON s.id = e.session_id
           JOIN rum_devices d ON d.id = s.device_id WHERE d.device_id LIKE '$DEV_PREFIX-x6-%'")" || ok=1
  return $ok
}
x6_batch() { render batch-legacy.json "$DEV_PREFIX-x6-$1" "$DEV_PREFIX-x6-$1-s" "$PKG_PREFIX.x6" "$(iso)"; }
x6_partitions() { "${DC[@]}" exec -T kafka kafka-topics --bootstrap-server localhost:29092 --describe --topic "$TOPIC" | grep -c 'Partition: '; }
x6_collector_down() { ! curl -sf -o /dev/null "$COLLECTOR/health"; }
x6_update_log() { mask < "$TMPD/update.log" > "$update_log"; tail -20 "$update_log" | sed 's/^/      /' | tee -a "$LOG"; }
x6_p0_committed() { awk '$1 == "partition" && $2 == 0 {print $4}' "$1"; }
