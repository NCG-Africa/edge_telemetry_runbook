#!/usr/bin/env bash
# System acceptance run (issue #46): run.sh x1 x2 ... from deployments/single-host.
# Each check is a function in x<n>.sh, run in order in this one shell so later
# checks can reuse earlier ones' Apps, keys and Kafka positions (X4 needs X1, X2).
# One PASS/FAIL line per check; exits 1 if any failed. Log: backups/acceptance-<RUN_ID>.log
set -uo pipefail
here=$(cd "$(dirname "$0")" && pwd)
# shellcheck source=lib.sh
. "$here/lib.sh"

log "acceptance run $RUN_ID ($(date -u +%FT%TZ)) checks: $*"
mint_jwt
failed=0
for x in "$@"; do
  X=$(printf %s "$x" | tr "[:lower:]" "[:upper:]")
  log "== $X"
  if [ ! -f "$here/$x.sh" ]; then
    result=FAIL; log "    FAIL $x is not wired ($x.sh missing)"
  else
    # shellcheck source=/dev/null
    . "$here/$x.sh"
    if "$x"; then result=PASS; else result=FAIL; fi
  fi
  [ "$result" = PASS ] || failed=1
  log "$result $X"
done
log "log: $LOG"
exit "$failed"
