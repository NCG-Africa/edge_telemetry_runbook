# EdgeTelemetryDeploymentGo Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Stand up `EdgeTelemetryDeploymentGo`, a deployment repo for `EdgeTelemetryCollectorGo` + `EdgeTelemetryProcessorGo` that mirrors `EdgeTelemetryDeployment`'s structure, Makefile targets, and two topologies (single-host, segmented DMZ/bank).

**Architecture:** Two Go services behind Kafka, PostgreSQL kept external in every topology. `single-host` bundles Kafka+Zookeeper+Redis+both services+Kafka UI on one box (`AUTH_MODE=api_key`). `segmented` splits into `dmz/` (Kafka dual-listener + collector, `AUTH_MODE=jwt`, RS256) and `bank/` (processor only, connects to DMZ Kafka over mTLS).

**Tech Stack:** Docker Compose v2, Make, Bash, OpenSSL. (No application code — this repo is deployment configuration only, mirroring `EdgeTelemetryDeployment`, which likewise contains no Python source.)

## Global Constraints

- This repo contains **no application source code**, matching `EdgeTelemetryDeployment` exactly — only Docker Compose files, Makefiles, env examples, and shared secrets-provisioning scripts.
- Ports must not collide with the Python deployment (8001/8002/6379/8080/9093) or either Go service's own standalone dev compose (8004/8005/6380/8083/8084/9095/2184/2185). This repo uses 8011 (collector), 8012 (processor), 6381 (redis), 8090 (kafka-ui), 9097 (segmented Kafka mTLS), 2186 (zookeeper, dev-compose only).
- PostgreSQL is never bundled in any compose file — always external, matching Python exactly.
- No Redis service in segmented `dmz/` or `bank/` — matches Python's segmented topology exactly (Python's bank Redis existed only for the out-of-scope RUM Analytics API).
- RUM Analytics API and the portal are out of scope entirely — no service entries, no ports, no secrets dirs for them.
- JWT is RS256 (not ES256) to match Python exactly; key files use Collector-Go's existing `<kid>.public.pem` lookup convention.
- Real `.env` files, `*.pem`, `*.key`, `*.jks`, `*.p12` are never committed — `.gitignore` blocks them from Task 1 onward, and no task writes real secrets into git.
- Full design rationale lives in `EdgeTelemetryDeploymentGo/docs/2026-08-17-edge-telemetry-deployment-go-design.md` — consult it for anything this plan doesn't spell out.

---

## Prerequisites — executed in other repos, before this plan's Phase 6 smoke test

This deployment repo depends on two capabilities the Go services don't have yet. Both are real code changes belonging to those services, not to this deployment repo — so each has its own standalone implementation plan, tracked and executed in its own repo:

- **RS256 JWT verification in `EdgeTelemetryCollectorGo`** — the segmented DMZ collector must verify RS256-signed tokens to match Python's bank-signs/DMZ-verifies model; Collector-Go currently only supports ES256. Plan: `../../EdgeTelemetryCollectorGo/docs/plans/2026-08-17-rs256-jwt-support-plan.md`.
- **Kafka mTLS client support in `EdgeTelemetryProcessorGo`** — the segmented bank processor must connect to the DMZ's external Kafka listener over mutual TLS; Processor-Go currently only supports plaintext Kafka connections. Plan: `../../EdgeTelemetryProcessorGo/docs/plans/2026-08-17-kafka-mtls-support-plan.md`.

Both plans are additive and independent of each other — they can be executed in parallel and in any order, and neither touches this repo. Nothing in this plan's Phase 0 through Phase 6 requires either prerequisite to have landed: Phase 6's automated smoke test only exercises the single-host topology (`AUTH_MODE=api_key`, plaintext Kafka), which needs neither RS256 nor mTLS. The segmented topology's manual verification (JWT-authenticated requests against the DMZ, mTLS Kafka between DMZ and bank) does require both prerequisite plans merged first — confirm that before attempting it.

---

## Phase 0 — Repo scaffold

### Task 1: Initialize the EdgeTelemetryDeploymentGo repo

**Files:**
- Create: `EdgeTelemetryDeploymentGo/.gitignore`
- Create: `EdgeTelemetryDeploymentGo/README.md` (stub, filled in fully by Task 16)
- Create: `EdgeTelemetryDeploymentGo/CLAUDE.md` (stub, filled in fully by Task 16)

The `docs/` directory and design spec already exist from the brainstorming phase — this task adds the rest of the skeleton and turns the directory into a git repo.

- [ ] **Step 1: Initialize git**

```bash
cd "EdgeTelemetryDeploymentGo"
git init
```

- [ ] **Step 2: Create `.gitignore`**

```gitignore
# Secrets — never committed
*.pem
*.key
*.jks
*.p12
.env
.env.dev
deployments/single-host/configs/single-host.env
deployments/segmented/dmz/configs/dmz.env
deployments/segmented/bank/configs/bank.env
deployments/segmented/dmz/secrets/**/*.pem
deployments/segmented/dmz/secrets/**/*.jks
deployments/segmented/bank/secrets/**/*.pem
deployments/segmented/bank/secrets/**/*.jks

# OS / editor noise
.DS_Store
*.swp

# Go build artifacts (in case anything is built locally in this repo)
.gocache/
.gomodcache/
```

- [ ] **Step 3: Create placeholder `README.md` and `CLAUDE.md`**

```markdown
# EdgeTelemetry Deployment (Go)

Deployment repo for the Go telemetry services (`EdgeTelemetryCollectorGo`,
`EdgeTelemetryProcessorGo`). See `docs/2026-08-17-edge-telemetry-deployment-go-design.md`
for the full design. This README is filled in as the deployment structure lands.
```

```markdown
# CLAUDE.md - EdgeTelemetry Deployment (Go)

Placeholder — filled in once the deployment structure is complete.
```

- [ ] **Step 4: Commit**

```bash
git add .gitignore README.md CLAUDE.md docs/
git commit -m "chore: initialize EdgeTelemetryDeploymentGo repo"
```

---

## Phase 1 — Shared secrets tooling

### Task 2: Create `shared/scripts/` and `shared/README.md`

**Files:**
- Create: `EdgeTelemetryDeploymentGo/shared/scripts/generate-ca.sh`
- Create: `EdgeTelemetryDeploymentGo/shared/scripts/issue-kafka-server-cert.sh`
- Create: `EdgeTelemetryDeploymentGo/shared/scripts/issue-kafka-client-cert.sh`
- Create: `EdgeTelemetryDeploymentGo/shared/scripts/generate-jwt-keypair.sh`
- Create: `EdgeTelemetryDeploymentGo/shared/scripts/verify-key-fingerprint.sh`
- Create: `EdgeTelemetryDeploymentGo/shared/scripts/install-pre-commit-hook.sh`
- Create: `EdgeTelemetryDeploymentGo/shared/scripts/pre-commit-hook.sh`
- Create: `EdgeTelemetryDeploymentGo/shared/README.md`

**Interfaces:**
- Consumes: nothing from earlier tasks.
- Produces: `generate-ca.sh` → `ca-cert.pem`, `ca-key.pem`. `issue-kafka-server-cert.sh` → JKS keystore/truststore for the DMZ Kafka broker. `issue-kafka-client-cert.sh` → PEM `client.cert.pem` / `client.key.pem` (consumed by `KAFKA_TLS_CLIENT_CERT` / `KAFKA_TLS_CLIENT_KEY`, added to Processor-Go by ../../EdgeTelemetryProcessorGo/docs/plans/2026-08-17-kafka-mtls-support-plan.md). `generate-jwt-keypair.sh` → `<kid>.public.pem` / `private.pem` (consumed by `JWT_PUBLIC_KEYS_DIR` from Collector-Go, RS256 support added by ../../EdgeTelemetryCollectorGo/docs/plans/2026-08-17-rs256-jwt-support-plan.md).

- [ ] **Step 1: Copy `generate-ca.sh` unchanged**

Copy `EdgeTelemetryDeployment/shared/scripts/generate-ca.sh` to `EdgeTelemetryDeploymentGo/shared/scripts/generate-ca.sh` verbatim — this script only produces a CA keypair with OpenSSL and has no language-specific content.

```bash
cp "../EdgeTelemetryDeployment/shared/scripts/generate-ca.sh" "shared/scripts/generate-ca.sh"
chmod +x "shared/scripts/generate-ca.sh"
```

- [ ] **Step 2: Copy `issue-kafka-server-cert.sh` unchanged**

```bash
cp "../EdgeTelemetryDeployment/shared/scripts/issue-kafka-server-cert.sh" "shared/scripts/issue-kafka-server-cert.sh"
chmod +x "shared/scripts/issue-kafka-server-cert.sh"
```

The DMZ Kafka broker is still the Confluent/Java image regardless of which service language produces/consumes messages, so it still needs a JKS keystore. No changes needed.

- [ ] **Step 3: Write the PEM-based `issue-kafka-client-cert.sh`**

```bash
#!/bin/bash
# Issue a PEM Kafka client certificate for the bank-side Go processor.
# Unlike the Python deployment's version, this skips keytool/JKS entirely —
# Go's crypto/tls (used by EdgeTelemetryProcessorGo) consumes PEM directly.
# Usage: ./issue-kafka-client-cert.sh --ca-cert ./ca/ca-cert.pem --ca-key ./ca/ca-key.pem --client-name bank-processor --output-dir ./client-certs

set -euo pipefail

CA_CERT=""
CA_KEY=""
CLIENT_NAME=""
OUTPUT_DIR="./kafka-client-certs"
VALIDITY_DAYS=365

while [[ $# -gt 0 ]]; do
    case $1 in
        --ca-cert) CA_CERT="$2"; shift 2 ;;
        --ca-key) CA_KEY="$2"; shift 2 ;;
        --client-name) CLIENT_NAME="$2"; shift 2 ;;
        --output-dir) OUTPUT_DIR="$2"; shift 2 ;;
        --validity-days) VALIDITY_DAYS="$2"; shift 2 ;;
        -h|--help)
            echo "Usage: $0 [OPTIONS]"
            echo ""
            echo "Required:"
            echo "  --ca-cert FILE         CA certificate PEM file"
            echo "  --ca-key FILE          CA private key PEM file"
            echo "  --client-name NAME     Client identifier (e.g., bank-processor)"
            echo ""
            echo "Optional:"
            echo "  --output-dir DIR       Output directory (default: ./kafka-client-certs)"
            echo "  --validity-days DAYS   Certificate validity (default: 365)"
            echo ""
            echo "Outputs PEM files (client.cert.pem, client.key.pem) plus a copy of the"
            echo "CA cert (ca.cert.pem), for EdgeTelemetryProcessorGo's KAFKA_TLS_* env vars."
            exit 0
            ;;
        *) echo "Unknown option: $1"; exit 1 ;;
    esac
done

if [[ -z "$CA_CERT" || -z "$CA_KEY" || -z "$CLIENT_NAME" ]]; then
    echo "ERROR: --ca-cert, --ca-key, and --client-name are required"
    exit 1
fi

mkdir -p "$OUTPUT_DIR"
WORK_DIR=$(mktemp -d)
trap "rm -rf $WORK_DIR" EXIT

echo "Issuing Kafka client certificate (PEM)..."
echo "  Client: $CLIENT_NAME"
echo "  CA cert: $CA_CERT"
echo "  Output: $OUTPUT_DIR"

# Step 1: Generate client private key
echo "[1/3] Generating client private key..."
openssl genpkey \
    -algorithm RSA \
    -pkeyopt rsa_keygen_bits:2048 \
    -out "$OUTPUT_DIR/client.key.pem"

# Step 2: Generate CSR
echo "[2/3] Generating certificate signing request..."
openssl req -new \
    -key "$OUTPUT_DIR/client.key.pem" \
    -subj "/CN=$CLIENT_NAME/O=EdgeTelemetry/OU=Bank" \
    -out "$WORK_DIR/client.csr"

# Step 3: Sign the CSR with the CA
echo "[3/3] Signing certificate with CA..."
openssl x509 -req \
    -in "$WORK_DIR/client.csr" \
    -CA "$CA_CERT" \
    -CAkey "$CA_KEY" \
    -CAcreateserial \
    -out "$OUTPUT_DIR/client.cert.pem" \
    -days "$VALIDITY_DAYS"

cp "$CA_CERT" "$OUTPUT_DIR/ca.cert.pem"

chmod 600 "$OUTPUT_DIR/client.key.pem"
chmod 644 "$OUTPUT_DIR/client.cert.pem" "$OUTPUT_DIR/ca.cert.pem"

echo ""
echo "Kafka client certificate generated:"
echo "  Client cert: $OUTPUT_DIR/client.cert.pem"
echo "  Client key:  $OUTPUT_DIR/client.key.pem  (600 permissions)"
echo "  CA cert:     $OUTPUT_DIR/ca.cert.pem"
echo ""
echo "Copy these to: deployments/segmented/bank/secrets/kafka-tls/"
echo "Set in deployments/segmented/bank/configs/bank.env:"
echo "  KAFKA_SECURITY_PROTOCOL=SSL"
echo "  KAFKA_TLS_CA_CERT=/app/certs/kafka/ca.cert.pem"
echo "  KAFKA_TLS_CLIENT_CERT=/app/certs/kafka/client.cert.pem"
echo "  KAFKA_TLS_CLIENT_KEY=/app/certs/kafka/client.key.pem"
```

```bash
chmod +x shared/scripts/issue-kafka-client-cert.sh
```

- [ ] **Step 4: Write the `<kid>`-aware `generate-jwt-keypair.sh`**

```bash
#!/bin/bash
# Generate an RS256 JWT keypair for EdgeTelemetry (Go) authentication.
# Same RSA/RS256 generation as the Python deployment's version, but the
# public key is written as "<kid>.public.pem" to match Collector-Go's
# lookup convention (JWT_PUBLIC_KEYS_DIR/<kid>.public.pem).
# Usage: ./generate-jwt-keypair.sh --output-dir ./jwt-keys [--kid my-key-id]

set -euo pipefail

OUTPUT_DIR="./jwt-keys"
KID=""

while [[ $# -gt 0 ]]; do
    case $1 in
        --output-dir) OUTPUT_DIR="$2"; shift 2 ;;
        --kid) KID="$2"; shift 2 ;;
        -h|--help)
            echo "Usage: $0 [OPTIONS]"
            echo ""
            echo "Options:"
            echo "  --output-dir DIR   Output directory (default: ./jwt-keys)"
            echo "  --kid ID           Key ID to embed in the public key filename."
            echo "                     Defaults to the key's SHA-256 fingerprint if omitted."
            echo ""
            echo "Generates an RS256 keypair (private.pem + <kid>.public.pem)."
            echo ""
            echo "After generation:"
            echo "  - Copy <kid>.public.pem to: deployments/segmented/dmz/secrets/jwt-public-keys/"
            echo "  - Copy both files to:        deployments/segmented/bank/secrets/jwt-signing-keys/"
            exit 0
            ;;
        *) echo "Unknown option: $1"; exit 1 ;;
    esac
done

mkdir -p "$OUTPUT_DIR"

echo "Generating RS256 JWT keypair..."
echo "  Output: $OUTPUT_DIR"

openssl genpkey \
    -algorithm RSA \
    -pkeyopt rsa_keygen_bits:2048 \
    -out "$OUTPUT_DIR/private.pem"

openssl rsa \
    -in "$OUTPUT_DIR/private.pem" \
    -pubout \
    -out "$OUTPUT_DIR/public.pem.tmp"

FINGERPRINT=$(openssl rsa -in "$OUTPUT_DIR/private.pem" -pubout -outform DER 2>/dev/null | openssl dgst -sha256 | awk '{print $2}')

if [[ -z "$KID" ]]; then
    KID="${FINGERPRINT:0:16}"
fi

mv "$OUTPUT_DIR/public.pem.tmp" "$OUTPUT_DIR/$KID.public.pem"

chmod 600 "$OUTPUT_DIR/private.pem"
chmod 644 "$OUTPUT_DIR/$KID.public.pem"

echo ""
echo "JWT keypair generated:"
echo "  Private key: $OUTPUT_DIR/private.pem (600 permissions)"
echo "  Public key:  $OUTPUT_DIR/$KID.public.pem (644 permissions)"
echo "  kid:         $KID"
echo ""
echo "Fingerprint (for verification across zones):"
echo "$FINGERPRINT"
echo ""
echo "Next steps:"
echo "  1. Copy $KID.public.pem to: deployments/segmented/dmz/secrets/jwt-public-keys/"
echo "  2. Copy both files to:       deployments/segmented/bank/secrets/jwt-signing-keys/"
echo "  3. Verify fingerprint matches on both sides with: ./verify-key-fingerprint.sh"
echo "  4. Sign tokens with alg=RS256 and header kid=\"$KID\""
```

```bash
chmod +x shared/scripts/generate-jwt-keypair.sh
```

- [ ] **Step 5: Copy `verify-key-fingerprint.sh`, `install-pre-commit-hook.sh`, `pre-commit-hook.sh` unchanged**

```bash
cp "../EdgeTelemetryDeployment/shared/scripts/verify-key-fingerprint.sh" "shared/scripts/verify-key-fingerprint.sh"
cp "../EdgeTelemetryDeployment/shared/scripts/install-pre-commit-hook.sh" "shared/scripts/install-pre-commit-hook.sh"
cp "../EdgeTelemetryDeployment/shared/scripts/pre-commit-hook.sh" "shared/scripts/pre-commit-hook.sh"
chmod +x shared/scripts/verify-key-fingerprint.sh shared/scripts/install-pre-commit-hook.sh shared/scripts/pre-commit-hook.sh
```

These scripts operate on file extensions and git internals only — nothing Python-specific. Open `verify-key-fingerprint.sh` after copying and confirm it doesn't hardcode a `public.pem` filename anywhere (it fingerprints whatever file path is passed as an argument) — if it does, adjust the invocation instructions in Step 7 to pass the `<kid>.public.pem` path explicitly rather than editing the script.

- [ ] **Step 6: Write `shared/README.md`**

```markdown
# Shared Secrets Tooling

Scripts for provisioning the security material used by the `segmented`
deployment: a private CA, Kafka mTLS certs (server-side JKS for the broker,
client-side PEM for the Go processor), and an RS256 JWT keypair.

## Order of operations

1. **Generate the CA** (once):
   ```bash
   ./scripts/generate-ca.sh --output-dir ./ca
   ```

2. **Issue the Kafka server certificate** (DMZ broker, JKS):
   ```bash
   ./scripts/issue-kafka-server-cert.sh \
     --ca-cert ./ca/ca-cert.pem --ca-key ./ca/ca-key.pem \
     --fqdn dmz-kafka.example.com \
     --output-dir ../deployments/segmented/dmz/secrets/kafka-tls
   ```

3. **Issue the Kafka client certificate** (bank processor, PEM):
   ```bash
   ./scripts/issue-kafka-client-cert.sh \
     --ca-cert ./ca/ca-cert.pem --ca-key ./ca/ca-key.pem \
     --client-name bank-processor \
     --output-dir ../deployments/segmented/bank/secrets/kafka-tls
   ```

4. **Generate the JWT keypair** (RS256, bank signs / DMZ verifies):
   ```bash
   ./scripts/generate-jwt-keypair.sh --output-dir ./jwt-keys
   # Copy <kid>.public.pem -> ../deployments/segmented/dmz/secrets/jwt-public-keys/
   # Copy both files       -> ../deployments/segmented/bank/secrets/jwt-signing-keys/
   ```

5. **Verify fingerprints match across zones**:
   ```bash
   ./scripts/verify-key-fingerprint.sh \
     ../deployments/segmented/dmz/secrets/jwt-public-keys/<kid>.public.pem \
     ../deployments/segmented/bank/secrets/jwt-signing-keys/<kid>.public.pem
   ```

6. **Install the pre-commit hook** (blocks accidentally committing secrets):
   ```bash
   ./scripts/install-pre-commit-hook.sh
   ```

## Why the client cert is PEM, not JKS

The DMZ Kafka broker is the Confluent/Java image and needs a JKS keystore —
that's what `issue-kafka-server-cert.sh` produces, unchanged from the Python
deployment. The bank-side consumer here is `EdgeTelemetryProcessorGo`, a Go
binary using `crypto/tls`, which reads PEM directly and has no JKS support.
`issue-kafka-client-cert.sh` therefore skips `keytool` and issues PEM output.
```

- [ ] **Step 7: Validate scripts are syntactically sound**

```bash
bash -n shared/scripts/generate-ca.sh
bash -n shared/scripts/issue-kafka-server-cert.sh
bash -n shared/scripts/issue-kafka-client-cert.sh
bash -n shared/scripts/generate-jwt-keypair.sh
bash -n shared/scripts/verify-key-fingerprint.sh
bash -n shared/scripts/install-pre-commit-hook.sh
bash -n shared/scripts/pre-commit-hook.sh
```

Expected: no output (syntax OK) from any invocation.

- [ ] **Step 8: Commit**

```bash
git add shared/
git commit -m "feat: add shared secrets tooling (CA, Kafka TLS, RS256 JWT)"
```

---

## Phase 2 — single-host deployment

### Task 3: `deployments/single-host/docker-compose.yml` and `configs/single-host.env.example`

**Files:**
- Create: `EdgeTelemetryDeploymentGo/deployments/single-host/docker-compose.yml`
- Create: `EdgeTelemetryDeploymentGo/deployments/single-host/configs/single-host.env.example`

**Interfaces:**
- Consumes: `KAFKA_TLS_*`/`KAFKA_SECURITY_PROTOCOL` are irrelevant here (single-host Kafka is plaintext-only, matching Python). Consumes Collector-Go's and Processor-Go's env contracts as documented in each service's README.
- Produces: a running stack reachable at `http://localhost:8011` (collector) and `http://localhost:8012` (processor), used by Task 17's smoke test.

- [ ] **Step 1: Write `docker-compose.yml`**

```yaml
services:
  zookeeper:
    image: confluentinc/cp-zookeeper:7.4.0
    hostname: zookeeper
    container_name: telemetry-go-zookeeper
    environment:
      ZOOKEEPER_CLIENT_PORT: 2181
      ZOOKEEPER_TICK_TIME: 2000
    volumes:
      - zookeeper-data:/var/lib/zookeeper/data
      - zookeeper-logs:/var/lib/zookeeper/log
    networks:
      - telemetry-go-network
    restart: unless-stopped
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"

  kafka:
    image: confluentinc/cp-kafka:7.4.0
    hostname: kafka
    container_name: telemetry-go-kafka
    depends_on:
      - zookeeper
    environment:
      KAFKA_BROKER_ID: 1
      KAFKA_ZOOKEEPER_CONNECT: "zookeeper:2181"
      KAFKA_LISTENER_SECURITY_PROTOCOL_MAP: PLAINTEXT:PLAINTEXT
      KAFKA_ADVERTISED_LISTENERS: PLAINTEXT://kafka:29092
      KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR: 1
      KAFKA_GROUP_INITIAL_REBALANCE_DELAY_MS: 0
      KAFKA_AUTO_CREATE_TOPICS_ENABLE: "true"
    volumes:
      - kafka-data:/var/lib/kafka/data
    networks:
      - telemetry-go-network
    restart: unless-stopped
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"
    healthcheck:
      test: ["CMD-SHELL", "kafka-topics --bootstrap-server localhost:29092 --list"]
      interval: 10s
      timeout: 10s
      retries: 5
      start_period: 40s

  telemetry-redis:
    image: redis:7-alpine
    container_name: telemetry-go-redis
    ports:
      - "6381:6379"
    volumes:
      - redis-data:/data
    networks:
      - telemetry-go-network
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 30s
      timeout: 10s
      retries: 3
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"

  telemetry-collector-go:
    build:
      context: ../../../EdgeTelemetryCollectorGo
      dockerfile: Dockerfile
    container_name: telemetry-collector-go
    depends_on:
      kafka:
        condition: service_healthy
    ports:
      - "8011:8000"
    env_file:
      - ./configs/single-host.env
    environment:
      # --- service-specific overrides ---
      AUTH_MODE: api_key
      DATABASE_SSL_MODE: disable
      KAFKA_BOOTSTRAP_SERVERS: kafka:29092
      KAFKA_TOPIC: telemetry-upsert
      KAFKA_ACKS: all
      KAFKA_RETRIES: 3
      REDIS_HOST: telemetry-redis
      REDIS_PORT: 6379
      REDIS_PASSWORD: ""
      REDIS_DB: 0
      API_HOST: 0.0.0.0
      API_PORT: 8000
    networks:
      - telemetry-go-network
    restart: unless-stopped
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  telemetry-processor-go:
    build:
      context: ../../../EdgeTelemetryProcessorGo
      dockerfile: Dockerfile
    container_name: telemetry-processor-go
    depends_on:
      kafka:
        condition: service_healthy
    ports:
      - "8012:8000"
    env_file:
      - ./configs/single-host.env
    environment:
      # --- service-specific overrides ---
      KAFKA_BOOTSTRAP_SERVERS: kafka:29092
      KAFKA_TOPIC: telemetry-upsert
      KAFKA_GROUP_ID: edge-telemetry-processor
      KAFKA_SECURITY_PROTOCOL: PLAINTEXT
      API_HOST: 0.0.0.0
      API_PORT: 8000
    networks:
      - telemetry-go-network
    restart: unless-stopped
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"
    healthcheck:
      test: ["CMD", "wget", "-qO-", "http://localhost:8000/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  kafka-ui:
    image: provectuslabs/kafka-ui:latest
    container_name: telemetry-go-kafka-ui
    depends_on:
      kafka:
        condition: service_healthy
    ports:
      - "8090:8080"
    environment:
      KAFKA_CLUSTERS_0_NAME: telemetry-go-production
      KAFKA_CLUSTERS_0_BOOTSTRAPSERVERS: kafka:29092
      KAFKA_CLUSTERS_0_ZOOKEEPER: zookeeper:2181
    networks:
      - telemetry-go-network
    restart: unless-stopped
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"

volumes:
  kafka-data:
    driver: local
  zookeeper-data:
    driver: local
  zookeeper-logs:
    driver: local
  redis-data:
    driver: local

networks:
  telemetry-go-network:
    driver: bridge
```

- [ ] **Step 2: Write `configs/single-host.env.example`**

```env
# ===== Shared =====
LOG_LEVEL=INFO

# ===== Kafka (shared) =====
KAFKA_BOOTSTRAP_SERVERS=kafka:29092
KAFKA_TOPIC=telemetry-upsert

# ===== Redis (Collector-Go only) =====
REDIS_HOST=telemetry-redis
REDIS_PORT=6379
REDIS_PASSWORD=
REDIS_DB=0

# ===== Collector-Go: Auth =====
AUTH_MODE=api_key
DATABASE_SSL_MODE=disable
# Postgres DSN for API-key lookups against rum_api_keys (Collector-Go only).
# Replace user/password/host/port/dbname with your real values.
DATABASE_URL=postgresql://USER:PASSWORD@DB_HOST:5432/edge_db

# ===== Processor-Go: Postgres (discrete vars — no DATABASE_URL support) =====
POSTGRES_HOST=DB_HOST
POSTGRES_PORT=5432
POSTGRES_DATABASE=edge_db
POSTGRES_USER=USER
POSTGRES_PASSWORD=PASSWORD
POSTGRES_SSLMODE=disable

# ===== API defaults =====
API_HOST=0.0.0.0
```

- [ ] **Step 3: Validate compose syntax**

```bash
cd deployments/single-host
cp configs/single-host.env.example configs/single-host.env
docker compose config --quiet
```

Expected: no output (valid compose file). Then remove the throwaway env copy so it doesn't get committed:

```bash
rm configs/single-host.env
```

- [ ] **Step 4: Commit**

```bash
cd "EdgeTelemetryDeploymentGo"
git add deployments/single-host/docker-compose.yml deployments/single-host/configs/single-host.env.example
git commit -m "feat: add single-host deployment compose"
```

---

### Task 4: `deployments/single-host/Makefile`

**Files:**
- Create: `EdgeTelemetryDeploymentGo/deployments/single-host/Makefile`

**Interfaces:**
- Consumes: `docker-compose.yml` and `configs/single-host.env` from Task 3.
- Produces: `make deploy`, `make down`, `make health`, etc. — same target names as the Python single-host Makefile, called by the root Makefile (Task 13) and documented in Task 5's README.

- [ ] **Step 1: Write the Makefile**

```makefile
# Edge Telemetry (Go) - All-in-One Deployment Makefile
# All services run on a single host

.PHONY: help deploy down logs restart update status health health-detailed config-check system-info backup restore clean cleanup test-deployment monitor

MODE_NAME := all-in-one-go

help:
	@echo "Edge Telemetry (Go) - All-in-One Mode"
	@echo "======================================"
	@echo ""
	@echo "Deployment:"
	@echo "  deploy       - Deploy all services"
	@echo "  down         - Stop all services"
	@echo "  logs         - View logs for all services"
	@echo "  restart      - Restart all services"
	@echo "  update       - Pull latest images and redeploy"
	@echo ""
	@echo "Monitoring:"
	@echo "  status       - Show service status"
	@echo "  health       - Check health of services"
	@echo "  health-detailed - Detailed health check"
	@echo "  config-check - Validate configuration"
	@echo "  system-info  - Display system information"
	@echo "  monitor      - Real-time monitoring dashboard"
	@echo ""
	@echo "Testing:"
	@echo "  test-deployment   - Test with sample telemetry data"
	@echo ""
	@echo "Maintenance:"
	@echo "  backup       - Backup data volumes"
	@echo "  restore      - Restore from backup"
	@echo "  cleanup      - Clean up unused resources"
	@echo ""
	@echo "Service Logs:"
	@echo "  logs-collector     - Collector-Go logs"
	@echo "  logs-processor     - Processor-Go logs"
	@echo "  logs-redis         - Redis logs"
	@echo "  logs-kafka         - Kafka logs"

deploy:
	@echo "Deploying EdgeTelemetry Go ($(MODE_NAME) mode)..."
	@echo "Pre-deployment checks..."
	@$(MAKE) config-check
	@$(MAKE) system-info
	@echo "Creating data directories..."
	@sudo mkdir -p /opt/edge-telemetry-go/data/{kafka,zookeeper,redis}
	@sudo mkdir -p /opt/edge-telemetry-go/logs/{zookeeper,redis}
	@sudo chown -R 1000:1000 /opt/edge-telemetry-go/
	@echo "Building and starting services..."
	docker compose up -d --build
	@echo "Waiting for services to start..."
	@sleep 60
	@echo "Running health checks..."
	@$(MAKE) health-detailed
	@echo ""
	@echo "Auto-fixing any service connectivity issues..."
	@if ! curl -f -s http://localhost:8012/health > /dev/null 2>&1; then \
		echo "Processor unhealthy - restarting..."; \
		docker compose restart telemetry-processor-go; \
		sleep 30; \
		if curl -f -s http://localhost:8012/health > /dev/null 2>&1; then \
			echo "Processor recovered"; \
		else \
			echo "Processor still unhealthy after restart"; \
		fi \
	else \
		echo "Processor is healthy"; \
	fi
	@echo ""
	@echo "Deployment completed!"
	@echo ""
	@echo "Service URLs:"
	@echo "  Collector API:  http://localhost:8011"
	@echo "  Processor API:  http://localhost:8012"
	@echo "  Kafka UI:       http://localhost:8090"
	@echo ""
	@echo "Monitor with: make logs | make status"

down:
	docker compose down

logs:
	docker compose logs -f

restart:
	@echo "Restarting services..."
	docker compose restart
	@sleep 20
	@$(MAKE) health

update:
	@echo "Updating services..."
	docker compose pull
	docker compose up -d
	@sleep 20
	@$(MAKE) health

logs-collector:
	docker compose logs -f telemetry-collector-go

logs-processor:
	docker compose logs -f telemetry-processor-go

logs-redis:
	docker compose logs -f telemetry-redis

logs-kafka:
	docker compose logs -f kafka

status:
	@echo "Service Status ($(MODE_NAME) mode):"
	@docker compose ps --format "table {{.Name}}\t{{.Status}}\t{{.Ports}}" || echo "No services running"
	@echo ""
	@echo "Volume usage:"
	@docker volume ls | grep telemetry-go || echo "No telemetry-go volumes found"

health:
	@echo "Checking service health..."
	@sleep 5
	@if curl -f -s http://localhost:8011/health > /dev/null 2>&1; then \
		echo "  Collector (8011): healthy"; \
	else \
		echo "  Collector (8011): unhealthy"; \
	fi
	@if curl -f -s http://localhost:8012/health > /dev/null 2>&1; then \
		echo "  Processor (8012): healthy"; \
	else \
		echo "  Processor (8012): unhealthy"; \
	fi
	@echo ""
	@echo "Docker status:"
	@docker compose ps --format "table {{.Name}}\t{{.Status}}\t{{.Ports}}"

health-detailed:
	@echo "Detailed health check ($(MODE_NAME) mode)..."
	@echo ""
	@echo "Collector:"
	@if curl -f -s http://localhost:8011/health > /dev/null 2>&1; then \
		echo "  Status: healthy"; \
		echo "  Response: $$(curl -s http://localhost:8011/health 2>/dev/null)"; \
	else \
		echo "  Status: unhealthy"; \
	fi
	@echo ""
	@echo "Processor:"
	@if curl -f -s http://localhost:8012/health > /dev/null 2>&1; then \
		echo "  Status: healthy"; \
		echo "  Response: $$(curl -s http://localhost:8012/health 2>/dev/null)"; \
	else \
		echo "  Status: unhealthy"; \
	fi
	@echo ""
	@echo "Docker status:"
	@docker compose ps --format "table {{.Name}}\t{{.Status}}\t{{.Ports}}" 2>/dev/null || echo "Could not fetch container status"

config-check:
	@echo "Validating configuration..."
	@if [ -f "configs/single-host.env" ]; then \
		echo "  Config file: found"; \
		if grep -q "USER:PASSWORD\|DB_HOST\|placeholder\|example" configs/single-host.env 2>/dev/null; then \
			echo "  Database config: contains placeholder values -- please update"; \
			exit 1; \
		else \
			echo "  Database config: customized"; \
		fi \
	else \
		echo "  Config file: NOT FOUND (configs/single-host.env)"; \
		exit 1; \
	fi

system-info:
	@echo "System Information:"
	@echo "  OS: $$(lsb_release -d 2>/dev/null | cut -f2 || echo 'Unknown')"
	@echo "  Memory: $$(free -h 2>/dev/null | grep Mem | awk '{print $$2}' | head -1 || echo 'Unknown')"
	@echo "  Disk: $$(df -h . 2>/dev/null | tail -1 | awk '{print $$4}' | head -1 || echo 'Unknown') available"
	@echo "  Docker: $$(docker --version 2>/dev/null || echo 'Not installed')"
	@echo "  Docker Compose: $$(docker compose version 2>/dev/null || echo 'Not installed')"

backup:
	@echo "Creating backup..."
	@mkdir -p backups
	@timestamp=$$(date +%Y%m%d_%H%M%S); \
	echo "Creating backup_$$timestamp.tar.gz..."; \
	sudo tar -czf backups/backup_$$timestamp.tar.gz -C /opt/edge-telemetry-go data/ || \
	echo "Backup failed - ensure /opt/edge-telemetry-go exists and you have sudo access"
	@echo "Backup completed"

restore:
	@echo "Available backups:"
	@ls -la backups/*.tar.gz 2>/dev/null || echo "No backups found"
	@echo ""
	@echo "To restore, run: sudo tar -xzf backups/backup_TIMESTAMP.tar.gz -C /opt/edge-telemetry-go"

clean:
	docker compose down -v
	docker system prune -f

cleanup:
	@echo "Cleaning up..."
	@docker container prune -f
	@docker image prune -f
	@docker network prune -f
	@echo "Cleanup completed"

test-deployment:
	@echo "Testing deployment with sample telemetry data..."
	@sleep 5
	@curl -X POST http://localhost:8011/telemetry \
		-H "Content-Type: application/json" \
		-H "User-Agent: EdgeTelemetryGo-Test/1.0" \
		-d '{ \
			"device_id": "deployment-test-device", \
			"events": [{ \
				"type": "deployment_test", \
				"timestamp": "'$$(date -u +%Y-%m-%dT%H:%M:%SZ)'" \
			}] \
		}' \
	&& echo "Test data sent successfully" \
	|| echo "Failed to send test data"
	@echo ""
	@echo "Checking processor logs..."
	@timeout 10 docker compose logs --tail=10 telemetry-processor-go || echo "Processor logs unavailable"

monitor:
	@echo "Real-time monitoring (Ctrl+C to stop)..."
	@while true; do \
		clear; \
		echo "EdgeTelemetry Go Monitor ($(MODE_NAME)) - $$(date)"; \
		echo "================================================"; \
		$(MAKE) health 2>/dev/null; \
		echo ""; \
		echo "Container Resources:"; \
		docker stats --no-stream --format "table {{.Name}}\t{{.CPUPerc}}\t{{.MemUsage}}" 2>/dev/null || echo "Stats unavailable"; \
		sleep 10; \
	done
```

Note: Collector-Go's minimum valid payload requires `device_id` at root plus a non-empty `events` array (see `EdgeTelemetryCollectorGo/README.md`, "Payload Contract") — `test-deployment` above uses that shape, not Python's `telemetry-batch` shape.

- [ ] **Step 2: Validate Makefile syntax**

```bash
cd deployments/single-host
make -n help
```

Expected: prints the help text without errors (dry-run confirms no syntax errors).

- [ ] **Step 3: Commit**

```bash
cd "EdgeTelemetryDeploymentGo"
git add deployments/single-host/Makefile
git commit -m "feat: add single-host deployment Makefile"
```

---

### Task 5: `deployments/single-host/README.md`

**Files:**
- Create: `EdgeTelemetryDeploymentGo/deployments/single-host/README.md`

- [ ] **Step 1: Write the README**

```markdown
# Single-Host Deployment (Go)

Everything on one host: Kafka, Zookeeper, Redis, Collector-Go, Processor-Go,
Kafka UI. No auth-plane split — Collector-Go runs `AUTH_MODE=api_key` against
an external PostgreSQL. Use this for dev, staging, or any production
environment without a network-segmentation requirement.

## Quick start

```bash
cp configs/single-host.env.example configs/single-host.env
# Edit configs/single-host.env: set DATABASE_URL (Collector-Go) and the
# POSTGRES_* vars (Processor-Go) to point at your external PostgreSQL.
make deploy
```

## Service URLs

| Service | URL |
|---|---|
| Collector-Go | http://localhost:8011 |
| Processor-Go | http://localhost:8012 |
| Kafka UI | http://localhost:8090 |
| Redis | localhost:6381 |

## Commands

```bash
make deploy           # Build + start
make down              # Stop
make logs               # Tail all logs
make health              # Quick health check
make health-detailed      # Detailed health check
make status                # Container status
make test-deployment        # Send a sample telemetry event
make monitor                  # Live health/resource dashboard
```

See the root [`Makefile`](../../Makefile) and [`README.md`](../../README.md) for
the full command reference and the local-dev workflow (building from sibling
source instead of registry images).

## PostgreSQL

Never bundled in this compose file. Point `DATABASE_URL` (Collector-Go) and
`POSTGRES_HOST`/`POSTGRES_PORT`/`POSTGRES_DATABASE`/`POSTGRES_USER`/`POSTGRES_PASSWORD`/`POSTGRES_SSLMODE`
(Processor-Go — it has no `DATABASE_URL` support) at a managed or external
instance. Both must reach the same `edge_db` database; Collector-Go reads
`rum_api_keys`, Processor-Go writes the RUM tables.
```

- [ ] **Step 2: Commit**

```bash
git add deployments/single-host/README.md
git commit -m "docs: add single-host deployment README"
```

---

## Phase 3 — segmented/dmz

### Task 6: `deployments/segmented/dmz/docker-compose.yml`, `configs/dmz.env.example`, `secrets/README.md`

**Files:**
- Create: `EdgeTelemetryDeploymentGo/deployments/segmented/dmz/docker-compose.yml`
- Create: `EdgeTelemetryDeploymentGo/deployments/segmented/dmz/configs/dmz.env.example`
- Create: `EdgeTelemetryDeploymentGo/deployments/segmented/dmz/secrets/README.md`

**Interfaces:**
- Consumes: RS256 verification, added to Collector-Go by `../../EdgeTelemetryCollectorGo/docs/plans/2026-08-17-rs256-jwt-support-plan.md` (`AUTH_MODE=jwt`, `JWT_PUBLIC_KEYS_DIR=/app/keys/jwt`, files named `<kid>.public.pem`).
- Produces: DMZ Kafka external listener on host port 9097 for the bank processor (Task 9) to connect to.

- [ ] **Step 1: Write `docker-compose.yml`**

```yaml
# EdgeTelemetry Go - DMZ Deployment
# Internet-facing services: Kafka (dual-listener) + Collector-Go + Kafka UI
# Bank-side processor connects to Kafka on port 9097 via mTLS

services:
  zookeeper:
    image: confluentinc/cp-zookeeper:7.4.0
    hostname: zookeeper
    container_name: telemetry-go-zookeeper
    environment:
      ZOOKEEPER_CLIENT_PORT: 2181
      ZOOKEEPER_TICK_TIME: 2000
    volumes:
      - zookeeper-data:/var/lib/zookeeper/data
      - zookeeper-logs:/var/lib/zookeeper/log
    networks:
      - telemetry-go-network
    restart: unless-stopped
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"

  kafka:
    image: confluentinc/cp-kafka:7.4.0
    hostname: kafka
    container_name: telemetry-go-kafka
    depends_on:
      - zookeeper
    ports:
      - "9097:9097"     # External SSL listener for the bank-side processor
    environment:
      KAFKA_BROKER_ID: 1
      KAFKA_ZOOKEEPER_CONNECT: "zookeeper:2181"
      # Dual listeners: INTERNAL for collector (plaintext), EXTERNAL for bank processor (SSL/mTLS)
      KAFKA_LISTENER_SECURITY_PROTOCOL_MAP: "INTERNAL:PLAINTEXT,EXTERNAL:SSL"
      KAFKA_LISTENERS: "INTERNAL://0.0.0.0:29092,EXTERNAL://0.0.0.0:9097"
      KAFKA_ADVERTISED_LISTENERS: "INTERNAL://kafka:29092,EXTERNAL://${DMZ_KAFKA_EXTERNAL_FQDN:-dmz-kafka-go.example.com}:9097"
      KAFKA_INTER_BROKER_LISTENER_NAME: INTERNAL
      KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR: 1
      KAFKA_GROUP_INITIAL_REBALANCE_DELAY_MS: 0
      KAFKA_AUTO_CREATE_TOPICS_ENABLE: "false"
      KAFKA_SSL_KEYSTORE_LOCATION: /etc/kafka/secrets/kafka.server.keystore.jks
      KAFKA_SSL_KEYSTORE_PASSWORD: ${KAFKA_KEYSTORE_PASSWORD:-changeit}
      KAFKA_SSL_KEY_PASSWORD: ${KAFKA_KEY_PASSWORD:-changeit}
      KAFKA_SSL_TRUSTSTORE_LOCATION: /etc/kafka/secrets/kafka.server.truststore.jks
      KAFKA_SSL_TRUSTSTORE_PASSWORD: ${KAFKA_TRUSTSTORE_PASSWORD:-changeit}
      KAFKA_SSL_CLIENT_AUTH: required
      KAFKA_SSL_ENDPOINT_IDENTIFICATION_ALGORITHM: ""
    volumes:
      - kafka-data:/var/lib/kafka/data
      - ./secrets/kafka-tls:/etc/kafka/secrets:ro
    networks:
      - telemetry-go-network
    restart: unless-stopped
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"
    healthcheck:
      test: ["CMD-SHELL", "kafka-topics --bootstrap-server localhost:29092 --list"]
      interval: 10s
      timeout: 10s
      retries: 5
      start_period: 40s

  telemetry-collector-go:
    build:
      context: ../../../../EdgeTelemetryCollectorGo
      dockerfile: Dockerfile
    container_name: telemetry-collector-go
    depends_on:
      kafka:
        condition: service_healthy
    ports:
      - "8011:8000"
    env_file:
      - ./configs/dmz.env
    environment:
      AUTH_MODE: jwt
      JWT_PUBLIC_KEYS_DIR: /app/keys/jwt
      KAFKA_BOOTSTRAP_SERVERS: kafka:29092
      KAFKA_TOPIC: telemetry-upsert
      KAFKA_ACKS: all
      KAFKA_RETRIES: 3
      API_HOST: 0.0.0.0
      API_PORT: 8000
      RATE_LIMIT_DEFAULT_REQUESTS: ${RATE_LIMIT_DEFAULT_REQUESTS:-100}
      RATE_LIMIT_DEFAULT_WINDOW: ${RATE_LIMIT_DEFAULT_WINDOW:-60}
    volumes:
      - ./secrets/jwt-public-keys:/app/keys/jwt:ro
    networks:
      - telemetry-go-network
    restart: unless-stopped
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  kafka-ui:
    image: provectuslabs/kafka-ui:latest
    container_name: telemetry-go-kafka-ui
    depends_on:
      kafka:
        condition: service_healthy
    ports:
      - "8090:8080"
    environment:
      KAFKA_CLUSTERS_0_NAME: telemetry-go-dmz
      KAFKA_CLUSTERS_0_BOOTSTRAPSERVERS: kafka:29092
      KAFKA_CLUSTERS_0_ZOOKEEPER: zookeeper:2181
    networks:
      - telemetry-go-network
    restart: unless-stopped
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"

volumes:
  kafka-data:
    driver: local
  zookeeper-data:
    driver: local
  zookeeper-logs:
    driver: local

networks:
  telemetry-go-network:
    driver: bridge
```

No Redis service — Collector-Go's Redis client will fail to connect (`REDIS_HOST` unset/unreachable) and fall back to in-memory rate limiting automatically, matching the Python DMZ's actual behavior (which never had Redis-backed rate limiting on this side either).

- [ ] **Step 2: Write `configs/dmz.env.example`**

```env
# ===== DMZ Environment (Go) =====
LOG_LEVEL=INFO

# ===== Kafka =====
KAFKA_BOOTSTRAP_SERVERS=kafka:29092
KAFKA_TOPIC=telemetry-upsert

# ===== Collector-Go Auth =====
AUTH_MODE=jwt
JWT_PUBLIC_KEYS_DIR=/app/keys/jwt

# ===== Rate Limiting =====
RATE_LIMIT_DEFAULT_REQUESTS=100
RATE_LIMIT_DEFAULT_WINDOW=60

# ===== API =====
API_HOST=0.0.0.0
```

- [ ] **Step 3: Write `secrets/README.md`**

```markdown
# DMZ Secrets

Two subdirectories, populated by `shared/scripts/` (see `shared/README.md`):

- `kafka-tls/` — the DMZ Kafka broker's JKS keystore + truststore
  (`kafka.server.keystore.jks`, `kafka.server.truststore.jks`), from
  `issue-kafka-server-cert.sh`.
- `jwt-public-keys/` — one or more `<kid>.public.pem` files, from
  `generate-jwt-keypair.sh`. Collector-Go loads every `*.public.pem` file in
  this directory at startup and matches incoming tokens by their `kid` header.

Never commit real files here — only this README is tracked; `.gitignore` at
the repo root blocks `*.jks` and `*.pem`.
```

- [ ] **Step 4: Create the (empty, gitignored-contents) secrets directories**

```bash
mkdir -p deployments/segmented/dmz/secrets/kafka-tls deployments/segmented/dmz/secrets/jwt-public-keys
touch deployments/segmented/dmz/secrets/kafka-tls/.gitkeep deployments/segmented/dmz/secrets/jwt-public-keys/.gitkeep
```

- [ ] **Step 5: Validate compose syntax**

```bash
cd deployments/segmented/dmz
cp configs/dmz.env.example configs/dmz.env
docker compose config --quiet
rm configs/dmz.env
```

Expected: no output (valid).

- [ ] **Step 6: Commit**

```bash
cd "EdgeTelemetryDeploymentGo"
git add deployments/segmented/dmz/docker-compose.yml deployments/segmented/dmz/configs/dmz.env.example deployments/segmented/dmz/secrets/
git commit -m "feat: add segmented DMZ deployment compose"
```

---

### Task 7: `deployments/segmented/dmz/Makefile`

**Files:**
- Create: `EdgeTelemetryDeploymentGo/deployments/segmented/dmz/Makefile`

- [ ] **Step 1: Write the Makefile**

```makefile
# Edge Telemetry (Go) - DMZ Deployment Makefile

.PHONY: help deploy down logs restart update status health config-check system-info cleanup test-deployment

MODE_NAME := segmented-dmz-go

help:
	@echo "Edge Telemetry (Go) - DMZ Mode"
	@echo "==============================="
	@echo ""
	@echo "  deploy       - Deploy DMZ services (Kafka, Collector-Go, Kafka UI)"
	@echo "  down         - Stop DMZ services"
	@echo "  logs         - View logs"
	@echo "  restart      - Restart services"
	@echo "  update       - Pull latest images and redeploy"
	@echo "  status       - Show service status"
	@echo "  health       - Check collector health"
	@echo "  config-check - Validate configuration"
	@echo "  system-info  - Display system information"
	@echo "  cleanup      - Clean up unused resources"
	@echo "  test-deployment - Send a JWT-authenticated sample event"

deploy:
	@echo "Deploying EdgeTelemetry Go DMZ..."
	@$(MAKE) config-check
	@$(MAKE) system-info
	docker compose up -d --build
	@sleep 60
	@$(MAKE) health
	@echo ""
	@echo "Service URLs:"
	@echo "  Collector API: http://localhost:8011"
	@echo "  Kafka UI:      http://localhost:8090"
	@echo "  Kafka (mTLS, external): <this host>:9097"

down:
	docker compose down

logs:
	docker compose logs -f

restart:
	docker compose restart
	@sleep 20
	@$(MAKE) health

update:
	docker compose pull
	docker compose up -d
	@sleep 20
	@$(MAKE) health

status:
	@docker compose ps --format "table {{.Name}}\t{{.Status}}\t{{.Ports}}" || echo "No services running"

health:
	@if curl -f -s http://localhost:8011/health > /dev/null 2>&1; then \
		echo "  Collector (8011): healthy"; \
		echo "  Response: $$(curl -s http://localhost:8011/health 2>/dev/null)"; \
	else \
		echo "  Collector (8011): unhealthy"; \
	fi

config-check:
	@echo "Validating configuration..."
	@if [ -f "configs/dmz.env" ]; then \
		echo "  Config file: found"; \
	else \
		echo "  Config file: NOT FOUND (configs/dmz.env)"; \
		exit 1; \
	fi
	@if [ -z "$$(ls -A secrets/jwt-public-keys 2>/dev/null | grep -v .gitkeep)" ]; then \
		echo "  JWT public keys: NONE FOUND in secrets/jwt-public-keys/ -- run shared/scripts/generate-jwt-keypair.sh"; \
		exit 1; \
	else \
		echo "  JWT public keys: found"; \
	fi
	@if [ -z "$$(ls -A secrets/kafka-tls 2>/dev/null | grep -v .gitkeep)" ]; then \
		echo "  Kafka TLS keystore: NONE FOUND in secrets/kafka-tls/ -- run shared/scripts/issue-kafka-server-cert.sh"; \
		exit 1; \
	else \
		echo "  Kafka TLS keystore: found"; \
	fi

system-info:
	@echo "System Information:"
	@echo "  OS: $$(lsb_release -d 2>/dev/null | cut -f2 || echo 'Unknown')"
	@echo "  Docker: $$(docker --version 2>/dev/null || echo 'Not installed')"

cleanup:
	@docker container prune -f
	@docker image prune -f
	@docker network prune -f

test-deployment:
	@echo "Requires a signed RS256 JWT with tenant_id, app_id, jti claims and a"
	@echo "kid matching a file in secrets/jwt-public-keys/. Example:"
	@echo ""
	@echo "curl -i -X POST http://localhost:8011/telemetry \\"
	@echo "  -H 'Content-Type: application/json' \\"
	@echo "  -H 'Authorization: Bearer edge_<your-signed-jwt>' \\"
	@echo "  -d '{\"device_id\":\"device-123\",\"events\":[{\"type\":\"page_view\"}]}'"
```

- [ ] **Step 2: Validate Makefile syntax**

```bash
cd deployments/segmented/dmz
make -n help
```

Expected: prints help text without errors.

- [ ] **Step 3: Commit**

```bash
cd "EdgeTelemetryDeploymentGo"
git add deployments/segmented/dmz/Makefile
git commit -m "feat: add segmented DMZ deployment Makefile"
```

---

### Task 8: `deployments/segmented/dmz/README.md`

**Files:**
- Create: `EdgeTelemetryDeploymentGo/deployments/segmented/dmz/README.md`

- [ ] **Step 1: Write the README**

```markdown
# Segmented Deployment — DMZ (Go)

Internet-facing half of the segmented topology: Kafka (dual-listener) +
Collector-Go (`AUTH_MODE=jwt`, RS256) + Kafka UI. No PostgreSQL, no Redis —
matches the Python DMZ topology exactly.

## Prerequisites

Provision secrets once via `shared/scripts/` (see `../../../shared/README.md`):

- `secrets/kafka-tls/` — server JKS keystore + truststore.
- `secrets/jwt-public-keys/` — one or more `<kid>.public.pem` files.

## Quick start

```bash
cp configs/dmz.env.example configs/dmz.env   # tweak FQDN / rate limits
DMZ_KAFKA_EXTERNAL_FQDN=dmz-kafka-go.example.com \
KAFKA_KEYSTORE_PASSWORD=<your-password> \
KAFKA_KEY_PASSWORD=<your-password> \
KAFKA_TRUSTSTORE_PASSWORD=<your-password> \
make deploy
```

## Service URLs

| Service | URL |
|---|---|
| Collector-Go | http://localhost:8011 |
| Kafka UI | http://localhost:8090 |
| Kafka (mTLS, external) | `<this-host>:9097` |

## JWT

RS256, verified against `<kid>.public.pem` files in `secrets/jwt-public-keys/`.
Tokens must carry `tenant_id`, `app_id`, `jti` claims and a `kid` header
matching one of the loaded key files. See
[`EdgeTelemetryCollectorGo/README.md`](../../../../EdgeTelemetryCollectorGo/README.md#mode-2-jwt-authentication)
for the full claim/header contract.
```

- [ ] **Step 2: Commit**

```bash
git add deployments/segmented/dmz/README.md
git commit -m "docs: add segmented DMZ deployment README"
```

---

## Phase 4 — segmented/bank

### Task 9: `deployments/segmented/bank/docker-compose.yml`, `configs/bank.env.example`, `secrets/README.md`

**Files:**
- Create: `EdgeTelemetryDeploymentGo/deployments/segmented/bank/docker-compose.yml`
- Create: `EdgeTelemetryDeploymentGo/deployments/segmented/bank/configs/bank.env.example`
- Create: `EdgeTelemetryDeploymentGo/deployments/segmented/bank/secrets/README.md`

**Interfaces:**
- Consumes: Kafka mTLS support, added to Processor-Go by `../../EdgeTelemetryProcessorGo/docs/plans/2026-08-17-kafka-mtls-support-plan.md` (`KAFKA_SECURITY_PROTOCOL=SSL`, `KAFKA_TLS_CA_CERT`, `KAFKA_TLS_CLIENT_CERT`, `KAFKA_TLS_CLIENT_KEY`); DMZ's external Kafka listener from Task 6 (port 9097).
- Produces: nothing consumed by later tasks — this is the last per-deployment service definition.

- [ ] **Step 1: Write `docker-compose.yml`**

```yaml
# EdgeTelemetry Go - Bank Deployment
# Internal services: Processor-Go only
# Processor connects to DMZ Kafka on port 9097 via mTLS

services:
  telemetry-processor-go:
    build:
      context: ../../../../EdgeTelemetryProcessorGo
      dockerfile: Dockerfile
    container_name: telemetry-processor-go
    ports:
      - "8012:8000"
    env_file:
      - ./configs/bank.env
    environment:
      KAFKA_BOOTSTRAP_SERVERS: ${DMZ_KAFKA_EXTERNAL_FQDN:-dmz-kafka-go.example.com}:9097
      KAFKA_SECURITY_PROTOCOL: SSL
      KAFKA_TLS_CA_CERT: /app/certs/kafka/ca.cert.pem
      KAFKA_TLS_CLIENT_CERT: /app/certs/kafka/client.cert.pem
      KAFKA_TLS_CLIENT_KEY: /app/certs/kafka/client.key.pem
      KAFKA_TOPIC: telemetry-upsert
      KAFKA_GROUP_ID: edge-telemetry-processor
      API_HOST: 0.0.0.0
      API_PORT: 8000
    volumes:
      - ./secrets/kafka-tls:/app/certs/kafka:ro
    networks:
      - telemetry-go-network
    restart: unless-stopped
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"
    healthcheck:
      test: ["CMD", "wget", "-qO-", "http://localhost:8000/health"]
      interval: 30s
      timeout: 10s
      retries: 3

networks:
  telemetry-go-network:
    driver: bridge
```

No Redis (Processor-Go doesn't use it) and no RUM Analytics API (out of
scope) — the bank side is a single container connecting outward to DMZ Kafka
and outward to external PostgreSQL.

- [ ] **Step 2: Write `configs/bank.env.example`**

```env
# ===== Bank Environment (Go) =====
LOG_LEVEL=INFO

# ===== Postgres (Processor-Go — discrete vars, no DATABASE_URL) =====
# Replace host/port/dbname/user/password with your real values.
POSTGRES_HOST=DB_HOST
POSTGRES_PORT=5432
POSTGRES_DATABASE=edge_db
POSTGRES_USER=USER
POSTGRES_PASSWORD=PASSWORD
POSTGRES_SSLMODE=require

# ===== Kafka (connects to DMZ externally via mTLS) =====
KAFKA_TOPIC=telemetry-upsert
KAFKA_GROUP_ID=edge-telemetry-processor

# ===== API =====
API_HOST=0.0.0.0
```

`KAFKA_BOOTSTRAP_SERVERS` and the `KAFKA_TLS_*` paths are set directly in
`docker-compose.yml`'s `environment:` block (they depend on the DMZ FQDN and
the fixed in-container cert mount paths), not in this file — matching the
pattern the Python bank config already uses for its Kafka mTLS settings.

- [ ] **Step 3: Write `secrets/README.md`**

```markdown
# Bank Secrets

- `kafka-tls/` — `ca.cert.pem`, `client.cert.pem`, `client.key.pem`, from
  `shared/scripts/issue-kafka-client-cert.sh`. PEM, not JKS — Processor-Go's
  Go TLS stack reads these directly.

Never commit real files here — only this README is tracked; `.gitignore` at
the repo root blocks `*.pem`.
```

- [ ] **Step 4: Create the secrets directory**

```bash
mkdir -p deployments/segmented/bank/secrets/kafka-tls
touch deployments/segmented/bank/secrets/kafka-tls/.gitkeep
```

- [ ] **Step 5: Validate compose syntax**

```bash
cd deployments/segmented/bank
cp configs/bank.env.example configs/bank.env
docker compose config --quiet
rm configs/bank.env
```

Expected: no output (valid).

- [ ] **Step 6: Commit**

```bash
cd "EdgeTelemetryDeploymentGo"
git add deployments/segmented/bank/docker-compose.yml deployments/segmented/bank/configs/bank.env.example deployments/segmented/bank/secrets/
git commit -m "feat: add segmented bank deployment compose"
```

---

### Task 10: `deployments/segmented/bank/Makefile`

**Files:**
- Create: `EdgeTelemetryDeploymentGo/deployments/segmented/bank/Makefile`

- [ ] **Step 1: Write the Makefile**

```makefile
# Edge Telemetry (Go) - Bank Deployment Makefile

.PHONY: help deploy down logs restart update status health config-check system-info cleanup

MODE_NAME := segmented-bank-go

help:
	@echo "Edge Telemetry (Go) - Bank Mode"
	@echo "================================"
	@echo ""
	@echo "  deploy       - Deploy bank services (Processor-Go)"
	@echo "  down         - Stop bank services"
	@echo "  logs         - View logs"
	@echo "  restart      - Restart services"
	@echo "  update       - Pull latest images and redeploy"
	@echo "  status       - Show service status"
	@echo "  health       - Check processor health"
	@echo "  config-check - Validate configuration"
	@echo "  system-info  - Display system information"
	@echo "  cleanup      - Clean up unused resources"

deploy:
	@echo "Deploying EdgeTelemetry Go Bank..."
	@$(MAKE) config-check
	@$(MAKE) system-info
	docker compose up -d --build
	@sleep 30
	@$(MAKE) health
	@echo ""
	@echo "Service URLs:"
	@echo "  Processor API: http://localhost:8012"

down:
	docker compose down

logs:
	docker compose logs -f

restart:
	docker compose restart
	@sleep 15
	@$(MAKE) health

update:
	docker compose pull
	docker compose up -d
	@sleep 15
	@$(MAKE) health

status:
	@docker compose ps --format "table {{.Name}}\t{{.Status}}\t{{.Ports}}" || echo "No services running"

health:
	@if curl -f -s http://localhost:8012/health > /dev/null 2>&1; then \
		echo "  Processor (8012): healthy"; \
		echo "  Response: $$(curl -s http://localhost:8012/health 2>/dev/null)"; \
	else \
		echo "  Processor (8012): unhealthy"; \
	fi

config-check:
	@echo "Validating configuration..."
	@if [ -f "configs/bank.env" ]; then \
		echo "  Config file: found"; \
		if grep -q "DB_HOST\|USER:PASSWORD\|placeholder\|example" configs/bank.env 2>/dev/null; then \
			echo "  Database config: contains placeholder values -- please update"; \
			exit 1; \
		else \
			echo "  Database config: customized"; \
		fi \
	else \
		echo "  Config file: NOT FOUND (configs/bank.env)"; \
		exit 1; \
	fi
	@if [ -z "$$(ls -A secrets/kafka-tls 2>/dev/null | grep -v .gitkeep)" ]; then \
		echo "  Kafka client cert: NONE FOUND in secrets/kafka-tls/ -- run shared/scripts/issue-kafka-client-cert.sh"; \
		exit 1; \
	else \
		echo "  Kafka client cert: found"; \
	fi

system-info:
	@echo "System Information:"
	@echo "  OS: $$(lsb_release -d 2>/dev/null | cut -f2 || echo 'Unknown')"
	@echo "  Docker: $$(docker --version 2>/dev/null || echo 'Not installed')"

cleanup:
	@docker container prune -f
	@docker image prune -f
	@docker network prune -f
```

- [ ] **Step 2: Validate Makefile syntax**

```bash
cd deployments/segmented/bank
make -n help
```

Expected: prints help text without errors.

- [ ] **Step 3: Commit**

```bash
cd "EdgeTelemetryDeploymentGo"
git add deployments/segmented/bank/Makefile
git commit -m "feat: add segmented bank deployment Makefile"
```

---

### Task 11: `deployments/segmented/bank/README.md`

**Files:**
- Create: `EdgeTelemetryDeploymentGo/deployments/segmented/bank/README.md`

- [ ] **Step 1: Write the README**

```markdown
# Segmented Deployment — Bank (Go)

Internal half of the segmented topology: Processor-Go only. Connects
outward to the DMZ's external Kafka listener over mTLS and outward to an
external PostgreSQL. No Redis, no RUM Analytics API — both out of scope for
this deployment repo (see the design spec, §2).

## Prerequisites

Provision the Kafka client certificate once via `shared/scripts/` (see
`../../../shared/README.md`):

- `secrets/kafka-tls/` — `ca.cert.pem`, `client.cert.pem`, `client.key.pem`.

## Quick start

```bash
cp configs/bank.env.example configs/bank.env   # set POSTGRES_* vars
DMZ_KAFKA_EXTERNAL_FQDN=dmz-kafka-go.example.com make deploy
```

`DMZ_KAFKA_EXTERNAL_FQDN` must match the FQDN the DMZ Kafka broker's server
certificate was issued for (see `deployments/segmented/dmz/README.md`).

## Service URLs

| Service | URL |
|---|---|
| Processor-Go | http://localhost:8012 |

## PostgreSQL

Never bundled in this compose file. Processor-Go has no `DATABASE_URL`
support — set the discrete `POSTGRES_HOST` / `POSTGRES_PORT` /
`POSTGRES_DATABASE` / `POSTGRES_USER` / `POSTGRES_PASSWORD` / `POSTGRES_SSLMODE`
vars in `configs/bank.env`.
```

- [ ] **Step 2: Commit**

```bash
git add deployments/segmented/bank/README.md
git commit -m "docs: add segmented bank deployment README"
```

---

## Phase 5 — Root files

### Task 12: Root `docker-compose.yml` (local dev)

**Files:**
- Create: `EdgeTelemetryDeploymentGo/docker-compose.yml`
- Create: `EdgeTelemetryDeploymentGo/.env.dev.example`

**Interfaces:**
- Consumes: `../EdgeTelemetryCollectorGo`, `../EdgeTelemetryProcessorGo` as build contexts.
- Produces: local dev stack, used by the root Makefile's `up`/`up-build`/`down`/`logs` targets (Task 13).

- [ ] **Step 1: Write `docker-compose.yml`**

```yaml
services:
  zookeeper:
    image: confluentinc/cp-zookeeper:7.4.0
    hostname: zookeeper
    container_name: telemetry-go-dev-zookeeper
    ports:
      - "2186:2181"
    environment:
      ZOOKEEPER_CLIENT_PORT: 2181
      ZOOKEEPER_TICK_TIME: 2000
    volumes:
      - zookeeper-data:/var/lib/zookeeper/data
      - zookeeper-logs:/var/lib/zookeeper/log
    networks:
      - telemetry-go-dev-network
    restart: unless-stopped

  kafka:
    image: confluentinc/cp-kafka:7.4.0
    hostname: kafka
    container_name: telemetry-go-dev-kafka
    depends_on:
      - zookeeper
    ports:
      - "9096:9092"
    environment:
      KAFKA_BROKER_ID: 1
      KAFKA_ZOOKEEPER_CONNECT: 'zookeeper:2181'
      KAFKA_LISTENER_SECURITY_PROTOCOL_MAP: PLAINTEXT:PLAINTEXT,PLAINTEXT_HOST:PLAINTEXT
      KAFKA_ADVERTISED_LISTENERS: PLAINTEXT://kafka:29092,PLAINTEXT_HOST://localhost:9096
      KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR: 1
      KAFKA_GROUP_INITIAL_REBALANCE_DELAY_MS: 0
      KAFKA_AUTO_CREATE_TOPICS_ENABLE: 'true'
    volumes:
      - kafka-data:/var/lib/kafka/data
    networks:
      - telemetry-go-dev-network
    restart: unless-stopped
    healthcheck:
      test: ["CMD-SHELL", "kafka-topics --bootstrap-server localhost:29092 --list"]
      interval: 10s
      timeout: 10s
      retries: 5
      start_period: 40s

  telemetry-redis:
    image: redis:7-alpine
    container_name: telemetry-go-dev-redis
    ports:
      - "6381:6379"
    volumes:
      - redis-data:/data
    networks:
      - telemetry-go-dev-network
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 30s
      timeout: 10s
      retries: 3

  telemetry-collector-go:
    build:
      context: ../EdgeTelemetryCollectorGo
      dockerfile: Dockerfile
    container_name: telemetry-go-dev-collector
    depends_on:
      kafka:
        condition: service_healthy
    ports:
      - "8011:8000"
    env_file:
      - ./.env.dev
    environment:
      AUTH_MODE: api_key
      DATABASE_SSL_MODE: disable
      KAFKA_BOOTSTRAP_SERVERS: kafka:29092
      KAFKA_TOPIC: telemetry-upsert
      KAFKA_ACKS: all
      KAFKA_RETRIES: 3
      REDIS_HOST: telemetry-redis
      REDIS_PORT: 6379
      API_HOST: 0.0.0.0
      API_PORT: 8000
    networks:
      - telemetry-go-dev-network
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  telemetry-processor-go:
    build:
      context: ../EdgeTelemetryProcessorGo
      dockerfile: Dockerfile
    container_name: telemetry-go-dev-processor
    depends_on:
      kafka:
        condition: service_healthy
    ports:
      - "8012:8000"
    env_file:
      - ./.env.dev
    environment:
      KAFKA_BOOTSTRAP_SERVERS: kafka:29092
      KAFKA_TOPIC: telemetry-upsert
      KAFKA_GROUP_ID: edge-telemetry-processor
      KAFKA_SECURITY_PROTOCOL: PLAINTEXT
      API_HOST: 0.0.0.0
      API_PORT: 8000
    networks:
      - telemetry-go-dev-network
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "wget", "-qO-", "http://localhost:8000/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  kafka-ui:
    image: provectuslabs/kafka-ui:latest
    container_name: telemetry-go-dev-kafka-ui
    depends_on:
      kafka:
        condition: service_healthy
    ports:
      - "8090:8080"
    environment:
      KAFKA_CLUSTERS_0_NAME: development-go
      KAFKA_CLUSTERS_0_BOOTSTRAPSERVERS: kafka:29092
      KAFKA_CLUSTERS_0_ZOOKEEPER: zookeeper:2181
    networks:
      - telemetry-go-dev-network
    restart: unless-stopped

volumes:
  kafka-data:
    driver: local
  zookeeper-data:
    driver: local
  zookeeper-logs:
    driver: local
  redis-data:
    driver: local

networks:
  telemetry-go-dev-network:
    driver: bridge
```

- [ ] **Step 2: Write `.env.dev.example`**

```env
# ===== Collector-Go =====
DATABASE_URL=postgresql://USER:PASSWORD@DB_HOST:5432/edge_db

# ===== Processor-Go =====
POSTGRES_HOST=DB_HOST
POSTGRES_PORT=5432
POSTGRES_DATABASE=edge_db
POSTGRES_USER=USER
POSTGRES_PASSWORD=PASSWORD
POSTGRES_SSLMODE=disable
```

- [ ] **Step 3: Validate compose syntax**

```bash
cp .env.dev.example .env.dev
docker compose config --quiet
rm .env.dev
```

Expected: no output (valid).

- [ ] **Step 4: Commit**

```bash
git add docker-compose.yml .env.dev.example
git commit -m "feat: add root local-dev compose"
```

---

### Task 13: Root `Makefile`

**Files:**
- Create: `EdgeTelemetryDeploymentGo/Makefile`

**Interfaces:**
- Consumes: `deployments/single-host/Makefile` (Task 4), `deployments/segmented/dmz/Makefile` (Task 7), `deployments/segmented/bank/Makefile` (Task 10), root `docker-compose.yml` (Task 12).

- [ ] **Step 1: Write the Makefile**

```makefile
# Edge Telemetry Go Deployment — root Makefile
#
# This Makefile has two roles:
#   1. Local dev: build/run the dev compose at the repo root, which builds
#      services from sibling source directories (../EdgeTelemetryCollectorGo,
#      ../EdgeTelemetryProcessorGo).
#   2. Delegation: forward `deploy-*` targets to the per-deployment Makefiles
#      under deployments/.
#
# On a deployment server (no sibling source dirs), dev targets are disabled
# and `make deploy` forwards to deployments/single-host/.

.PHONY: help build up up-build down logs restart \
        logs-collector logs-processor logs-redis logs-kafka \
        list-deployments deploy-single-host deploy-dmz deploy-bank \
        deploy health health-detailed status deploy-down deploy-logs deploy-restart \
        _check-dev-env

HAS_DEV_SOURCES := $(wildcard ../EdgeTelemetryCollectorGo/.)

help:
ifeq ($(HAS_DEV_SOURCES),)
	@echo ""
	@echo "  DEPLOYMENT SERVER detected (no sibling source dirs found)"
	@echo ""
	@echo "  Quick start:   make deploy"
	@echo "  View status:   make status"
	@echo "  View logs:     make deploy-logs"
	@echo "  Health check:  make health"
	@echo "  Stop services: make deploy-down"
	@echo ""
	@echo "Deployment targets:"
	@echo "  deploy              - Deploy single-host (all services on one machine)"
	@echo "  deploy-down         - Stop deployed services"
	@echo "  deploy-logs         - Tail deployed service logs"
	@echo "  deploy-restart      - Restart deployed services"
	@echo "  health              - Quick health check"
	@echo "  health-detailed     - Detailed health check"
	@echo "  status              - Show container status"
	@echo ""
	@echo "Other deployments:"
	@echo "  deploy-single-host  - Deploy single-host (same as 'deploy')"
	@echo "  deploy-dmz          - Deploy DMZ side of segmented topology"
	@echo "  deploy-bank         - Deploy bank side of segmented topology"
	@echo "  list-deployments    - Show all available deployments"
else
	@echo "Local development (builds from ../EdgeTelemetry*Go source dirs):"
	@echo "  build           - Build dev images"
	@echo "  up              - Start dev stack"
	@echo "  up-build        - Build then start dev stack"
	@echo "  down            - Stop dev stack"
	@echo "  logs            - Tail all dev logs"
	@echo "  restart         - Restart dev stack"
	@echo ""
	@echo "Per-service dev logs:"
	@echo "  logs-collector | logs-processor | logs-redis | logs-kafka"
	@echo ""
	@echo "Deployments (forward to deployments/<name>/Makefile):"
	@echo "  list-deployments    - Show available deployments"
	@echo "  deploy-single-host  - Deploy single-host (all services on one machine)"
	@echo "  deploy-dmz          - Deploy DMZ side of segmented topology"
	@echo "  deploy-bank         - Deploy bank side of segmented topology"
endif

_check-dev-env:
ifeq ($(HAS_DEV_SOURCES),)
	@echo "Error: Local dev requires sibling source directories:"
	@echo "  ../EdgeTelemetryCollectorGo"
	@echo "  ../EdgeTelemetryProcessorGo"
	@echo ""
	@echo "On a deployment server, use: make deploy"
	@exit 1
endif

build: _check-dev-env
	docker compose build

up: _check-dev-env
	docker compose up -d

up-build: _check-dev-env
	docker compose up -d --build

down:
	docker compose down

logs:
	docker compose logs -f

restart:
	docker compose restart

logs-collector:
	docker compose logs -f telemetry-collector-go

logs-processor:
	docker compose logs -f telemetry-processor-go

logs-redis:
	docker compose logs -f telemetry-redis

logs-kafka:
	docker compose logs -f kafka

list-deployments:
	@echo "Available deployments:"
	@echo "  single-host  - All services on one host"
	@echo "  segmented    - DMZ + Bank split (deploy DMZ and bank separately on their hosts)"
	@echo ""
	@echo "Usage:"
	@echo "  make deploy-single-host"
	@echo "  make deploy-dmz    # run on the DMZ host"
	@echo "  make deploy-bank   # run on the bank host"

deploy deploy-single-host:
	$(MAKE) -C deployments/single-host deploy

deploy-dmz:
	$(MAKE) -C deployments/segmented/dmz deploy

deploy-bank:
	$(MAKE) -C deployments/segmented/bank deploy

health:
	$(MAKE) -C deployments/single-host health

health-detailed:
	$(MAKE) -C deployments/single-host health-detailed

status:
	$(MAKE) -C deployments/single-host status

deploy-down:
	$(MAKE) -C deployments/single-host down

deploy-logs:
	$(MAKE) -C deployments/single-host logs

deploy-restart:
	$(MAKE) -C deployments/single-host restart
```

- [ ] **Step 2: Validate Makefile syntax**

```bash
make -n help
```

Expected: prints help text without errors — with sibling `EdgeTelemetryCollectorGo`/`EdgeTelemetryProcessorGo` present, it should print the "Local development" branch, not the "DEPLOYMENT SERVER detected" branch.

- [ ] **Step 3: Commit**

```bash
git add Makefile
git commit -m "feat: add root Makefile (dev targets + deployment delegation)"
```

---

### Task 14: `getstarted.sh`

**Files:**
- Create: `EdgeTelemetryDeploymentGo/getstarted.sh`

**Interfaces:**
- Consumes: nothing.
- Produces: a host-bootstrap script referenced from the root README (Task 16).

- [ ] **Step 1: Read the Python `getstarted.sh` for structure**

```bash
head -n 60 "../EdgeTelemetryDeployment/getstarted.sh"
```

Note which sections are Python-specific (any `pip`/`python3` install steps) versus generic host setup (Docker install, directory creation, firewall notes) — only the generic sections carry over.

- [ ] **Step 2: Write `getstarted.sh`**

```bash
#!/bin/bash
# EdgeTelemetry Go — Ubuntu host bootstrap
# Installs Docker + Docker Compose, verifies Go toolchain availability (for
# local dev only — not required on a pure deployment server), and prepares
# the /opt/edge-telemetry-go data directories used by the single-host Makefile.

set -euo pipefail

echo "EdgeTelemetry Go — host bootstrap"
echo "=================================="

if ! command -v docker &> /dev/null; then
    echo "[1/4] Installing Docker..."
    curl -fsSL https://get.docker.com | sh
    sudo usermod -aG docker "$USER"
    echo "  Docker installed. You may need to log out and back in for group membership to apply."
else
    echo "[1/4] Docker already installed: $(docker --version)"
fi

if ! docker compose version &> /dev/null; then
    echo "ERROR: Docker Compose v2 plugin not found. Install it before continuing."
    exit 1
else
    echo "[2/4] Docker Compose already installed: $(docker compose version)"
fi

if command -v go &> /dev/null; then
    echo "[3/4] Go toolchain found: $(go version) (only needed for local dev / building from source)"
else
    echo "[3/4] Go toolchain not found (only needed for local dev / building from source, not for deployment)"
fi

echo "[4/4] Preparing data directories..."
sudo mkdir -p /opt/edge-telemetry-go/data/{kafka,zookeeper,redis}
sudo mkdir -p /opt/edge-telemetry-go/logs/{zookeeper,redis}
sudo chown -R 1000:1000 /opt/edge-telemetry-go/

echo ""
echo "Bootstrap complete."
echo ""
echo "Next steps:"
echo "  Single-host: cd deployments/single-host && cp configs/single-host.env.example configs/single-host.env && make deploy"
echo "  Segmented:   see shared/README.md for CA/TLS/JWT provisioning, then deploy dmz/ and bank/ separately."
```

- [ ] **Step 3: Make executable and validate syntax**

```bash
chmod +x getstarted.sh
bash -n getstarted.sh
```

Expected: no output (syntax OK).

- [ ] **Step 4: Commit**

```bash
git add getstarted.sh
git commit -m "feat: add host bootstrap script"
```

---

### Task 15: `.github/workflows/validate.yml`

**Files:**
- Create: `EdgeTelemetryDeploymentGo/.github/workflows/validate.yml`

- [ ] **Step 1: Write the workflow**

```yaml
name: Validate

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  compose-lint:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Validate root dev compose
        run: docker compose -f docker-compose.yml config --quiet
      - name: Validate single-host compose
        run: |
          cp deployments/single-host/configs/single-host.env.example deployments/single-host/configs/single-host.env
          docker compose -f deployments/single-host/docker-compose.yml --project-directory deployments/single-host config --quiet
      - name: Validate segmented DMZ compose
        run: |
          cp deployments/segmented/dmz/configs/dmz.env.example deployments/segmented/dmz/configs/dmz.env
          docker compose -f deployments/segmented/dmz/docker-compose.yml --project-directory deployments/segmented/dmz config --quiet
      - name: Validate segmented bank compose
        run: |
          cp deployments/segmented/bank/configs/bank.env.example deployments/segmented/bank/configs/bank.env
          docker compose -f deployments/segmented/bank/docker-compose.yml --project-directory deployments/segmented/bank config --quiet

  secret-scan:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Fail if real secrets are tracked
        run: |
          if git ls-files | grep -E '\.(pem|key|jks|p12)$'; then
            echo "Tracked secret-shaped files found — see above."
            exit 1
          fi
          if git ls-files | grep -E '(^|/)(single-host|dmz|bank)\.env$'; then
            echo "Tracked real .env file found — only .env.example files should be committed."
            exit 1
          fi

  shellcheck:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Run shellcheck on shared scripts
        run: |
          sudo apt-get update && sudo apt-get install -y shellcheck
          shellcheck shared/scripts/*.sh getstarted.sh
```

- [ ] **Step 2: Commit**

```bash
git add .github/workflows/validate.yml
git commit -m "ci: add compose-lint, secret-scan, shellcheck workflow"
```

---

### Task 16: Finalize root `README.md` and `CLAUDE.md`

**Files:**
- Modify: `EdgeTelemetryDeploymentGo/README.md`
- Modify: `EdgeTelemetryDeploymentGo/CLAUDE.md`

- [ ] **Step 1: Write the full `README.md`**

```markdown
# EdgeTelemetry Deployment (Go)

Production deployment for the Go telemetry pipeline (Collector-Go → Kafka →
Processor-Go → PostgreSQL). Mirrors [`EdgeTelemetryDeployment`](../EdgeTelemetryDeployment)
(the Python deployment repo) as closely as the Go services' capabilities
allow. Full design rationale: [`docs/2026-08-17-edge-telemetry-deployment-go-design.md`](docs/2026-08-17-edge-telemetry-deployment-go-design.md).

There are **two supported deployments**:

| Deployment | When to use | Auth |
|------------|-------------|------|
| **single-host** | Dev, staging, or any environment without a network-segmentation requirement. Everything on one box. | None on the wire, API key checked against Postgres |
| **segmented** | Production with a DMZ/internal split. Collector-Go and Kafka live in the DMZ; Processor-Go lives in the bank network. The two zones talk over Kafka:9097 with mTLS. | RS256 JWT (DMZ holds the public key, bank holds the private key) |

```
deployments/
├── single-host/                # Deployment 1: everything on one host
└── segmented/                  # Deployment 2: DMZ + Bank
    ├── dmz/                    #   Internet-facing (Collector-Go + Kafka)
    └── bank/                   #   Internal (Processor-Go)
```

## Quick start

### Single-host

```bash
cd deployments/single-host
cp configs/single-host.env.example configs/single-host.env   # set DATABASE_URL and POSTGRES_*
make deploy
```

See [`deployments/single-host/README.md`](deployments/single-host/README.md).

### Segmented

Provision the keys once (CA, Kafka mTLS server+client certs, RS256 JWT
keypair) — see [`shared/README.md`](shared/README.md).

Then on each host:

```bash
# DMZ host
cd deployments/segmented/dmz
cp configs/dmz.env.example configs/dmz.env
make deploy

# Bank host
cd deployments/segmented/bank
cp configs/bank.env.example configs/bank.env
make deploy
```

See [`deployments/segmented/dmz/README.md`](deployments/segmented/dmz/README.md) and
[`deployments/segmented/bank/README.md`](deployments/segmented/bank/README.md).

## Architecture

```
single-host                        segmented (production)
─────────────                      ─────────────────────────────────────
                                       DMZ                  Bank network
Client → Collector-Go               Client → Collector-Go
            ↓                                  ↓
          Kafka                              Kafka  ── mTLS :9097 ──→  Processor-Go → DB
            ↓
        Processor-Go → DB
```

| Component | Port | Single-host | Segmented |
|-----------|------|-------------|-----------|
| Collector-Go | 8011 | ✓ | DMZ |
| Processor-Go | 8012 | ✓ | Bank |
| Redis | 6381 | ✓ | — |
| Kafka (internal) | 29092 | ✓ | DMZ |
| Kafka (mTLS, external) | 9097 | — | DMZ |
| Kafka UI | 8090 | ✓ | DMZ |
| Zookeeper | 2181 | ✓ | DMZ |

Not present in this deployment repo (Python-only for now): RUM Analytics API,
portal frontend. Added here once each is rewritten in Go.

## Security

- **JWT** — RS256, segmented mode only. Bank holds private key (signs); DMZ
  holds public key(s) (verifies), one `<kid>.public.pem` file per active key.
- **Kafka mTLS** — required between DMZ Kafka (port 9097, external listener)
  and the bank-side processor; both sides issued from a shared private CA.
  Broker side is JKS (Java/Confluent); client side (Processor-Go) is PEM.
- **Secrets** — never committed. `.gitignore` blocks `*.pem`, `*.key`,
  `*.jks`, `*.p12`, and real `.env` files. Only `.env.example` files are
  tracked. A pre-commit hook (`shared/scripts/install-pre-commit-hook.sh`)
  backs this up.

Generate everything via `shared/scripts/` — see [`shared/README.md`](shared/README.md).

## Local development

If you're iterating on a service's source (sibling dirs
`../EdgeTelemetryCollectorGo`, `../EdgeTelemetryProcessorGo`), the root
`docker-compose.yml` builds those services from source.

```bash
cp .env.dev.example .env.dev    # then edit POSTGRES_*/DATABASE_URL
make up-build                   # build + start dev stack
make logs                       # tail
make down                       # stop
```

This is **not** a deployment mode — it's a local build/run convenience. For
production-shaped runs, use the `deployments/` Makefiles.

## Root Makefile shortcuts

```bash
make list-deployments    # Show available deployments
make deploy-single-host  # Forward to deployments/single-host
make deploy-dmz          # Forward to deployments/segmented/dmz
make deploy-bank         # Forward to deployments/segmented/bank
```

## System requirements

- Docker 27.5+ and Docker Compose v2
- 2 GB RAM minimum (single-host — the Go services have a much smaller
  footprint than the Python stack); per-host requirements similar for
  segmented
- 10 GB free disk
- Segmented mode: DNS for the DMZ Kafka FQDN, firewall allowing bank →
  DMZ:9097

## Support

Each deployment has its own README with troubleshooting, health checks, and
command reference. For shared scripts (CA / TLS / JWT setup), see
[`shared/README.md`](shared/README.md).
```

- [ ] **Step 2: Write the full `CLAUDE.md`**

```markdown
# CLAUDE.md - EdgeTelemetry Deployment (Go)

## Project Overview

EdgeTelemetry Deployment (Go) is a containerized system for collecting and
processing real-time telemetry from mobile/edge applications, using the Go
reimplementations of the collector and processor. The pipeline is:

```
Client → Collector-Go → Kafka → Processor-Go → PostgreSQL
```

Mirrors [`EdgeTelemetryDeployment`](../EdgeTelemetryDeployment) (the Python
deployment repo) — same structure, same Makefile target names, same two
topologies — adapted only where the Go services' capabilities require a
difference. Full rationale: `docs/2026-08-17-edge-telemetry-deployment-go-design.md`.

## Deployments

- **single-host** — everything on one host. `AUTH_MODE=api_key`.
- **segmented** — split across two network zones:
  - `segmented/dmz/` — internet-facing: Kafka (dual listener) + Collector-Go + Kafka UI
  - `segmented/bank/` — internal: Processor-Go only
  - Cross-zone traffic flows over Kafka:9097 with mTLS. JWT uses RS256 (DMZ
    holds public key, bank holds private).

## Architecture

| Component | Port | Purpose |
|-----------|------|---------|
| Collector-Go | 8011 → 8000 | REST API for telemetry ingestion |
| Processor-Go | 8012 → 8000 | Kafka consumer; writes to PostgreSQL |
| Kafka (internal) | 29092 | Plaintext, in-cluster |
| Kafka (mTLS) | 9097 | External SSL (segmented mode only) |
| Zookeeper | 2181 | Kafka coordination |
| Redis | 6381 | API-key cache + rate-limit counters (single-host only) |
| Kafka UI | 8090 | Kafka monitoring |

## Tech Stack

- **Backend:** Go 1.22 (Collector-Go: Echo; Processor-Go: net/http via Echo)
- **Message broker:** Apache Kafka 7.4.0 + Zookeeper
- **Kafka client:** `segmentio/kafka-go`
- **Database:** PostgreSQL, external, never bundled
- **Cache:** Redis 7-alpine (single-host only)
- **Containerization:** Docker + Docker Compose
- **Automation:** Make, Bash

## Repository Structure

```
├── deployments/
│   ├── single-host/
│   │   ├── docker-compose.yml
│   │   ├── Makefile
│   │   └── configs/single-host.env(.example)
│   └── segmented/
│       ├── dmz/
│       │   ├── docker-compose.yml
│       │   ├── Makefile
│       │   ├── configs/dmz.env(.example)
│       │   └── secrets/{kafka-tls, jwt-public-keys}
│       └── bank/
│           ├── docker-compose.yml
│           ├── Makefile
│           ├── configs/bank.env(.example)
│           └── secrets/kafka-tls
├── shared/
│   ├── scripts/        # CA / TLS / JWT / pre-commit hook
│   └── README.md
├── docker-compose.yml   # Local-dev: builds from sibling source dirs
├── Makefile             # Dev targets + deployment delegation
├── getstarted.sh        # Ubuntu host bootstrap
├── .github/workflows/validate.yml
└── .gitignore
```

Source code for individual services lives in sibling directories (used by the
root `docker-compose.yml` for local dev):
- `../EdgeTelemetryCollectorGo`
- `../EdgeTelemetryProcessorGo`

## Common Commands

```bash
# From repo root
make list-deployments
make deploy-single-host
make deploy-dmz
make deploy-bank

# Local dev
make up-build
make logs
make down

# Inside any deployment dir
make deploy
make down
make health
make config-check
```

## Configuration

Each deployment owns its own env file. Note Processor-Go has **no
`DATABASE_URL`** support — it only reads discrete `POSTGRES_HOST` /
`POSTGRES_PORT` / `POSTGRES_DATABASE` / `POSTGRES_USER` / `POSTGRES_PASSWORD` /
`POSTGRES_SSLMODE`. Collector-Go uses `DATABASE_URL` (API-key mode only).

Real env files are gitignored — only `.env.example` files are committed.

## Security Scripts

Located in `shared/scripts/`:
- `generate-ca.sh` — private CA for Kafka mTLS (unchanged from Python)
- `issue-kafka-server-cert.sh` — Kafka server cert, JKS (DMZ, unchanged from Python)
- `issue-kafka-client-cert.sh` — Kafka client cert, **PEM** (bank — rewritten for Go's `crypto/tls`)
- `generate-jwt-keypair.sh` — RS256 keypair, public key named `<kid>.public.pem` (adapted from Python)
- `verify-key-fingerprint.sh` — compare JWT key fingerprints across DMZ/bank
- `install-pre-commit-hook.sh` — installs hook blocking `*.pem`/`*.jks`/etc.

## Prerequisite Code Changes (not in this repo)

- `EdgeTelemetryCollectorGo`: RS256 JWT verification added alongside ES256
  (`internal/auth/jwt.go`). Both algorithms work simultaneously, selected per
  key file.
- `EdgeTelemetryProcessorGo`: Kafka mTLS client support added
  (`internal/config/config.go`, `internal/kafka/consumer.go`) — new
  `KAFKA_SECURITY_PROTOCOL` / `KAFKA_TLS_CA_CERT` / `KAFKA_TLS_CLIENT_CERT` /
  `KAFKA_TLS_CLIENT_KEY` env vars, `PLAINTEXT` default.

## Database

PostgreSQL `edge_db`, same schema as the Python deployment (`rum_api_keys`,
`rum_apps`, `rum_devices`, `rum_users`, `rum_sessions`) — this repo doesn't
change the schema, only which services connect to it.

## GitHub

Repository: (set once created — not yet pushed)
```

- [ ] **Step 3: Commit**

```bash
git add README.md CLAUDE.md
git commit -m "docs: finalize root README and CLAUDE.md"
```

---

## Phase 6 — End-to-end verification

### Task 17: Single-host smoke test

**Files:** none created — this task exercises the stack built in Tasks 5–7.

**Interfaces:**
- Consumes: everything from Phase 3.
- Produces: confidence that the single-host topology actually works before calling the plan done.

- [ ] **Step 1: Start an ephemeral local Postgres for the smoke test**

(Deployment compose files never bundle Postgres, matching Python — for this smoke test only, run one ad hoc.)

```bash
docker run -d --name edge-go-smoke-postgres \
  -e POSTGRES_DB=edge_db -e POSTGRES_USER=postgres -e POSTGRES_PASSWORD=postgres \
  -p 5434:5432 postgres:16-alpine
sleep 5
docker exec edge-go-smoke-postgres psql -U postgres -d edge_db -c \
  "CREATE TABLE IF NOT EXISTS rum_api_keys (id uuid primary key default gen_random_uuid(), tenant_id text, user_id text, api_key_id text unique, api_key_hash text, api_created_at timestamptz default now(), api_expires_at timestamptz, api_revoked_at timestamptz);"
```

- [ ] **Step 2: Point the single-host config at it and deploy**

```bash
cd deployments/single-host
cp configs/single-host.env.example configs/single-host.env
```

Edit `configs/single-host.env`, replacing the `DATABASE_URL`/`POSTGRES_*`
placeholders with `host.docker.internal:5434` (or the Docker bridge gateway
IP on Linux), user `postgres`, password `postgres`, db `edge_db`.

```bash
docker compose up -d --build
```

- [ ] **Step 3: Wait for health, then verify both services are healthy**

```bash
sleep 60
curl -f http://localhost:8011/health
curl -f http://localhost:8012/health
```

Expected: both return HTTP 200 with a JSON body containing `"status":"healthy"` (Collector-Go's response also reports `kafka`/`redis` sub-status; Processor-Go's shape is whatever `handler.Health` in `EdgeTelemetryProcessorGo/cmd/server` returns — inspect it if the assertion above needs adjusting to match the real field names).

- [ ] **Step 4: Send a test telemetry event and confirm it lands in Kafka**

```bash
curl -i -X POST http://localhost:8011/telemetry \
  -H "Content-Type: application/json" \
  -d '{"device_id":"smoke-test-device","events":[{"type":"smoke_test"}]}'
```

Expected: HTTP 200 with `"status":"success"` and a `metadata.offset` field.

```bash
docker compose logs --tail=20 telemetry-processor-go
```

Expected: a log line showing the processor consumed and processed the message (`"processed kafka message"` per the `slog.Info` call in `consumer.go`).

- [ ] **Step 5: Confirm the row landed in Postgres**

```bash
docker exec edge-go-smoke-postgres psql -U postgres -d edge_db -c "SELECT device_id FROM rum_devices WHERE device_id = 'smoke-test-device';"
```

Expected: one row returned. (If `rum_devices`/other RUM tables don't exist yet in this ad hoc Postgres, create them first per `EdgeTelemetryDeployment/DATABASE_SCHEMA_GUIDE.md`'s schema — that guide is the source of truth for the full RUM table set, unchanged by this deployment repo.)

- [ ] **Step 6: Tear down the smoke test**

```bash
docker compose down
rm configs/single-host.env
docker rm -f edge-go-smoke-postgres
```

- [ ] **Step 7: Record the result**

If all checks in Steps 3–5 passed, the single-host topology is verified end-to-end. No commit needed for this task — it's a verification gate, not a code change. Note the result (pass/fail + any deviations you had to make, e.g. actual health-response field names) back to the plan owner before moving on to segmented-mode verification, which requires real TLS/JWT material and is out of scope for an automated smoke test — do that manually per `deployments/segmented/dmz/README.md` and `deployments/segmented/bank/README.md` once both hosts are provisioned.

---

## Summary

17 tasks across 7 phases: repo scaffold, shared secrets tooling, three deployment definitions (single-host, DMZ, bank) each with compose + Makefile + README, root dev compose + Makefile + bootstrap + CI, and an end-to-end smoke test. Every task ends in a commit except the final verification task, which is a manual gate. The two prerequisite code changes (RS256 JWT in Collector-Go, Kafka mTLS in Processor-Go) are tracked and executed as separate plans in their own repos — see "Prerequisites" above.
