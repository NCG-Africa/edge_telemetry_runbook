# EdgeTelemetryDeploymentGo — Design Spec

Status: Approved for planning
Date: 2026-08-17
Owner: Jonathan Ebhota

## 1. Purpose

`EdgeTelemetryDeployment` is the production deployment repo for the **Python** telemetry
pipeline (Collector → Kafka → Processor → PostgreSQL, plus a Redis-backed RUM Analytics
API and a portal frontend). Two Go services now exist that reimplement part of that
pipeline — `EdgeTelemetryCollectorGo` and `EdgeTelemetryProcessorGo` — but there is no
deployment repo for them. Operators currently have no supported way to run the Go
services in a single-host or DMZ/bank-segmented production topology the way they can
with the Python stack.

This spec defines `EdgeTelemetryDeploymentGo`: a new sibling repo that mirrors
`EdgeTelemetryDeployment` as closely as the underlying services allow — same directory
layout, same Makefile target names and behavior, same two topologies, same security
model — adapted only where the Go services' actual capabilities require a difference.

## 2. Scope

**In scope:**
- New repo `EdgeTelemetryDeploymentGo`, sibling to `EdgeTelemetryCollectorGo`,
  `EdgeTelemetryProcessorGo`, and `EdgeTelemetryDeployment`.
- `single-host` topology: Collector-Go + Processor-Go + Kafka + Zookeeper + Redis +
  Kafka UI, all on one host, `AUTH_MODE=api_key`.
- `segmented` topology: `dmz/` (Collector-Go + Kafka dual-listener + Kafka UI,
  `AUTH_MODE=jwt`) and `bank/` (Processor-Go only), connected over Kafka mTLS.
- Shared secrets tooling (`shared/scripts/`) adapted from the Python repo: CA
  generation, Kafka mTLS cert issuance, JWT keypair generation, fingerprint
  verification, pre-commit secret-blocking hook.
- Root Makefile with the same dual role as Python's: local dev (build from sibling
  Go source dirs) + delegation to per-deployment Makefiles.
- A small prerequisite change to `EdgeTelemetryCollectorGo`: add RS256 JWT
  verification (see §5).
- A small prerequisite change to `EdgeTelemetryProcessorGo`: add Kafka mTLS
  client support (see §5a).

**Out of scope (explicitly deferred):**
- RUM Analytics API and the portal frontend. Neither has a Go implementation yet.
  When they're converted to Go, this deployment repo gains a third/fourth service
  and picks up Redis on the bank side (mirroring Python's bank topology) — not
  addressed by this spec.
- CI/CD pipeline changes beyond mirroring the Python repo's `validate.yml` shape.

## 3. Repository Layout

```
EdgeTelemetryDeploymentGo/
├── deployments/
│   ├── single-host/
│   │   ├── docker-compose.yml
│   │   ├── Makefile
│   │   ├── README.md
│   │   └── configs/single-host.env(.example)
│   └── segmented/
│       ├── dmz/
│       │   ├── docker-compose.yml
│       │   ├── Makefile
│       │   ├── README.md
│       │   ├── configs/dmz.env(.example)
│       │   └── secrets/{kafka-tls, jwt-public-keys}
│       └── bank/
│           ├── docker-compose.yml
│           ├── Makefile
│           ├── README.md
│           ├── configs/bank.env(.example)
│           └── secrets/{kafka-tls, jwt-signing-keys}
├── shared/
│   ├── scripts/
│   │   ├── generate-ca.sh                     (unchanged from Python)
│   │   ├── issue-kafka-server-cert.sh          (unchanged from Python — broker is still Java/Confluent, needs JKS)
│   │   ├── issue-kafka-client-cert.sh          (adapted — see §5a; outputs PEM instead of JKS)
│   │   ├── generate-jwt-keypair.sh             (adapted — see §5)
│   │   ├── verify-key-fingerprint.sh           (unchanged from Python)
│   │   ├── install-pre-commit-hook.sh          (unchanged from Python)
│   │   ├── pre-commit-hook.sh                  (unchanged from Python)
│   │   └── test-mode2-integration.sh           (adapted for Go env vars)
│   └── README.md
├── docker-compose.yml            # local dev: builds from ../EdgeTelemetryCollectorGo,
│                                  # ../EdgeTelemetryProcessorGo
├── Makefile                      # dev targets + deploy-* delegation (dual role)
├── getstarted.sh                 # host bootstrap, adapted
├── .github/workflows/validate.yml
├── CLAUDE.md
├── README.md
└── .gitignore                    # blocks *.pem, *.key, *.jks, *.p12, real .env files
```

This is a 1:1 structural mirror of `EdgeTelemetryDeployment`, minus the
`telemetry-rum-analytics` and `edgerumportal` services and their associated secrets
directories (`jwt-signing-keys` moves to `bank/secrets/kafka-tls`'s sibling only where
still needed — see §5 for where JWT signing keys actually live).

## 4. Service Composition Per Topology

### single-host

| Container | Image/build | Purpose |
|---|---|---|
| `zookeeper` | `confluentinc/cp-zookeeper:7.4.0` | Kafka coordination |
| `kafka` | `confluentinc/cp-kafka:7.4.0` | Message broker, plaintext internal |
| `telemetry-redis` | `redis:7-alpine` | API key cache + rate-limit counters for Collector-Go |
| `telemetry-collector-go` | `mktowett/edge_telemetry_collector_go:latest` (or built) | Ingestion, `AUTH_MODE=api_key` |
| `telemetry-processor-go` | `mktowett/edge_telemetry_processor_go:latest` (or built) | Kafka consumer → PostgreSQL |
| `kafka-ui` | `provectuslabs/kafka-ui:latest` | Kafka monitoring |

PostgreSQL remains external (matches Python exactly — never bundled in compose,
`DATABASE_URL` points at a managed/external instance).

### segmented / dmz

| Container | Purpose |
|---|---|
| `zookeeper` | Kafka coordination |
| `kafka` | Dual-listener: `INTERNAL` plaintext for collector, `EXTERNAL` SSL/mTLS on the segmented port for the bank processor |
| `telemetry-collector-go` | Ingestion, `AUTH_MODE=jwt`, verifies RS256 tokens against mounted public keys |
| `kafka-ui` | Kafka monitoring |

No Redis service — matches the Python DMZ exactly. Collector-Go's Redis client will
fail to connect and the service falls back to in-memory rate limiting automatically
(documented, existing behavior in Collector-Go). This is a known, accepted parity
gap: shared/cross-replica rate-limit state isn't available in this topology, same as
it implicitly wasn't in the Python DMZ (which never had Redis-backed rate limiting
here either).

### segmented / bank

| Container | Purpose |
|---|---|
| `telemetry-processor-go` | Kafka consumer via mTLS from DMZ Kafka, writes to external PostgreSQL |

No Redis (Processor-Go doesn't use Redis at all). No RUM Analytics API (out of
scope). This makes the Go bank side considerably smaller than Python's — a single
container connecting outward to DMZ Kafka and outward to external PostgreSQL.

## 5. Security Model

**Kafka mTLS (broker side)** — unchanged from Python. Same CA (`generate-ca.sh`),
same server-side JKS keystore/truststore issuance (`issue-kafka-server-cert.sh`),
because the Kafka broker is still the Confluent/Java image regardless of which
language produces/consumes messages. This layer requires no adaptation.

**Kafka mTLS (client side) — see §5a.** Processor-Go's Kafka client
(`segmentio/kafka-go`) has no TLS support today and cannot consume JKS keystores
even if it did, so this side is not a straight port.

**JWT (segmented mode)** — algorithm matches Python exactly: **RS256**, bank holds
the private (signing) key, DMZ holds the public (verification) key(s).

This requires a **prerequisite change to `EdgeTelemetryCollectorGo`**:
`internal/auth/jwt.go` currently verifies only ES256. Add RS256 verification,
selected by matching `alg` in the JWT header (or by a config toggle, whichever the
Collector-Go team prefers at implementation time) — same claim contract as today
(`tenant_id`, `app_id`, `jti` required; same Kafka header propagation on success).
Key *lookup* stays on Collector-Go's existing convention: files named
`<kid>.public.pem` under `JWT_PUBLIC_KEYS_DIR`, matched against the JWT header's
`kid`. This is a small, scoped change — no new dependencies, no change to the auth
result/error types other than accepting a second algorithm.

`shared/scripts/generate-jwt-keypair.sh` is adapted from Python's version:
- Keeps RSA 2048-bit key generation (`openssl genpkey -algorithm RSA`), producing
  RS256-compatible keys — this part is unchanged from Python.
- Changes the **public key output filename** from flat `public.pem` to
  `<kid>.public.pem`, where `<kid>` is either passed via `--kid` or derived from the
  key's SHA-256 fingerprint, to match Collector-Go's lookup convention.
- Private key stays `private.pem` (single active signing key on the bank side, no
  `kid` needed for the signer).
- Same fingerprint-printing behavior at the end, same next-steps guidance, updated
  to reference `deployments/segmented/dmz/secrets/jwt-public-keys/<kid>.public.pem`.

**Secrets hygiene** — unchanged from Python: `.gitignore` blocks `*.pem`, `*.key`,
`*.jks`, `*.p12`, and real `.env` files. Only `.env.example` files are tracked. The
pre-commit hook (`install-pre-commit-hook.sh`) is carried over verbatim.

## 5a. Prerequisite: Kafka mTLS Client Support in `EdgeTelemetryProcessorGo`

**Code change** (`internal/config/config.go` + wherever the Kafka reader is
constructed): add TLS configuration, gated by a new `KAFKA_SECURITY_PROTOCOL`
env var (`PLAINTEXT` default, `SSL` for mTLS — same variable name Python's
`bank.env.example` already uses, for consistency of vocabulary even though the
underlying client library differs). When `SSL`:

- `KAFKA_TLS_CA_CERT` — path to the CA certificate (PEM) that signed the DMZ
  Kafka broker's server certificate.
- `KAFKA_TLS_CLIENT_CERT` — path to this client's certificate (PEM).
- `KAFKA_TLS_CLIENT_KEY` — path to this client's private key (PEM).

These build a `*tls.Config{Certificates: [...], RootCAs: pool}` passed into a
`kafka.Dialer` used by the `segmentio/kafka-go` `Reader`. No other behavior
changes — plaintext mode (single-host) is unaffected.

**Cert issuance script adaptation**: `shared/scripts/issue-kafka-client-cert.sh`
is rewritten for this repo to skip `keytool`/JKS entirely and issue a PEM
client cert directly:

```bash
openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:2048 -out client.key.pem
openssl req -new -key client.key.pem -subj "/CN=$CLIENT_NAME/O=EdgeTelemetry/OU=Bank" -out client.csr
openssl x509 -req -in client.csr -CA "$CA_CERT" -CAkey "$CA_KEY" -CAcreateserial -out client.cert.pem -days "$VALIDITY_DAYS"
```

Output: `client.cert.pem`, `client.key.pem`, plus a copy of the CA cert
(`ca.cert.pem`) for `KAFKA_TLS_CA_CERT` — all copied to
`deployments/segmented/bank/secrets/kafka-tls/`. The broker-side script
(`issue-kafka-server-cert.sh`, JKS-based) is untouched since the broker is
unaffected by this change.

## 6. Ports

Chosen to be **distinct from both** the Python deployment's ports and each Go
service's own standalone local-dev compose ports, so all three stacks (Python
deployment, Go deployment, individual Go service dev compose) can run concurrently
on the same host without collision.

| Component | Python deployment | Go service's own dev compose | **EdgeTelemetryDeploymentGo** |
|---|---|---|---|
| Collector | 8001 | 8004 | **8011** |
| Processor | 8002 | 8005 | **8012** |
| Redis (single-host) | 6379 | 6380 | **6381** |
| Kafka UI | 8080 | 8083 / 8084 | **8090** |
| Kafka mTLS external (segmented) | 9093 | n/a | **9097** |
| Zookeeper | 2181/2182 | 2184/2185 | **2186** |

Internal container ports are unchanged (`8000` for both Go services, matching their
existing Dockerfiles/healthchecks).

## 7. Configuration

Same per-deployment env-file ownership pattern as Python:

- `deployments/single-host/configs/single-host.env` — Kafka, Redis,
  `AUTH_MODE=api_key`, Collector-Go's `DATABASE_URL` (API-key lookups against
  `rum_api_keys`), Processor-Go's discrete `POSTGRES_HOST` / `POSTGRES_PORT` /
  `POSTGRES_DATABASE` / `POSTGRES_USER` / `POSTGRES_PASSWORD` / `POSTGRES_SSLMODE`
  (Processor-Go has no `DATABASE_URL` — it only accepts discrete Postgres vars,
  per its existing `internal/config/config.go`).
- `deployments/segmented/dmz/configs/dmz.env` — Kafka, `AUTH_MODE=jwt`,
  `JWT_PUBLIC_KEYS_DIR`, rate-limit values. No Postgres vars (JWT mode doesn't
  use them).
- `deployments/segmented/bank/configs/bank.env` — Processor-Go's discrete
  `POSTGRES_*` vars (see above), Kafka bootstrap + `KAFKA_SECURITY_PROTOCOL=SSL`
  + `KAFKA_TLS_CA_CERT` / `KAFKA_TLS_CLIENT_CERT` / `KAFKA_TLS_CLIENT_KEY` (§5a).

Only `.env.example` files are committed; real env files are gitignored and copied
per-host, exactly as in Python.

## 8. Makefile Parity

Root Makefile keeps Python's dual role:
1. **Local dev** — detects sibling source dirs (`../EdgeTelemetryCollectorGo`,
   `../EdgeTelemetryProcessorGo`) via `$(wildcard ...)`; if present, exposes
   `build`/`up`/`up-build`/`down`/`logs`/`restart` plus per-service log targets
   (`logs-collector`, `logs-processor`) against the root dev compose.
2. **Deployment delegation** — `list-deployments`, `deploy-single-host`, `deploy-dmz`,
   `deploy-bank`, plus server-shortcut forwards (`deploy`, `health`,
   `health-detailed`, `status`, `deploy-down`, `deploy-logs`, `deploy-restart`) to
   `deployments/single-host`.

Per-deployment Makefiles (`deployments/single-host/Makefile`,
`deployments/segmented/{dmz,bank}/Makefile`) keep the same target names as Python's
(`deploy`, `down`, `logs`, `restart`, `update`, `status`, `health`,
`health-detailed`, `config-check`, `system-info`, `backup`, `restore`, `cleanup`,
`monitor`, plus per-service `logs-*`/`restart-*` targets), with:
- Health-check URLs updated to the new ports (§6) and Go health payload shape
  (`{"service": ..., "status": "healthy"|"degraded", ...}` — same shape family as
  Python's, so the existing `curl -f .../health` pattern needs no structural change).
- `test-deployment`/`test-full` targets updated to POST the minimum valid
  Collector-Go payload (`device_id` + non-empty `events` array) instead of Python's
  payload shape.
- No `test-rum-analytics` target (service doesn't exist in this repo).
- `single-host` deploy step drops the RUM-Analytics-specific auto-restart-and-retry
  block Python's `deploy` target has (there being no RUM Analytics service here);
  keeps the same pattern for Processor-Go.

## 9. What Explicitly Does Not Change From Collector-Go / Processor-Go

- Neither service's own tests, Dockerfile, or `.env.*.example` files change,
  **except** the RS256 addition (§5, Collector-Go) and the Kafka mTLS addition
  (§5a, Processor-Go). Both are additive: new env vars with safe defaults
  (`AUTH_MODE` unchanged default; `KAFKA_SECURITY_PROTOCOL` defaults to
  `PLAINTEXT`), no existing behavior changes for callers that don't set them.
- Both services' existing standalone `docker-compose.yml` (each service's own repo)
  are untouched — they remain the per-service local-dev/test setups they are today,
  independent of this new deployment repo.

## 10. Open Items For The Implementation Plan

- Confirm final Docker Hub image naming/tagging convention for
  `telemetry-collector-go` / `telemetry-processor-go` production images (Python uses
  `mktowett/edge_telemetry_collector:latest`; Go equivalents need a namespace/tag
  decided at build-pipeline time — not blocking for the deployment repo's structure,
  since `deployments/*/docker-compose.yml` can reference either a built image or
  `build: ../EdgeTelemetryCollectorGo` initially).
- `getstarted.sh` needs adaptation for a Go toolchain check instead of Python's,
  otherwise mirrors the same host-bootstrap steps (Docker install, directory setup).
- `.github/workflows/validate.yml` mirrors Python's compose-lint / secret-scan /
  shellcheck CI shape; exact job list to be finalized during implementation.
