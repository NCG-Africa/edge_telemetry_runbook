# DMZ Secrets

This directory holds secret material for the DMZ deployment. **Never commit these files to git.**

## `jwt-public-keys/`

Place JWT public keys here for the Collector to verify incoming tokens.

- `public.pem` — RS256 public key exported from the bank's RUM Analytics service
- Obtain from the bank-side deployment team or generate with `shared/scripts/generate-jwt-keypair.sh`

## `kafka-tls/`

Place Kafka server TLS material here for the dual-listener configuration.

- `kafka.server.keystore.jks` — Kafka broker's server keystore (contains server cert + private key)
- `kafka.server.truststore.jks` — Truststore containing the CA cert (used to verify client certs from the bank)

Generate with `shared/scripts/issue-kafka-server-cert.sh`.
