#!/bin/bash
# Issue a PEM Kafka client certificate for a bank-side Go client: the processor
# (--client-name bank-processor) or RUM Analytics (--client-name bank-analytics).
# Unlike the Python deployment's version, this skips keytool/JKS entirely —
# Go's crypto/tls (used by EdgeTelemetryProcessorGo) consumes PEM directly.
# Usage: ./issue-kafka-client-cert.sh --ca-cert ./ca/ca-cert.pem --ca-key ./ca/ca-key.pem --client-name bank-processor --output-dir ./client-certs

set -euo pipefail

CA_CERT=""
CA_KEY=""
CLIENT_NAME=""
OUTPUT_DIR="./kafka-client-certs"
VALIDITY_DAYS=365

while [[ $# -gt 0 ]]; do
    case $1 in
        --ca-cert) CA_CERT="$2"; shift 2 ;;
        --ca-key) CA_KEY="$2"; shift 2 ;;
        --client-name) CLIENT_NAME="$2"; shift 2 ;;
        --output-dir) OUTPUT_DIR="$2"; shift 2 ;;
        --validity-days) VALIDITY_DAYS="$2"; shift 2 ;;
        -h|--help)
            echo "Usage: $0 [OPTIONS]"
            echo ""
            echo "Required:"
            echo "  --ca-cert FILE         CA certificate PEM file"
            echo "  --ca-key FILE          CA private key PEM file"
            echo "  --client-name NAME     Client identifier (bank-processor or bank-analytics)"
            echo ""
            echo "Optional:"
            echo "  --output-dir DIR       Output directory (default: ./kafka-client-certs)"
            echo "  --validity-days DAYS   Certificate validity (default: 365)"
            echo ""
            echo "Outputs PEM files (client.cert.pem, client.key.pem) plus a copy of the"
            echo "CA cert (ca.cert.pem), for EdgeTelemetryProcessorGo's KAFKA_TLS_* env vars."
            exit 0
            ;;
        *) echo "Unknown option: $1"; exit 1 ;;
    esac
done

if [[ -z "$CA_CERT" || -z "$CA_KEY" || -z "$CLIENT_NAME" ]]; then
    echo "ERROR: --ca-cert, --ca-key, and --client-name are required"
    exit 1
fi

mkdir -p "$OUTPUT_DIR"
WORK_DIR=$(mktemp -d)
trap 'rm -rf "$WORK_DIR"' EXIT

echo "Issuing Kafka client certificate (PEM)..."
echo "  Client: $CLIENT_NAME"
echo "  CA cert: $CA_CERT"
echo "  Output: $OUTPUT_DIR"

# Step 1: Generate client private key
echo "[1/3] Generating client private key..."
openssl genpkey \
    -algorithm RSA \
    -pkeyopt rsa_keygen_bits:2048 \
    -out "$OUTPUT_DIR/client.key.pem"

# Step 2: Generate CSR
echo "[2/3] Generating certificate signing request..."
openssl req -new \
    -key "$OUTPUT_DIR/client.key.pem" \
    -subj "/CN=$CLIENT_NAME/O=EdgeTelemetry/OU=Bank" \
    -out "$WORK_DIR/client.csr"

# Step 3: Sign the CSR with the CA
echo "[3/3] Signing certificate with CA..."
openssl x509 -req \
    -in "$WORK_DIR/client.csr" \
    -CA "$CA_CERT" \
    -CAkey "$CA_KEY" \
    -CAcreateserial \
    -out "$OUTPUT_DIR/client.cert.pem" \
    -days "$VALIDITY_DAYS"

cp "$CA_CERT" "$OUTPUT_DIR/ca.cert.pem"

chmod 600 "$OUTPUT_DIR/client.key.pem"
chmod 644 "$OUTPUT_DIR/client.cert.pem" "$OUTPUT_DIR/ca.cert.pem"

# The bank processor container runs as uid 65534 (see
# deployments/segmented/bank/docker-compose.yml), so a 600 key owned by the
# deploy user is unreadable inside it.
if ! chown 65534:65534 "$OUTPUT_DIR/client.key.pem" 2>/dev/null; then
    echo "NOTE: could not chown the client key to uid 65534 (the processor container user)."
    echo "      The processor will fail to read it. Run:"
    echo "        sudo chown 65534:65534 $OUTPUT_DIR/client.key.pem"
fi

echo ""
echo "Kafka client certificate generated:"
echo "  Client cert: $OUTPUT_DIR/client.cert.pem"
echo "  Client key:  $OUTPUT_DIR/client.key.pem  (600 permissions)"
echo "  CA cert:     $OUTPUT_DIR/ca.cert.pem"
echo ""
echo "Copy these to: deployments/segmented/bank/secrets/kafka-tls/"
echo "Set in deployments/segmented/bank/configs/bank.env:"
echo "  KAFKA_SECURITY_PROTOCOL=SSL"
echo "  KAFKA_TLS_CA_CERT=/app/certs/kafka/ca.cert.pem"
echo "  KAFKA_TLS_CLIENT_CERT=/app/certs/kafka/client.cert.pem"
echo "  KAFKA_TLS_CLIENT_KEY=/app/certs/kafka/client.key.pem"
