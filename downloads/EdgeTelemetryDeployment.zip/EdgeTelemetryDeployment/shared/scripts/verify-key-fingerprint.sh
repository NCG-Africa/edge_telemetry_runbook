#!/bin/bash
# Verify that JWT public keys match across DMZ and bank deployments
# Usage: ./verify-key-fingerprint.sh <key1.pem> [key2.pem]

set -euo pipefail

if [[ $# -lt 1 ]]; then
    echo "Usage: $0 <key1.pem> [key2.pem]"
    echo ""
    echo "With one argument:  prints the SHA-256 fingerprint of the key"
    echo "With two arguments: compares fingerprints and reports match/mismatch"
    echo ""
    echo "Examples:"
    echo "  $0 deployments/segmented/dmz/secrets/jwt-public-keys/public.pem"
    echo "  $0 deployments/segmented/dmz/secrets/jwt-public-keys/public.pem deployments/segmented/bank/secrets/jwt-signing-keys/public.pem"
    exit 1
fi

get_fingerprint() {
    local keyfile="$1"
    if [[ ! -f "$keyfile" ]]; then
        echo "ERROR: File not found: $keyfile" >&2
        exit 1
    fi

    # Handle both public and private key files
    if grep -q "PRIVATE KEY" "$keyfile" 2>/dev/null; then
        openssl rsa -in "$keyfile" -pubout -outform DER 2>/dev/null | openssl dgst -sha256 | awk '{print $2}'
    else
        openssl rsa -in "$keyfile" -pubin -outform DER 2>/dev/null | openssl dgst -sha256 | awk '{print $2}'
    fi
}

KEY1="$1"
FP1=$(get_fingerprint "$KEY1")

echo "Key: $KEY1"
echo "SHA-256: $FP1"

if [[ $# -ge 2 ]]; then
    KEY2="$2"
    FP2=$(get_fingerprint "$KEY2")
    echo ""
    echo "Key: $KEY2"
    echo "SHA-256: $FP2"
    echo ""
    if [[ "$FP1" == "$FP2" ]]; then
        echo "MATCH: Keys have the same fingerprint"
    else
        echo "MISMATCH: Keys have different fingerprints!"
        exit 1
    fi
fi
