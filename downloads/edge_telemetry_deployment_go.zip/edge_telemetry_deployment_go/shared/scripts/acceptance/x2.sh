# shellcheck shell=bash
# X2: a legacy batch (no contract_version, posted to /collector/telemetry) with a legacy key
# lands on the App matching (package_name, lower(device.platform)); with no match it lands in
# the DLQ as <app-not-registered> and replays after the App is registered (C8, C12, P9, P13, P18).
x2() {
  X2_DEVICE=$DEV_PREFIX-x2
  local pkg=$PKG_PREFIX.x2 ok=0 hdrs
  legacy_key x2 || return 1

  # Unregistered package: one batch-level dead-letter row, Kafka headers kept for the replay.
  post_batch x2 /collector/telemetry "$(render batch-legacy.json "$X2_DEVICE" "$X2_DEVICE-s1" "$pkg" "$(iso)")" || return 1
  wait_for "X2 <app-not-registered> DLQ row" 60 dlq_row "$X2_DEVICE" || return 1
  X2_DLQ_ID=$(dlq_id "$X2_DEVICE")
  hdrs=$(q "SELECT coalesce(kafka_headers->>'contract_version', '') || '|' || (kafka_headers ? 'app_id')::text
            FROM processor_dead_letter_events WHERE id = $X2_DLQ_ID")
  log "    DLQ row id=$X2_DLQ_ID"
  check "DLQ kafka_headers contract_version" legacy "${hdrs%|*}" || ok=1
  check "DLQ kafka_headers has app_id" false "${hdrs#*|}" || ok=1
  check "events for $X2_DEVICE before the App exists" 0 "$(events_of "$X2_DEVICE")" || ok=1

  # Register the App the batch names (platform = lower(device.platform)), then replay the row.
  create_app x2 android "$pkg" || return 1
  X2_APP=$APP_ID
  replay "$X2_DLQ_ID" || return 1
  check "replay succeeded" 1 "$(printf '%s' "$HTTP_BODY" | jq -r .succeeded)" || ok=1
  check "replayed session app_id" "$X2_APP" "$(session_row "$X2_DEVICE-s1" | cut -d'|' -f1)" || ok=1
  check "replayed session environment (legacy key: none)" "" "$(session_row "$X2_DEVICE-s1" | cut -d'|' -f2)" || ok=1

  # A second batch for the now-registered App lands directly, no new DLQ row.
  post_batch x2 /collector/telemetry "$(render batch-legacy.json "$X2_DEVICE" "$X2_DEVICE-s2" "$pkg" "$(iso)")" || return 1
  wait_for "X2 second batch in rum_telemetry_events" 60 events_are "$X2_DEVICE" 4 || return 1
  check "direct session app_id" "$X2_APP" "$(session_row "$X2_DEVICE-s2" | cut -d'|' -f1)" || ok=1
  check "DLQ rows for $X2_DEVICE" 1 "$(dlq_count "$X2_DEVICE")" || ok=1
  return $ok
}
