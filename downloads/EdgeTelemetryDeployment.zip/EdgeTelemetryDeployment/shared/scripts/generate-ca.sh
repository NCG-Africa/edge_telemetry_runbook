#!/bin/bash
# Generate a private Certificate Authority (CA) for Kafka mTLS
# Usage: ./generate-ca.sh --output-dir ./ca --validity-days 3650

set -euo pipefail

OUTPUT_DIR="./ca"
VALIDITY_DAYS=3650
CA_CN="EdgeTelemetry Private CA"

while [[ $# -gt 0 ]]; do
    case $1 in
        --output-dir) OUTPUT_DIR="$2"; shift 2 ;;
        --validity-days) VALIDITY_DAYS="$2"; shift 2 ;;
        --cn) CA_CN="$2"; shift 2 ;;
        -h|--help)
            echo "Usage: $0 [OPTIONS]"
            echo ""
            echo "Options:"
            echo "  --output-dir DIR       Output directory (default: ./ca)"
            echo "  --validity-days DAYS   CA validity in days (default: 3650)"
            echo "  --cn NAME              CA common name (default: EdgeTelemetry Private CA)"
            exit 0
            ;;
        *) echo "Unknown option: $1"; exit 1 ;;
    esac
done

mkdir -p "$OUTPUT_DIR"

echo "Generating private CA..."
echo "  Output: $OUTPUT_DIR"
echo "  Validity: $VALIDITY_DAYS days"
echo "  CN: $CA_CN"

# Generate CA private key
openssl genrsa -out "$OUTPUT_DIR/ca-key.pem" 4096

# Generate CA certificate
openssl req -new -x509 \
    -key "$OUTPUT_DIR/ca-key.pem" \
    -out "$OUTPUT_DIR/ca-cert.pem" \
    -days "$VALIDITY_DAYS" \
    -subj "/CN=$CA_CN/O=EdgeTelemetry/OU=Infrastructure"

echo ""
echo "CA generated successfully:"
echo "  Private key: $OUTPUT_DIR/ca-key.pem"
echo "  Certificate: $OUTPUT_DIR/ca-cert.pem"
echo ""
echo "Fingerprint:"
openssl x509 -in "$OUTPUT_DIR/ca-cert.pem" -noout -fingerprint -sha256
