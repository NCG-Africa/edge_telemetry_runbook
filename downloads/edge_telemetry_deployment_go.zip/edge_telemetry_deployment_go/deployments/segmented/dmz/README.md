# Segmented Deployment — DMZ (Go)

Internet-facing half of the segmented topology: Kafka (dual-listener) +
Collector-Go (API keys from `rum-api-keys`) + `kafka-init` + `kafka-lag-watch`
+ Kafka UI. No PostgreSQL, no Redis: the collector holds every API key in
memory, read from the `rum-api-keys` topic that bank RUM Analytics produces to,
and its rate limiter counts in memory.

## Prerequisites

Provision secrets once via `shared/scripts/` (see `../../../shared/README.md`):

- `secrets/kafka-tls/` — server JKS keystore + truststore.

Port 9093 is the only port this repo publishes off-host: the bank-side
processor and RUM Analytics dial it from another machine, so it cannot be bound to loopback.
Put a host firewall rule in front of it allowing **only** the bank's egress
IP. Everything else here binds to `127.0.0.1`.

## Quick start

```bash
cp configs/dmz.env.example configs/dmz.env
# then edit configs/dmz.env — every CHANGE_ME must be replaced, and the
# keystore passwords must match what you passed to issue-kafka-server-cert.sh:
#   DMZ_KAFKA_EXTERNAL_FQDN, KAFKA_{KEYSTORE,KEY,TRUSTSTORE}_PASSWORD,
#   KAFKA_UI_USER, KAFKA_UI_PASSWORD, KAFKA_DISK_BUDGET_BYTES
make deploy
```

Deploy the DMZ before the bank: its `kafka-init` creates `telemetry-upsert`
(12 partitions) and `rum-api-keys`, and the bank's `kafka-topics-wait` refuses
to start the processor and analytics until both exist.

## Service URLs

| Service | URL |
|---|---|
| Collector-Go | http://127.0.0.1:8001 (loopback only — front it with a host reverse proxy) |
| Kafka UI | http://127.0.0.1:8080 (loopback only — see below) |
| Kafka (mTLS, external) | `<this-host>:9093` (firewall to the bank egress IP) |

Kafka UI is bound to loopback and requires a login. Reach it from your laptop with:

```bash
ssh -L 8080:127.0.0.1:8080 <user>@<host>
```

then open <http://127.0.0.1:8080> and sign in with `KAFKA_UI_USER` /
`KAFKA_UI_PASSWORD` from `configs/dmz.env`.

## API keys and readiness

Keys are issued in bank RUM Analytics and reach this collector over
`rum-api-keys` within seconds; revocation is a tombstone. On start the collector
replays the topic, and until it has caught up `/ready` answers 503 and ingest
answers **503 with `Retry-After: 5`** (SDKs retry and queue; never 401, which
they would drop). The compose healthcheck and `make health` use `/ready`;
`/health` is liveness only. The reverse proxy must pass that 503 through
unchanged. `make test-deployment` prints an `X-API-Key` example.

## Upgrade (`make update`, both hosts)

Stop-the-world, split across the hosts. Images are pinned, so an upgrade is a
merged change to the two `docker-compose.yml` files; `git pull` on both hosts
first. `make update` on either host prints this order. Run each phase on its
host and let it succeed before the next:

| # | Host | Command | What it does |
|---|---|---|---|
| 1 | DMZ | `make update-stop` | `config-check`, pull images, stop the collector. Ingest is down (502, SDKs queue offline) until phase 5. |
| 2 | bank | `make update-drain` | `config-check`, pull images, poll the processor's lag over mTLS until 0 (`DRAIN_TIMEOUT_SECONDS`, default 1800; on timeout it exits 1 and nothing else changed), stop processor + analytics, write `backups/offsets-<ts>-before.txt`. |
| 3 | DMZ | `make update-topics` | Restart the broker if its config changed (nothing is connected now), then `kafka-init`: grows `telemetry-upsert` 1 → 12 (first upgrade only), creates `rum-api-keys`, reapplies topic config. |
| 4 | bank | `make update-start` | Analytics (migrates `rum_*`), then the processor, each waiting for healthy; both wait on `kafka-topics-wait`. Writes and prints `backups/offsets-<ts>-after.txt`. |
| 5 | DMZ | `make update-start` | The collector, once `/ready` (key map caught up on `rum-api-keys`), then the rest. |

Partition 0's committed offset in the bank's *after* file must equal the
*before* file; partitions 1-11 show none until they get traffic. If phase 2
times out, fix the processor and rerun `make update-drain`; the collector stays
stopped and the topic untouched. Never `down -v` either host.

## Lag alert

`kafka-lag-watch` checks the bank processor's group lag on `telemetry-upsert`
every 5 min and logs one `WARN kafka_lag_high lag=<n>` line per check while it
exceeds `LAG_ALERT_MESSAGES` (default 1000000, about 48 min of backlog). It is
log-only; grep for it:

```bash
docker compose logs kafka-lag-watch | grep kafka_lag_high
```

Keep `LAG_ALERT_MESSAGES` below `retention.bytes` ÷ average message size per
partition, or data ages out before the alert fires. A failed check logs
`WARN kafka_lag_check_failed` and the watcher keeps going.

## No ACLs on `rum-api-keys` (known limit)

No broker authorizer runs, so any client-cert holder could produce a forged key.
Accepted; upgrade path (`StandardAuthorizer`, write on `rum-api-keys` for
`CN=bank-analytics` only) in [`shared/README.md`](../../../shared/README.md#known-limit-no-acls-on-rum-api-keys).
