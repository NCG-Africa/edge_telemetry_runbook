#!/usr/bin/env bash
# One-shot owner of the Kafka topics (run by the kafka-init compose service).
# Idempotent, safe against an existing install:
#   1. create telemetry-upsert (12 partitions) and rum-api-keys (compacted) if missing
#   2. grow telemetry-upsert 1 -> 12 partitions, the only count change ever allowed;
#      any other count is an error. Never shrinks, deletes or recreates it.
#   3. reapply each topic's full config (fixes drift) with kafka-configs, because
#      Kafka 3.4's kafka-topics cannot alter configs
#   4. describe both topics
#
# Env: KAFKA_DISK_BUDGET_BYTES (required) total bytes telemetry-upsert may use;
#      retention.bytes per partition = budget / 12.
#      KAFKA_BOOTSTRAP_SERVERS, KAFKA_TOPIC, KAFKA_API_KEYS_TOPIC (defaulted).
set -euo pipefail

bs=${KAFKA_BOOTSTRAP_SERVERS:-kafka:29092}
upsert=${KAFKA_TOPIC:-telemetry-upsert}
keys=${KAFKA_API_KEYS_TOPIC:-rum-api-keys}
budget=${KAFKA_DISK_BUDGET_BYTES:-}
partitions=12

if ! [[ $budget =~ ^[0-9]+$ ]] || (( 10#$budget < partitions )); then
  echo "kafka-init: KAFKA_DISK_BUDGET_BYTES must be a byte count (e.g. 120000000000), got '$budget'" >&2
  exit 1
fi
retention_bytes=$(( 10#$budget / partitions ))
echo "kafka-init: retention.bytes = $budget / $partitions = $retention_bytes per partition"

upsert_cfg=(retention.ms=604800000 "retention.bytes=$retention_bytes" compression.type=zstd)
keys_cfg=(cleanup.policy=compact segment.ms=3600000 delete.retention.ms=86400000)

# "a b c" -> "--config a --config b --config c" for kafka-topics --create
config_flags() { for kv in "$@"; do printf -- '--config\n%s\n' "$kv"; done; }
# "a b c" -> "a,b,c" for kafka-configs --add-config
join() { local IFS=,; echo "$*"; }

# 1. create if missing
mapfile -t flags < <(config_flags "${keys_cfg[@]}")
kafka-topics --bootstrap-server "$bs" --create --if-not-exists --topic "$keys" --partitions 1 --replication-factor 1 "${flags[@]}"
mapfile -t flags < <(config_flags "${upsert_cfg[@]}")
kafka-topics --bootstrap-server "$bs" --create --if-not-exists --topic "$upsert" --partitions "$partitions" --replication-factor 1 "${flags[@]}"

# 2. partition count: checked before any config change so a bad topic is left untouched
count=$(kafka-topics --bootstrap-server "$bs" --describe --topic "$upsert" | sed -n 's/.*PartitionCount: *\([0-9]*\).*/\1/p' | head -1)
case $count in
  "$partitions") echo "kafka-init: $upsert has $partitions partitions" ;;
  1)
    echo "kafka-init: growing $upsert 1 -> $partitions partitions"
    kafka-topics --bootstrap-server "$bs" --alter --topic "$upsert" --partitions "$partitions"
    ;;
  *)
    echo "kafka-init: $upsert has '$count' partitions; only 1 (grown to $partitions) or $partitions is allowed." >&2
    echo "kafka-init: refusing to alter it. Never delete/recreate $upsert (offset reuse breaks processor dedupe)." >&2
    exit 1
    ;;
esac

# 3. config drift
kafka-configs --bootstrap-server "$bs" --alter --entity-type topics --entity-name "$keys" --add-config "$(join "${keys_cfg[@]}")"
kafka-configs --bootstrap-server "$bs" --alter --entity-type topics --entity-name "$upsert" --add-config "$(join "${upsert_cfg[@]}")"

# 4. report
kafka-topics --bootstrap-server "$bs" --describe --topic "$keys"
kafka-topics --bootstrap-server "$bs" --describe --topic "$upsert"
