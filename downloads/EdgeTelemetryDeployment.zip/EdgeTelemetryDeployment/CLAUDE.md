# CLAUDE.md - EdgeTelemetry Deployment

## Project Overview

EdgeTelemetry Deployment is a containerized system for collecting, processing, and visualizing real-time telemetry from mobile applications. The pipeline is:

```
Client → Collector → Kafka → Processor → PostgreSQL
                                ↓
                            Redis ← RUM Analytics API
```

## Deployments

There are **two supported deployments**, both under `deployments/`:

- **single-host** — everything on one host. No auth on the collector. For dev, staging, or prod environments without a network-segmentation requirement.
- **segmented** — split across two network zones:
  - `segmented/dmz/` — internet-facing: Kafka (dual listener) + Collector + Kafka UI
  - `segmented/bank/` — internal: Redis + Processor + RUM Analytics API
  - Cross-zone traffic flows over Kafka:9093 with mTLS. JWT uses RS256 (DMZ holds public key, bank holds private).

## Architecture

| Component | Port | Purpose |
|-----------|------|---------|
| Collector | 8001 → 8000 | REST API for telemetry ingestion |
| Processor | 8002 → 8000 | Kafka consumer; writes to PostgreSQL |
| RUM Analytics API | 8003 → 8100 | Query API with Redis caching |
| Kafka (internal) | 29092 | Plaintext, in-cluster |
| Kafka (mTLS) | 9093 | External SSL (segmented mode only) |
| Zookeeper | 2181 | Kafka coordination |
| Redis | 6379 | Analytics cache |
| Kafka UI | 8080 | Kafka monitoring |

## Tech Stack

- **Backend:** Python (Collector, Processor, RUM Analytics API)
- **Message broker:** Apache Kafka 7.4.0 + Zookeeper
- **Database:** PostgreSQL via `asyncpg`
- **Cache:** Redis 7-alpine
- **Containerization:** Docker + Docker Compose
- **Automation:** Make, Bash

## Repository Structure

```
├── deployments/
│   ├── single-host/                    # Deployment 1: all-in-one
│   │   ├── docker-compose.yml
│   │   ├── Makefile
│   │   └── configs/single-host.env(.example)
│   └── segmented/                      # Deployment 2: DMZ + Bank
│       ├── dmz/
│       │   ├── docker-compose.yml
│       │   ├── Makefile
│       │   ├── configs/dmz.env(.example)
│       │   └── secrets/{kafka-tls, jwt-public-keys}
│       └── bank/
│           ├── docker-compose.yml
│           ├── Makefile
│           ├── configs/bank.env(.example)
│           └── secrets/{kafka-tls, jwt-signing-keys}
├── shared/
│   ├── scripts/                        # CA / TLS / JWT / pre-commit hook
│   └── README.md
├── docker-compose.yml                  # Local-dev: builds from sibling source dirs
├── Makefile                            # Dev targets + deployment delegation
├── getstarted.sh                       # Host bootstrap (Debian/RHEL/SUSE)
├── .github/workflows/validate.yml      # CI: compose lint, secret scan, shellcheck
└── .gitignore                          # Excludes secrets, real .env files
```

Source code for individual services lives in sibling directories (used by the root `docker-compose.yml` for local dev):
- `../EdgeTelemetryCollector`
- `../EdgeTelemetryProcessor`
- `../EdgeTelemetryRumAnalytics`

## Common Commands

```bash
# From repo root
make list-deployments             # Show available deployments
make deploy-single-host           # Forward to deployments/single-host
make deploy-dmz                   # Forward to deployments/segmented/dmz
make deploy-bank                  # Forward to deployments/segmented/bank

# Local dev (root docker-compose.yml, builds from source)
make up-build                     # Build + start
make logs                         # Tail
make down                         # Stop

# Inside any deployment dir (e.g. cd deployments/single-host)
make deploy
make down
make health
make health-detailed
make logs
make config-check
```

## Configuration

Each deployment owns its own env file:
- `deployments/single-host/configs/single-host.env` — DB, Kafka, Redis (no auth)
- `deployments/segmented/dmz/configs/dmz.env` — Kafka, JWT public-key path, rate limits
- `deployments/segmented/bank/configs/bank.env` — DB, Redis, Kafka (mTLS), JWT signing keys

Real env files are gitignored — only `.env.example` files are committed. Copy and populate per-host:

```bash
cp deployments/single-host/configs/single-host.env.example deployments/single-host/configs/single-host.env
```

## Security Scripts

Located in `shared/scripts/`:
- `generate-ca.sh` — Create the private CA for Kafka mTLS
- `issue-kafka-server-cert.sh` — Issue Kafka server cert (DMZ)
- `issue-kafka-client-cert.sh` — Issue Kafka client cert (bank)
- `generate-jwt-keypair.sh` — Generate the RS256 JWT keypair
- `verify-key-fingerprint.sh` — Compare JWT key fingerprints across DMZ/bank
- `install-pre-commit-hook.sh` — Install hook that blocks committing `*.pem`/`*.jks`/etc.
- `test-distro-detection.sh` — Verify `getstarted.sh` maps each supported distro to the right package manager / Docker repo (runs in CI)

## Database

PostgreSQL `edge_db` with these core tables:
- `rum_apps` — Application metadata (keyed on `package_name`)
- `rum_devices` — Device info (platform, model, manufacturer)
- `rum_users` — User identifiers
- `rum_sessions` — Session tracking and metrics (FK to apps, devices, users)

## Docker Images

Production images on Docker Hub under `mktowett/`:
- `mktowett/edge_telemetry_collector:dev`
- `mktowett/edge_telemetry_processor:dev`
- `mktowett/edge_telemetry_rum_analytics:dev`

## GitHub

Repository: `github.com/NCG-Africa/EdgeTelemetryDeployment`
