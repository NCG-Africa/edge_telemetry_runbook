# Credential rotation and remediation handoff — Sep 3 2026 breach

**For:** whoever owns the live single-host RUM telemetry server.
**Scope:** credentials and data. This document does **not** cover cleaning the
compromised machine (miner removal, forensics, persistence, host firewall) —
that is a separate job.

## What the attacker had

`provectuslabs/kafka-ui:latest` was published on `0.0.0.0:8090` with no
authentication and taken over via a known unauthenticated RCE
(CVE-2023-52251 / CVE-2024-32030), running `xmrig` inside the container.

From inside that container the attacker sat on the `telemetry-go-network`
bridge with every other service. The single-host compose file mounted no
Docker socket and used no `privileged` / `cap_add`, so it granted no easy
escape to the host — but escape cannot be ruled out, and the rotation list
below assumes the worst where the cost of being wrong is high.

Directly reachable from the compromised container, with no credential needed:

| Service | Why it was open |
|---|---|
| `redis:6379` | no password, and additionally published on `0.0.0.0:6381` |
| `kafka:29092` | `PLAINTEXT`, no SASL — read *and* write on `telemetry-upsert` |
| `zookeeper:2181` | no auth |
| `collector:8000`, `processor:8000` | health/ingest endpoints |
| the external Postgres | published on `0.0.0.0` per the incident notes — credential still required |

## 1. Rotate now

### 1.1 Postgres `edge_db` credentials — do first

**Where:** `DATABASE_URL` and `POSTGRES_PASSWORD` in the deployed
`deployments/single-host/configs/single-host.env`, injected into both the
collector and processor containers.

**Why:** only readable with host filesystem access or a container escape,
neither of which is proven. Rotate anyway: Postgres itself was published on
`0.0.0.0`, so a leaked password is directly usable from the public internet
by anyone, not just this attacker.

```sql
ALTER ROLE <edge_db_user> WITH PASSWORD '<new>';
```

Then update **both** `DATABASE_URL` and `POSTGRES_PASSWORD` in the env file
(they must agree) and redeploy.

### 1.2 Every `rum_api_keys` row — do first

**Why:** Redis was unauthenticated *and* internet-published, and the collector
caches every recently-used key there. `KEYS api_key:*` yields the key
**prefix** — the first half of the credential — for every key used inside the
cache TTL, and each value holds `tenant_id`, `user_id`, `api_key_id` in
cleartext plus `api_key_hash`.

That hash is unsalted single-round SHA-256 (`internal/auth/apikey.go`,
`HashSecret`), so whether the secret half is recoverable offline depends on
how much entropy the key generator puts in it — something this repo does not
control. With half the credential and a cheap hash of the other half,
treat every key as exposed.

1. Issue replacement keys and distribute them to the client apps.
2. Revoke / delete the old `rum_api_keys` rows.
3. Flush the collector's Redis cache so no revoked hash survives its TTL:
   `redis-cli -a "$REDIS_PASSWORD" --scan --pattern 'api_key:*' | xargs -r redis-cli -a "$REDIS_PASSWORD" DEL`

### 1.3 Docker Hub push token — lower priority

**Where:** GitHub Actions secrets of `EdgeTelemetryCollectorGo` and
`EdgeTelemetryProcessorGo` (not this repo, and never on the breached host).

**Why:** not breach-exposed, but it is the one remaining credential that can
repoint a `papijo/*` production tag. Image provenance was audited clean and
both images are now digest-pinned, which blunts the risk — rotate as hygiene
on your own schedule, not as incident response.

## 2. Data integrity and disclosure

Not credentials, but they belong in the same handoff:

- **Kafka was writable.** The attacker could publish arbitrary messages to
  `telemetry-upsert`, which the processor would have written to `rum_*`.
  Audit those tables across the breach window for fabricated rows.
- **Kafka was readable.** All RUM telemetry in the topic's retention window —
  device ids, user ids, session data — was readable. Whoever owns that data
  needs to decide whether it triggers a disclosure obligation.

## 3. Do *not* rotate — verified not exposed

Listed so nobody spends time on them:

| Credential | Why it is safe |
|---|---|
| Kafka keystore / truststore / key passwords | segmented mode was never deployed; both `secrets/kafka-tls/` dirs contain only `.gitkeep`, so no keystore was ever generated. The `changeit` default is gone from the scripts regardless. |
| JWT RS256 signing keypair | JWT is DMZ-only; single-host runs `AUTH_MODE=api_key`. The private key was never on this host, and `dmz/secrets/jwt-public-keys/` is empty. |
| Anything in git history | `git log --all --diff-filter=A` over `*.env` / `*.pem` / `*.jks` returns only `README.md` and `.gitkeep`. No secret was ever committed. |
| Kafka UI credentials | none existed — that was the vulnerability. |
| Redis password | none existed. |

## 4. Create before the next deploy

The hardening work added two required credentials. `make deploy` aborts if
either is unset, and `make config-check` rejects a leftover `CHANGE_ME`. Both
live in `deployments/single-host/configs/single-host.env`:

```
REDIS_PASSWORD=$(openssl rand -base64 24)
KAFKA_UI_USER=<pick one>
KAFKA_UI_PASSWORD=$(openssl rand -base64 24)
```

The Kafka UI now binds to `127.0.0.1:8090` behind a login form. Reach it with
`ssh -L 8090:127.0.0.1:8090 <user>@<host>` — it is no longer on the internet.

## 5. Order of operations

1. Clean the host and confirm the miner and its persistence are gone. **Until
   this is done, every credential set below is being typed onto a machine the
   attacker may still control** — nothing here is meaningful before it.
2. Rotate the Postgres password (1.1).
3. Set the two new credentials (section 4).
4. Redeploy from the hardened repo: `make deploy` in
   `deployments/single-host/`.
5. Confirm `docker compose ps` shows six healthy containers and that nothing
   is listening on `0.0.0.0` any more (`ss -tlnp`).
6. Issue and distribute new API keys, then revoke the old ones and flush the
   cache (1.2).
7. Audit `rum_*` for injected rows (section 2).
