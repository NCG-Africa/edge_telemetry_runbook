#!/bin/bash
# Install the pre-commit hook that prevents accidental commit of secret files
# Usage: ./install-pre-commit-hook.sh

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
HOOK_SOURCE="$SCRIPT_DIR/pre-commit-hook.sh"
HOOK_TARGET="$REPO_ROOT/.git/hooks/pre-commit"

if [[ ! -f "$HOOK_SOURCE" ]]; then
    echo "ERROR: Source hook not found at $HOOK_SOURCE"
    exit 1
fi

if [[ ! -d "$REPO_ROOT/.git/hooks" ]]; then
    echo "ERROR: Not a git repository (no .git/hooks directory)"
    exit 1
fi

if [[ -f "$HOOK_TARGET" ]]; then
    echo "WARNING: Pre-commit hook already exists at $HOOK_TARGET"
    echo "Overwrite? (y/N)"
    read -r confirm
    if [[ "$confirm" != "y" && "$confirm" != "Y" ]]; then
        echo "Aborted"
        exit 0
    fi
fi

cp "$HOOK_SOURCE" "$HOOK_TARGET"
chmod +x "$HOOK_TARGET"

echo "Pre-commit hook installed at $HOOK_TARGET"
echo "It will block commits containing .pem, .key, .p12, or .jks files"
