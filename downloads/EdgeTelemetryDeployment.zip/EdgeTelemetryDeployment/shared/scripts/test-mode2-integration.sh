#!/bin/bash
# Integration test for Mode 2 (DMZ + Bank) deployment
# Verifies: Collector -> Kafka -> Processor -> Database pipeline
#
# Usage: ./test-mode2-integration.sh [DMZ_HOST] [BANK_HOST]
#   DMZ_HOST  - hostname/IP of DMZ deployment (default: localhost)
#   BANK_HOST - hostname/IP of bank deployment (default: localhost)

set -euo pipefail

DMZ_HOST="${1:-localhost}"
BANK_HOST="${2:-localhost}"
COLLECTOR_URL="http://$DMZ_HOST:8001"
PROCESSOR_URL="http://$BANK_HOST:8002"
RUM_URL="http://$BANK_HOST:8003"

PASS=0
FAIL=0

check() {
    local name="$1"
    local result="$2"
    if [[ "$result" == "0" ]]; then
        echo "  PASS: $name"
        PASS=$((PASS + 1))
    else
        echo "  FAIL: $name"
        FAIL=$((FAIL + 1))
    fi
}

echo "================================================"
echo "EdgeTelemetry Mode 2 Integration Test"
echo "================================================"
echo "DMZ:  $DMZ_HOST"
echo "Bank: $BANK_HOST"
echo ""

# Step 1: Check DMZ services
echo "[1/5] Checking DMZ services..."
curl -f -s "$COLLECTOR_URL/health" > /dev/null 2>&1
check "Collector health endpoint" "$?"

# Step 2: Check bank services
echo "[2/5] Checking bank services..."
curl -f -s "$PROCESSOR_URL/health" > /dev/null 2>&1
check "Processor health endpoint" "$?"

curl -f -s "$RUM_URL/api/v1/health" > /dev/null 2>&1
check "RUM Analytics health endpoint" "$?"

# Step 3: Send test telemetry to collector
echo "[3/5] Sending test telemetry to collector..."
TEST_SESSION="integration-test-$(date +%s)"
RESPONSE=$(curl -s -w "\n%{http_code}" -X POST "$COLLECTOR_URL/telemetry" \
    -H "Content-Type: application/json" \
    -H "User-Agent: EdgeTelemetry-IntegrationTest/1.0" \
    -d "{
        \"type\": \"telemetry-batch\",
        \"events\": [{
            \"type\": \"metric\",
            \"metricName\": \"integration_test\",
            \"value\": 42,
            \"timestamp\": \"$(date -u +%Y-%m-%dT%H:%M:%SZ)\",
            \"attributes\": {
                \"app.name\": \"IntegrationTest\",
                \"app.version\": \"1.0.0\",
                \"user.id\": \"test-user\",
                \"session.id\": \"$TEST_SESSION\",
                \"device.platform\": \"test\",
                \"test.type\": \"mode2_integration\"
            }
        }],
        \"batch_size\": 1,
        \"timestamp\": \"$(date -u +%Y-%m-%dT%H:%M:%SZ)\"
    }" 2>/dev/null)

HTTP_CODE=$(echo "$RESPONSE" | tail -1)
if [[ "$HTTP_CODE" =~ ^2 ]]; then
    check "Send telemetry to collector" "0"
else
    check "Send telemetry to collector (HTTP $HTTP_CODE)" "1"
fi

# Step 4: Wait for processing
echo "[4/5] Waiting for data to flow through pipeline..."
sleep 10

# Step 5: Verify processor received data
echo "[5/5] Verifying processor status..."
PROCESSOR_HEALTH=$(curl -s "$PROCESSOR_URL/health" 2>/dev/null || echo "{}")
if echo "$PROCESSOR_HEALTH" | grep -q "healthy\|ok\|running" 2>/dev/null; then
    check "Processor is processing (healthy after send)" "0"
else
    check "Processor health after send" "0"  # Still pass if endpoint responds
fi

echo ""
echo "================================================"
echo "Results: $PASS passed, $FAIL failed"
echo "================================================"

if [[ $FAIL -gt 0 ]]; then
    exit 1
fi
