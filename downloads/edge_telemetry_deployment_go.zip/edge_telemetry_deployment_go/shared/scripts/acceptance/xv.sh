# shellcheck shell=bash
# XV, the cross-repo version check left open by processor PR #14: after X1, analytics'
# ?version= filter and per-version experience return X1's session
# (rum_sessions.app_version_id -> rum_app_versions).
xv() {
  [ -n "${X1_APP:-}" ] || { log "    FAIL needs X1 earlier in the same run"; return 1; }
  local base=/api/v1/rum/mobile/apps/$X1_APP ok=0
  api GET "$base/sessions?version=$X1_VERSION&time_range=24h"
  check "sessions?version=$X1_VERSION has X1's session" yes \
    "$(printf '%s' "$HTTP_BODY" | jq -r --arg s "$X1_SESSION" 'if any(.data[]?; .session_id == $s) then "yes" else "no (HTTP '"$HTTP_CODE"')" end')" || ok=1
  api GET "$base/sessions?version=0.0.0-acceptance-none&time_range=24h"
  check "sessions?version=<other> excludes it" no \
    "$(printf '%s' "$HTTP_BODY" | jq -r --arg s "$X1_SESSION" 'if any(.data[]?; .session_id == $s) then "yes" else "no" end')" || ok=1
  api GET "$base/experience-score/versions?time_range=24h"
  check "experience-score/versions $X1_VERSION session_count" 1 \
    "$(printf '%s' "$HTTP_BODY" | jq -r --arg v "$X1_VERSION" '[.data[]? | select(.version == $v) | .session_count] | first // "missing (HTTP '"$HTTP_CODE"')"')" || ok=1
  api GET "$base/experience-score?version=$X1_VERSION&time_range=24h"
  check "experience-score?version=$X1_VERSION total_sessions" 1 \
    "$(printf '%s' "$HTTP_BODY" | jq -r '.data.total_sessions // "missing (HTTP '"$HTTP_CODE"')"')" || ok=1
  return $ok
}
