#!/usr/bin/env bash
# Write a Kafka CLI --command-config for mTLS from the PEMs the Go services use
# (KAFKA_TLS_CA_CERT, KAFKA_TLS_CLIENT_CERT, KAFKA_TLS_CLIENT_KEY) and print its
# path. Runs inside confluentinc/cp-kafka:7.4.0; needs a writable /tmp.
set -euo pipefail

dir=$(mktemp -d)
# A PEM keystore is one file: the unencrypted private key, then the cert chain.
cat "${KAFKA_TLS_CLIENT_KEY:?}" "${KAFKA_TLS_CLIENT_CERT:?}" > "$dir/client.pem"
cat > "$dir/client.properties" <<PROPS
security.protocol=SSL
ssl.keystore.type=PEM
ssl.keystore.location=$dir/client.pem
ssl.truststore.type=PEM
ssl.truststore.location=${KAFKA_TLS_CA_CERT:?}
PROPS
echo "$dir/client.properties"
