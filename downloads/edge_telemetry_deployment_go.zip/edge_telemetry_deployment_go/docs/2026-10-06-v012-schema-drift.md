# v012 → Go schema drift (public.rum_* + processor tables)

Resolves "Diff v012 rum tables against what the Go services need" (#20, map #19).

## Method

Throwaway `timescale/timescaledb-ha:pg17` (v012 says "dumped from 17.4"; `SET transaction_timeout` fails on pg16). Three DBs, catalogs dumped and diffed for the 27 relations the Go code references:

| DB | Built from |
|---|---|
| `edge_db` | `edge_apm_sql_enterprise_v012.sql`, whole file — loads with **0 errors** on pg17 into a DB named `edge_db` (it `\connect`s by name) |
| `ref` | RUM Analytics Go `schema/edge_db_schema.sql` — the prod pg_dump its integration suite runs against; i.e. the shape the Go services run on today |
| `gonew` | Processor-Go `0001`–`0004` + RUM Analytics `018`, `019` on an empty DB |

Touched set (grep of non-test `.go`): Processor-Go writes `rum_apps, rum_devices, rum_users, rum_sessions, rum_telemetry_events, rum_performance_metrics, rum_performance_events, rum_http_requests, rum_screen_durations, rum_errors, rum_navigations, rum_ui_interactions, processor_dead_letter_events`, reads `rum_action_envelopes`. Collector-Go reads `rum_api_keys`. RUM Analytics Go reads all of the above plus `rum_crash_events, rum_session_summaries, rum_app_versions, rum_geo_locations, rum_geo_rollup_{hourly,daily}, rum_navigation_events, rum_trace_spans, rum_user_actions, rum_user_experience_{daily,windows}`, writes `rum_app_settings`, `rum_geo_rollup_*`, `rum_session_summaries`.

## Headline findings

1. **14 of 27 touched relations don't exist in v012.** Missing: `processor_dead_letter_events`, `rum_errors`, `rum_navigations`, `rum_ui_interactions`, `rum_action_envelopes` (view), `rum_app_settings`, `rum_app_versions`, `rum_geo_locations`, `rum_geo_rollup_daily`, `rum_geo_rollup_hourly`, `rum_trace_spans`, `rum_user_actions`, `rum_user_experience_daily`, `rum_user_experience_windows`. Also missing enum `trace_injection_outcome`.
2. **79 columns missing** across the 13 tables v012 does have (list below). Zero columns in v012 that ref lacks — v012 is a strict, older subset plus type/nullability drift.
3. **Running Processor-Go's migrations on v012 fails today.** Applied `0001`→`0004` to a copy: `0001` and `0002` pass (every `CREATE TABLE` skipped — the known trap — but `0001`'s unique indexes and `0002`'s `ADD COLUMN IF NOT EXISTS` do land), then **`0003` aborts**: `column "brand" of relation "rum_devices" does not exist`. v012 `rum_devices` has none of `brand, hardware, product, platform_version, android_sdk, android_release, fingerprint, device_id, user_id, created_at`. golang-migrate would leave version 3 dirty; the processor would not start.
4. **Go migrations alone don't produce the shape Go needs either.** `gonew` vs `ref`: no `rum_apps.tenant_id` (Processor-Go `repository.go:50` inserts it), no `rum_api_keys`, `rum_http_requests`, `rum_screen_durations` (Processor-Go inserts into the last two), nor any of the 8 analytics-only tables. Their only DDL source is the ref pg_dump and the Python processor's hand-run scripts (`EdgeTelemetryProcessor/sql/*.sql`, `scripts/create_all_tables.sql`). **No Go repo owns DDL for ~half of the touched schema.** Directly relevant to the strategy and fold-in tickets.
5. Tables Go migrations *do* create (`rum_errors`, `rum_navigations`, `rum_ui_interactions`, `processor_dead_letter_events`, `rum_app_settings`) match ref exactly (ids aside).

## ON CONFLICT targets

| Statement | v012 | Effect |
|---|---|---|
| `rum_apps ON CONFLICT (package_name)` | **no unique** | 42P10 on every insert — fixed by `0001`'s `CREATE UNIQUE INDEX IF NOT EXISTS`, **fails if a client already has duplicate `package_name` rows** |
| `rum_users ON CONFLICT (user_id)` | **no unique** (plain btree only) | same as above |
| `rum_sessions ON CONFLICT (session_id)` | unique ✓ | ok |
| `rum_session_summaries ON CONFLICT (session_id)` | `UNIQUE(session_id)` ✓ (PK is `id`, ref's PK is `session_id`) | ok |
| `rum_app_settings ON CONFLICT (app_id)` | table missing | — |
| `rum_geo_rollup_* ON CONFLICT (app_id, geo_location_id, bucket_start)` | table missing | — |
| `rum_devices` partial unique `(device_id)` | column missing | processor dedupes devices by it |

## Blocking objects

- **View `analytics.v_mobile_rum_rca_evidence`** (other team's schema) depends on 8 touched tables and pins these columns against `ALTER COLUMN TYPE`: `rum_apps.{id,name,package_name,tenant_id,version}`, `rum_crash_events.{breadcrumbs,crash_hash,created_at,error_context,error_message,exception_type,is_fatal,session_id,severity_level}`, `rum_devices.{id,model,platform}`, `rum_http_requests.{duration_ms,method,request_timestamp,session_id,status_code,success,url}`, `rum_performance_events.{event_name,memory_pressure_level,memory_timestamp,memory_usage_mb,telemetry_event_id}`, `rum_performance_metrics.{frame_build_duration_ms,frame_dropped,frame_raster_duration_ms,metric_name,telemetry_event_id,value}`, `rum_sessions.{app_id,device_id,id,session_id}`, `rum_telemetry_events.{id,session_id,timestamp}`. `0003`'s capture-drop-recreate block already handles this pattern (it did drop/recreate this view before failing on `brand`).
- No hypertables, triggers, or rules on any `public.rum_*` table in v012.
- `rum_apps.tenant_id` / `rum_api_keys.tenant_id` FK → `core.tenants` (both v012 and ref) — the other team's table must have the tenant row.

## Type / nullability drift on existing columns

Only listed where it can bite; v012 being *looser* (nullable where ref is NOT NULL, unbounded/wider varchar) is harmless for Go writes.

| Column | v012 | Go needs (ref) | Risk |
|---|---|---|---|
| all `id` / FK cols on the 13 tables | `integer` | `bigint` | none now; overflow at 2^31. Retyping pinned by the view |
| `rum_performance_metrics.metric_name` | `varchar(100)` | `varchar(255) NOT NULL` | 22001 on long names; pinned by view |
| `rum_performance_events.event_name` | `varchar(100)` | `varchar(255) NOT NULL` | same |
| `rum_performance_events.memory_pressure_level` | `varchar(20)` | `varchar(50)` | 22001; pinned |
| `rum_sessions.network_type` | `varchar(20)` | `varchar(50)` | 22001 |
| `rum_performance_*.{value,memory_usage_mb,frame_*_ms}`, `rum_session_summaries.{avg,p95}_latency_ms,success_rate` | `numeric` | `double precision` | pgx scans either into float64; cosmetic. Pinned |
| `rum_crash_events.crash_hash` | `varchar(255) NOT NULL` | `varchar(64)` nullable | Go only reads |
| `rum_crash_events.breadcrumbs` | `jsonb` | `text` | analytics reads as text — check scan |
| `rum_api_keys.api_expires_at` | `NOT NULL` | nullable | collector reads only; never-expiring keys can't exist in v012 |
| `rum_telemetry_events.batch_timestamp` | nullable | `NOT NULL` | harmless |
| ON DELETE on several FKs (`SET NULL` vs `CASCADE`) | differs | — | only matters for retention deletes |

## Missing columns (v012 has the table, not the column)

- `rum_api_keys`: `api_key_name`
- `rum_apps`: — (but `package_name`, `version`, `build_number` nullable)
- `rum_crash_events`: `cause, device_id, error_code, geo_location_id, product_id`
- `rum_devices`: `android_release, android_sdk, brand, created_at, device_id, fingerprint, hardware, platform_version, product, user_id`
- `rum_http_requests`: `app_id, created_at, device_id, geo_location_id, parent_span_id, span_id, trace_adopted, trace_id, trace_injection, user_action_id, user_id` (+ 6 CHECKs, 6 indexes)
- `rum_navigation_events`: `app_id, created_at, device_id, has_arguments, route_type`
- `rum_performance_events`: `created_at, frame_build_duration_ms, frame_raster_duration_ms, frame_severity, frame_target_fps, frame_total_duration_ms`
- `rum_performance_metrics`: `created_at, frame_type, memory_source, memory_type, unit`
- `rum_screen_durations`: `app_id, created_at, device_id, source` (+ CHECK, index)
- `rum_session_summaries`: `calculated_at, navigation_total, p99_latency_ms, telemetry_total, unique_crash_hashes`
- `rum_sessions`: `app_version_id, created_at, end_time, geo_location_id, last_activity_at, location, metric_count, status, total_sessions, visited_screens` (+ 4 indexes)
- `rum_telemetry_events`: `attributes, created_at, event_name, geo_location_id, parent_span_id, rum_action_id, span_duration_ms, span_id, span_start_time, trace_id, trace_root_type` (+ GIN, action-id index)
- `rum_users`: `created_at, profile_data, profile_updated_at, profile_version` (+ `UNIQUE(user_id)`)

## Beyond public (noted, not diffed)

RUM Analytics Go also reads `rum.{sessions,errors,network_requests,web_vitals,pageviews,apps,user_actions,events}`, `traces.spans`, `core.{users,tenants}`, `alerts.{notification_channels,mobile_rum_*}`. These are the other team's schemas (v012 defines them) — out of this map's scope, but drift there breaks analytics reads too.

## Reproduce

```bash
docker run -d --name wf20pg -e POSTGRES_PASSWORD=x timescale/timescaledb-ha:pg17
docker exec wf20pg psql -U postgres -c 'create database edge_db'
docker cp edge_apm_sql_enterprise_v012.sql wf20pg:/tmp/ && docker exec wf20pg psql -U postgres -d edge_db -f /tmp/edge_apm_sql_enterprise_v012.sql
# ref: pre-create timescaledb (psql -X, own session), citext, uuid-ossp, pgcrypto, pg_trgm, schemas alerts/audit;
#      strip \restrict lines from edge_db_schema.sql (pg18 psql meta-command), then load.
```
