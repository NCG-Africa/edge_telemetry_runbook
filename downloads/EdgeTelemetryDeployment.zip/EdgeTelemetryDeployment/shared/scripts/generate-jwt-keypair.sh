#!/bin/bash
# Generate RS256 JWT keypair for EdgeTelemetry authentication
# Usage: ./generate-jwt-keypair.sh --output-dir ./jwt-keys

set -euo pipefail

OUTPUT_DIR="./jwt-keys"

while [[ $# -gt 0 ]]; do
    case $1 in
        --output-dir) OUTPUT_DIR="$2"; shift 2 ;;
        -h|--help)
            echo "Usage: $0 [OPTIONS]"
            echo ""
            echo "Options:"
            echo "  --output-dir DIR   Output directory (default: ./jwt-keys)"
            echo ""
            echo "Generates an RS256 keypair (private.pem + public.pem)."
            echo ""
            echo "After generation:"
            echo "  - Copy public.pem to:  deployments/segmented/dmz/secrets/jwt-public-keys/"
            echo "  - Copy both files to:  deployments/segmented/bank/secrets/jwt-signing-keys/"
            exit 0
            ;;
        *) echo "Unknown option: $1"; exit 1 ;;
    esac
done

mkdir -p "$OUTPUT_DIR"

echo "Generating RS256 JWT keypair..."
echo "  Output: $OUTPUT_DIR"

# Generate private key (RSA 2048-bit)
openssl genpkey \
    -algorithm RSA \
    -pkeyopt rsa_keygen_bits:2048 \
    -out "$OUTPUT_DIR/private.pem"

# Extract public key
openssl rsa \
    -in "$OUTPUT_DIR/private.pem" \
    -pubout \
    -out "$OUTPUT_DIR/public.pem"

# Set restrictive permissions on private key
chmod 600 "$OUTPUT_DIR/private.pem"
chmod 644 "$OUTPUT_DIR/public.pem"

echo ""
echo "JWT keypair generated:"
echo "  Private key: $OUTPUT_DIR/private.pem (600 permissions)"
echo "  Public key:  $OUTPUT_DIR/public.pem  (644 permissions)"
echo ""
echo "Fingerprint (for verification across zones):"
openssl rsa -in "$OUTPUT_DIR/public.pem" -pubin -outform DER 2>/dev/null | openssl dgst -sha256 | awk '{print $2}'
echo ""
echo "Next steps:"
echo "  1. Copy public.pem to:  deployments/segmented/dmz/secrets/jwt-public-keys/"
echo "  2. Copy both files to:  deployments/segmented/bank/secrets/jwt-signing-keys/"
echo "  3. Verify fingerprint matches on both sides with: ./verify-key-fingerprint.sh"
