#!/bin/bash
# Issue Kafka server certificate and create JKS keystores for DMZ deployment
# Usage: ./issue-kafka-server-cert.sh --ca-cert ./ca/ca-cert.pem --ca-key ./ca/ca-key.pem --fqdn kafka.dmz.example.com --output-dir ./dmz-certs

set -euo pipefail

CA_CERT=""
CA_KEY=""
FQDN=""
OUTPUT_DIR="./kafka-server-certs"
KEYSTORE_PASS="changeit"
VALIDITY_DAYS=365

while [[ $# -gt 0 ]]; do
    case $1 in
        --ca-cert) CA_CERT="$2"; shift 2 ;;
        --ca-key) CA_KEY="$2"; shift 2 ;;
        --fqdn) FQDN="$2"; shift 2 ;;
        --output-dir) OUTPUT_DIR="$2"; shift 2 ;;
        --keystore-pass) KEYSTORE_PASS="$2"; shift 2 ;;
        --validity-days) VALIDITY_DAYS="$2"; shift 2 ;;
        -h|--help)
            echo "Usage: $0 [OPTIONS]"
            echo ""
            echo "Required:"
            echo "  --ca-cert FILE         CA certificate PEM file"
            echo "  --ca-key FILE          CA private key PEM file"
            echo "  --fqdn HOSTNAME        Kafka server FQDN (e.g., kafka.dmz.example.com)"
            echo ""
            echo "Optional:"
            echo "  --output-dir DIR       Output directory (default: ./kafka-server-certs)"
            echo "  --keystore-pass PASS   Keystore password (default: changeit)"
            echo "  --validity-days DAYS   Certificate validity (default: 365)"
            exit 0
            ;;
        *) echo "Unknown option: $1"; exit 1 ;;
    esac
done

if [[ -z "$CA_CERT" || -z "$CA_KEY" || -z "$FQDN" ]]; then
    echo "ERROR: --ca-cert, --ca-key, and --fqdn are required"
    exit 1
fi

mkdir -p "$OUTPUT_DIR"
WORK_DIR=$(mktemp -d)
trap "rm -rf $WORK_DIR" EXIT

echo "Issuing Kafka server certificate..."
echo "  FQDN: $FQDN"
echo "  CA cert: $CA_CERT"
echo "  Output: $OUTPUT_DIR"

# Step 1: Generate server keystore with keypair
echo "[1/5] Generating server keystore..."
keytool -genkey -noprompt \
    -alias kafka-server \
    -dname "CN=$FQDN,O=EdgeTelemetry,OU=DMZ" \
    -keystore "$OUTPUT_DIR/kafka.server.keystore.jks" \
    -keyalg RSA \
    -keysize 2048 \
    -validity "$VALIDITY_DAYS" \
    -storepass "$KEYSTORE_PASS" \
    -keypass "$KEYSTORE_PASS" \
    -ext "SAN=DNS:$FQDN,DNS:kafka,DNS:localhost"

# Step 2: Generate CSR from keystore
echo "[2/5] Generating certificate signing request..."
keytool -certreq \
    -alias kafka-server \
    -keystore "$OUTPUT_DIR/kafka.server.keystore.jks" \
    -file "$WORK_DIR/server.csr" \
    -storepass "$KEYSTORE_PASS" \
    -keypass "$KEYSTORE_PASS" \
    -ext "SAN=DNS:$FQDN,DNS:kafka,DNS:localhost"

# Step 3: Sign the CSR with the CA
echo "[3/5] Signing certificate with CA..."
openssl x509 -req \
    -in "$WORK_DIR/server.csr" \
    -CA "$CA_CERT" \
    -CAkey "$CA_KEY" \
    -CAcreateserial \
    -out "$WORK_DIR/server-signed.pem" \
    -days "$VALIDITY_DAYS" \
    -extensions v3_req \
    -extfile <(cat <<EOF
[v3_req]
subjectAltName = DNS:$FQDN,DNS:kafka,DNS:localhost
EOF
)

# Step 4: Import CA cert and signed cert into keystore
echo "[4/5] Importing certificates into keystore..."
keytool -import -noprompt \
    -alias ca-root \
    -file "$CA_CERT" \
    -keystore "$OUTPUT_DIR/kafka.server.keystore.jks" \
    -storepass "$KEYSTORE_PASS"

keytool -import -noprompt \
    -alias kafka-server \
    -file "$WORK_DIR/server-signed.pem" \
    -keystore "$OUTPUT_DIR/kafka.server.keystore.jks" \
    -storepass "$KEYSTORE_PASS" \
    -keypass "$KEYSTORE_PASS"

# Step 5: Create truststore with CA cert
echo "[5/5] Creating truststore..."
keytool -import -noprompt \
    -alias ca-root \
    -file "$CA_CERT" \
    -keystore "$OUTPUT_DIR/kafka.server.truststore.jks" \
    -storepass "$KEYSTORE_PASS"

echo ""
echo "Kafka server certificates generated:"
echo "  Keystore:   $OUTPUT_DIR/kafka.server.keystore.jks"
echo "  Truststore: $OUTPUT_DIR/kafka.server.truststore.jks"
echo ""
echo "Copy these to: deployments/segmented/dmz/secrets/kafka-tls/"
echo "Update KAFKA_KEYSTORE_PASSWORD in deployments/segmented/dmz/.env to: $KEYSTORE_PASS"
