# Shared Secrets Tooling

Scripts for provisioning the security material used by the `segmented`
deployment: a private CA and Kafka mTLS certs (server-side JKS for the broker,
client-side PEM for the Go processor and RUM Analytics). There is no collector
JWT any more: the collector authenticates API keys it reads from `rum-api-keys`.

## Order of operations

1. **Generate the CA** (once):
   ```bash
   ./scripts/generate-ca.sh --output-dir ./ca
   ```

2. **Issue the Kafka server certificate** (DMZ broker, JKS):
   ```bash
   ./scripts/issue-kafka-server-cert.sh \
     --ca-cert ./ca/ca-cert.pem --ca-key ./ca/ca-key.pem \
     --fqdn dmz-kafka.example.com \
     --output-dir ../deployments/segmented/dmz/secrets/kafka-tls
   ```

3. **Issue the Kafka client certificate** (bank processor, PEM):
   ```bash
   ./scripts/issue-kafka-client-cert.sh \
     --ca-cert ./ca/ca-cert.pem --ca-key ./ca/ca-key.pem \
     --client-name bank-processor \
     --output-dir ../deployments/segmented/bank/secrets/kafka-tls
   ```

4. **Issue RUM Analytics its own Kafka client certificate** (bank analytics, PEM):
   ```bash
   ./scripts/issue-kafka-client-cert.sh \
     --ca-cert ./ca/ca-cert.pem --ca-key ./ca/ca-key.pem \
     --client-name bank-analytics \
     --output-dir ../deployments/segmented/bank/secrets/kafka-tls-analytics
   ```
   Never copy the processor's cert here (bank `make config-check` refuses one).
   Analytics produces API keys to `rum-api-keys` on the DMZ Kafka, and
   `CN=bank-analytics` is the principal the ACL upgrade below would grant.

5. **Install the pre-commit hook** (blocks accidentally committing secrets):
   ```bash
   ./scripts/install-pre-commit-hook.sh
   ```

## Why the client cert is PEM, not JKS

The DMZ Kafka broker is the Confluent/Java image and needs a JKS keystore —
that's what `issue-kafka-server-cert.sh` produces, unchanged from the Python
deployment. The bank-side consumer here is `EdgeTelemetryProcessorGo`, a Go
binary using `crypto/tls`, which reads PEM directly and has no JKS support.
`issue-kafka-client-cert.sh` therefore skips `keytool` and issues PEM output.

## Known limit: no ACLs on `rum-api-keys`

The DMZ broker runs no authorizer. Any holder of a cert this CA signed (the
processor, analytics, a future client) can produce to `rum-api-keys`, so a
stolen bank cert could inject a forged API key that the DMZ collector accepts.
Accepted for now: a compromised collector can already inject telemetry, so this
adds nothing. Upgrade path if a client demands it: enable
`StandardAuthorizer` on the broker and grant write on `rum-api-keys` to
`User:OU=Bank,O=EdgeTelemetry,CN=bank-analytics` (the RFC 2253 form Kafka uses) only (read stays open to the
collectors). Not built.
