# DMZ Secrets

One subdirectory, populated by `shared/scripts/` (see `shared/README.md`):

- `kafka-tls/` — the DMZ Kafka broker's JKS keystore + truststore
  (`kafka.server.keystore.jks`, `kafka.server.truststore.jks`), from
  `issue-kafka-server-cert.sh`.

Never commit real files here — only this README is tracked; `.gitignore` at
the repo root blocks `*.jks` and `*.pem`.
