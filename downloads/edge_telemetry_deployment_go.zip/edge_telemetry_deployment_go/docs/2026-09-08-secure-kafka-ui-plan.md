# Secure the Kafka UI — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Remove the unauthenticated, internet-facing, write-capable Kafka UI from the production host and replace it with a loopback-only, read-only, password-protected, maintained image reached over an SSH tunnel.

**Architecture:** Four edits to the `kafka-ui` service in `deployments/single-host/docker-compose.yml` (bind port to `127.0.0.1`, swap `provectuslabs/kafka-ui:latest` → pinned `ghcr.io/kafbat/kafka-ui`, add `KAFKA_CLUSTERS_0_READONLY`, add `LOGIN_FORM` auth backed by a new env var). Matching doc/Makefile updates so operators know the new SSH-tunnel access path. The local-dev root compose gets only the image pin + read-only change (it keeps its published port on purpose). No application code, no schema, no data-path impact — kafka-ui is a stateless sidecar.

**Tech Stack:** Docker Compose v2, Make, `kafbat/kafka-ui` (Spring Boot), SSH local port forwarding.

## Global Constraints

- Design source of truth: `EdgeTelemetryDeploymentGo/docs/2026-09-08-secure-kafka-ui-design.md`. Every task's requirements implicitly include it.
- **Production target is `deployments/single-host/docker-compose.yml` only.** The Python `EdgeTelemetryDeployment` repo is retired. The segmented `dmz/bank` topology is not deployed.
- App server: `102.164.37.226`, SSH on port `2222` as `jonathan`, public IP, **no host firewall**. The DB is not reachable from the dev machine — all host commands are handed to the user to run.
- kafbat/kafka-ui basic auth supports exactly **one** local user and is incompatible with RBAC/OAuth. Username is `admin`.
- Pin the kafka-ui image to an **exact released tag** of `ghcr.io/kafbat/kafka-ui` (confirm the current stable tag at implementation time; do not use `latest`).
- Real env files (`configs/single-host.env`) are gitignored — never commit a real password. Only `*.env.example` is tracked.
- Repo: `EdgeTelemetryDeploymentGo`, work on branch `dev`. Commit after every task.
- Keep `KAFKA_CLUSTERS_0_ZOOKEEPER` lines untouched — out of scope.

---

### Task 1: Confirm the kafbat image tag and auth/read-only env var names

**Files:** none (research task, no commit)

**Interfaces:**
- Produces: `KAFBAT_IMAGE` — the exact image ref used verbatim in Tasks 2 and 5, e.g. `ghcr.io/kafbat/kafka-ui:v1.3.0`.

- [ ] **Step 1: Find the current stable kafbat/kafka-ui tag**

Open `https://github.com/kafbat/kafka-ui/releases` (or `https://ghcr.io/kafbat/kafka-ui`). Pick the newest non-pre-release tag (form `vX.Y.Z`). Record it as `KAFBAT_IMAGE=ghcr.io/kafbat/kafka-ui:vX.Y.Z`.

- [ ] **Step 2: Confirm the config keys still apply**

On `https://ui.docs.kafbat.io/configuration/`, confirm these env keys for that version:
- `AUTH_TYPE=LOGIN_FORM`, `SPRING_SECURITY_USER_NAME`, `SPRING_SECURITY_USER_PASSWORD` (basic auth)
- `KAFKA_CLUSTERS_0_READONLY=true` (read-only cluster)

Expected: all four documented. If a key was renamed in the chosen version, use the documented name and note the deviation in the task commit messages that follow.

- [ ] **Step 3: Record the values**

Write the confirmed `KAFBAT_IMAGE` value and any key deviations into a scratch note for the following tasks. No commit.

---

### Task 2: Harden the production single-host compose

**Files:**
- Modify: `deployments/single-host/docker-compose.yml` (the `kafka-ui:` service block, currently lines 179–198)
- Modify: `deployments/single-host/configs/single-host.env.example` (append a new block after line 45)

**Interfaces:**
- Consumes: `KAFBAT_IMAGE` from Task 1.
- Produces: env var `KAFKA_UI_PASSWORD`, read by the `kafka-ui` service via `env_file: ./configs/single-host.env`.

- [ ] **Step 1: Replace the `kafka-ui` service block**

In `deployments/single-host/docker-compose.yml`, replace the entire current block:

```yaml
  kafka-ui:
    image: provectuslabs/kafka-ui:latest
    container_name: telemetry-go-kafka-ui
    depends_on:
      kafka:
        condition: service_healthy
    ports:
      - "8090:8080"
    environment:
      KAFKA_CLUSTERS_0_NAME: telemetry-go-production
      KAFKA_CLUSTERS_0_BOOTSTRAPSERVERS: kafka:29092
      KAFKA_CLUSTERS_0_ZOOKEEPER: zookeeper:2181
    networks:
      - telemetry-go-network
    restart: unless-stopped
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"
```

with (substitute the real `KAFBAT_IMAGE` from Task 1 for `ghcr.io/kafbat/kafka-ui:vX.Y.Z`):

```yaml
  kafka-ui:
    # kafbat/kafka-ui is the maintained community continuation of the archived
    # provectuslabs/kafka-ui. Pinned (never :latest) — see
    # docs/2026-09-08-secure-kafka-ui-design.md.
    image: ghcr.io/kafbat/kafka-ui:vX.Y.Z
    container_name: telemetry-go-kafka-ui
    depends_on:
      kafka:
        condition: service_healthy
    ports:
      # Loopback only: reachable from the host, not the public interface.
      # Access via SSH tunnel — see deployments/single-host/README.md.
      - "127.0.0.1:8090:8080"
    env_file:
      - ./configs/single-host.env
    environment:
      KAFKA_CLUSTERS_0_NAME: telemetry-go-production
      KAFKA_CLUSTERS_0_BOOTSTRAPSERVERS: kafka:29092
      KAFKA_CLUSTERS_0_ZOOKEEPER: zookeeper:2181
      KAFKA_CLUSTERS_0_READONLY: "true"
      AUTH_TYPE: LOGIN_FORM
      SPRING_SECURITY_USER_NAME: admin
      SPRING_SECURITY_USER_PASSWORD: ${KAFKA_UI_PASSWORD:?KAFKA_UI_PASSWORD must be set in configs/single-host.env}
    networks:
      - telemetry-go-network
    restart: unless-stopped
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"
```

- [ ] **Step 2: Append the env-example block**

At the end of `deployments/single-host/configs/single-host.env.example`, append:

```bash

# ===== Kafka UI =====
# Login password for the Kafka UI (username: admin). The UI is bound to
# 127.0.0.1 and reached only through an SSH tunnel; this password is a second
# layer so host access alone does not grant UI access.
# Generate one:  openssl rand -base64 24
KAFKA_UI_PASSWORD=
```

- [ ] **Step 3: Validate compose interpolation fails closed**

Run from `deployments/single-host/`:

```bash
docker compose --env-file /dev/null config >/dev/null
```

Expected: **error** mentioning `KAFKA_UI_PASSWORD must be set in configs/single-host.env` (proves the `:?` guard works). If it succeeds silently, the guard syntax is wrong — fix it.

- [ ] **Step 4: Validate compose parses with the var set**

Run from `deployments/single-host/`:

```bash
KAFKA_UI_PASSWORD=dummy docker compose config | grep -A25 'kafka-ui:'
```

Expected: PASS. Output shows `127.0.0.1:8090`, the kafbat image, `KAFKA_CLUSTERS_0_READONLY: "true"`, `AUTH_TYPE: LOGIN_FORM`, and `SPRING_SECURITY_USER_PASSWORD: dummy`.

- [ ] **Step 5: Commit**

```bash
git add deployments/single-host/docker-compose.yml deployments/single-host/configs/single-host.env.example
git commit -m "Harden production kafka-ui: loopback bind, kafbat image, read-only, login auth

Co-Authored-By: Claude Sonnet 5 <noreply@anthropic.com>"
```

---

### Task 3: Update single-host operator docs and Makefile banners

**Files:**
- Modify: `deployments/single-host/Makefile` (deploy banner ~line 84, deploy-rhel banner ~line 332)
- Modify: `deployments/single-host/README.md` (Service URLs table, line 17–24)
- Modify: `README.md` (root — port table line 89, Security section line 95–107)

**Interfaces:**
- Consumes: nothing.
- Produces: nothing (docs only).

- [ ] **Step 1: Fix the Makefile `deploy` banner**

In `deployments/single-host/Makefile`, find (in the `deploy:` target, ~line 81–86):

```make
	@echo "Service URLs:"
	@echo "  Collector API:  http://localhost:8011"
	@echo "  Processor API:  http://localhost:8012"
	@echo "  Kafka UI:       http://localhost:8090"
	@echo ""
```

Replace the `Kafka UI` line with:

```make
	@echo "  Kafka UI:       not publicly exposed - SSH tunnel then http://localhost:8090"
	@echo "                  ssh -p 2222 -L 8090:localhost:8090 jonathan@<host>"
```

- [ ] **Step 2: Fix the Makefile `deploy-rhel` banner**

In the same file, the `deploy-rhel:` target has an identical `Service URLs:` block (~line 329–333). Apply the exact same replacement to its `Kafka UI` line.

- [ ] **Step 3: Fix the single-host README Service URLs table**

In `deployments/single-host/README.md`, the table at lines 19–24. Replace the Kafka UI row:

```markdown
| Kafka UI | http://localhost:8090 |
```

with:

```markdown
| Kafka UI | Not publicly exposed. `ssh -p 2222 -L 8090:localhost:8090 jonathan@<host>` then http://localhost:8090 (login: `admin` / `KAFKA_UI_PASSWORD`) |
```

- [ ] **Step 4: Add an access note under the table**

Immediately after the table in `deployments/single-host/README.md`, add:

```markdown

The Kafka UI is bound to `127.0.0.1` on the host and runs in read-only mode with
a login password (`KAFKA_UI_PASSWORD` in `configs/single-host.env`). Reach it by
opening an SSH local-forward to the host, then browsing to the forwarded port.
See `../../docs/2026-09-08-secure-kafka-ui-design.md`.
```

- [ ] **Step 5: Fix the root README**

In `README.md` (repo root), line 89, change:

```markdown
| Kafka UI | 8090 | ✓ | DMZ |
```

to:

```markdown
| Kafka UI | 8090 (127.0.0.1 only) | ✓ | DMZ |
```

Then in the `## Security` section (after line 105, before the "Generate everything via" line), add a new bullet:

```markdown
- **Kafka UI** — single-host mode binds it to `127.0.0.1` (SSH-tunnel access
  only), runs it read-only, and requires a login password
  (`KAFKA_UI_PASSWORD`). It is never published on the public interface.
```

- [ ] **Step 6: Sanity-check no stale public URL remains**

```bash
grep -rn '8090' deployments/single-host/ README.md
```

Expected: every remaining hit is either the loopback form `127.0.0.1:8090` / `localhost:8090`, or the SSH-tunnel command. No bare `<host>:8090` or unqualified "http://...:8090" implying public reachability.

- [ ] **Step 7: Commit**

```bash
git add deployments/single-host/Makefile deployments/single-host/README.md README.md
git commit -m "Docs: kafka-ui is SSH-tunnel-only in single-host mode

Co-Authored-By: Claude Sonnet 5 <noreply@anthropic.com>"
```

---

### Task 4: Pin the image and set read-only in the local-dev compose

**Files:**
- Modify: `docker-compose.yml` (repo root — the `kafka-ui:` service block, currently lines 122–136)

**Interfaces:**
- Consumes: `KAFBAT_IMAGE` from Task 1.
- Produces: nothing.

Rationale: the root compose is a local build/run convenience, not internet-facing. It keeps its published `8090:8080` port for dev ergonomics and needs no auth. It still gets the maintained image (kills the RCE even on a laptop) and read-only mode (so a dev can't accidentally nuke a topic).

- [ ] **Step 1: Edit the dev `kafka-ui` block**

In root `docker-compose.yml`, change:

```yaml
  kafka-ui:
    image: provectuslabs/kafka-ui:latest
    container_name: telemetry-go-dev-kafka-ui
```

to (real `KAFBAT_IMAGE`):

```yaml
  kafka-ui:
    image: ghcr.io/kafbat/kafka-ui:vX.Y.Z
    container_name: telemetry-go-dev-kafka-ui
```

and add one line to its `environment:` block, after `KAFKA_CLUSTERS_0_ZOOKEEPER`:

```yaml
      KAFKA_CLUSTERS_0_READONLY: "true"
```

Leave `ports: - "8090:8080"` as-is.

- [ ] **Step 2: Validate**

```bash
docker compose -f docker-compose.yml config | grep -A15 'telemetry-go-dev-kafka-ui'
```

Expected: PASS; shows the kafbat image and `KAFKA_CLUSTERS_0_READONLY: "true"`, still `8090:8080` (no bind address).

- [ ] **Step 3: Commit**

```bash
git add docker-compose.yml
git commit -m "Local-dev compose: pin kafbat kafka-ui image, read-only cluster

Co-Authored-By: Claude Sonnet 5 <noreply@anthropic.com>"
```

---

### Task 5: Update the cross-repo deployment runbook

**Files:**
- Modify: `../real-user-monitoring/docs/07-deployment.md` (platform docs — the "Runbook: is data flowing?" section and the "Operational gaps" bullet)

Note: this file is in the parent `real-user-monitoring` docs tree, **not** in `EdgeTelemetryDeploymentGo`. It is not under version control at the repo root (`real-user-monitoring` is not a git repo). Edit in place; there is nothing to commit. If that changes, commit it wherever it now lives.

**Interfaces:**
- Consumes: nothing.
- Produces: nothing.

- [ ] **Step 1: Fix runbook step 2**

In `docs/07-deployment.md`, the "Runbook: is data flowing?" block, find:

```
# 2. Messages landing in Kafka
#    Kafka UI on :8080 → topic telemetry-upsert → check offsets advancing
```

Replace with:

```
# 2. Messages landing in Kafka
#    Kafka UI is loopback-only. From your machine:
#      ssh -p 2222 -L 8090:localhost:8090 jonathan@<host>
#    then http://localhost:8090 (login: admin) → topic telemetry-upsert →
#    check offsets advancing. (Read-only UI — you cannot produce/reset here.)
```

- [ ] **Step 2: Fix the "Operational gaps" bullet**

Find:

```
- **Consumer lag is invisible** except through Kafka UI on port 8080, manually.
```

Replace with:

```
- **Consumer lag is invisible** except through Kafka UI (loopback-only, via SSH
  tunnel on :8090), manually.
```

- [ ] **Step 3: Verify**

```bash
grep -n '8080\|8090\|Kafka UI' docs/07-deployment.md
```

Expected: no remaining implication that Kafka UI is directly reachable on a public port.

---

### Task 6: Deploy to the host and verify (operator-run)

**Files:** none — this task is a runbook the user executes on `102.164.37.226`. The agent produces the commands and checks the pasted output; it cannot reach the host.

**Interfaces:**
- Consumes: the merged branch from Tasks 2–4.

- [ ] **Step 1: Set the real password on the host**

Ask the user to run, on the app server, in the single-host deployment directory:

```bash
test -f configs/single-host.env || cp configs/single-host.env.example configs/single-host.env
grep -q '^KAFKA_UI_PASSWORD=' configs/single-host.env || echo "KAFKA_UI_PASSWORD=$(openssl rand -base64 24)" >> configs/single-host.env
grep '^KAFKA_UI_PASSWORD=' configs/single-host.env
```

Expected: prints a non-empty `KAFKA_UI_PASSWORD=...`. Have the user save that password in their password manager (login is `admin`).

- [ ] **Step 2: Pull the new code and recreate only kafka-ui**

```bash
git -C <repo path> pull
cd <repo path>/deployments/single-host
docker compose pull kafka-ui
docker compose up -d kafka-ui
docker compose ps kafka-ui
```

Expected: `docker compose ps kafka-ui` shows the container `Up` and the ports column reads `127.0.0.1:8090->8080/tcp` (NOT `0.0.0.0:8090`).

- [ ] **Step 3: Verify it is gone from the public interface**

From the **dev machine** (not the host):

```bash
curl -sS -m 5 http://102.164.37.226:8090/ ; echo "exit=$?"
```

Expected: connection refused or timeout, non-zero exit. If it returns HTML, STOP — the bind did not take effect.

- [ ] **Step 4: Verify tunnel + auth + read-only**

From the dev machine:

```bash
ssh -p 2222 -f -N -L 8090:localhost:8090 jonathan@102.164.37.226
curl -sS -I -m 5 http://localhost:8090/ ; echo "exit=$?"
```

Expected: HTTP `200` or a redirect to `/login`. Then in a browser at `http://localhost:8090`: a login form appears; `admin` + the saved password logs in; the cluster shows; the "Produce Message" action on any topic is absent or disabled.

Tear down the tunnel: `pkill -f '8090:localhost:8090'`.

- [ ] **Step 5: Verify the pipeline was untouched**

Have the user run on the host:

```bash
curl -s http://localhost:8012/health
docker compose logs --tail=20 telemetry-processor-go
```

Expected: processor healthy, still consuming — kafka-ui is not in the data path, so this is a formality.

- [ ] **Step 6: Record completion**

Note in `docs/2026-09-08-secure-kafka-ui-design.md` (Status line) that it shipped, with the date. Commit that one-line change.

---

## Self-Review

**Spec coverage:**
- Design Change 1 (loopback) → Task 2 Step 1, verified Task 6 Steps 2–3. ✓
- Design Change 2 (kafbat image) → Task 1, Task 2 Step 1, Task 4. ✓
- Design Change 3 (read-only) → Task 2 Step 1, Task 4 Step 1, verified Task 6 Step 4. ✓
- Design Change 4 (login form + env var + env_file + example) → Task 2 Steps 1–2, verified Task 6 Steps 1, 4. ✓
- Design Change 5 (runbook, Makefile, README, 07-deployment.md) → Tasks 3 and 5. ✓
- Design "Verification" table → Task 6 Steps 2–5. ✓
- Design "Rollout" → Task 6 Steps 1–2. ✓
- Follow-ups section → intentionally out of scope; not planned. ✓

**Placeholder scan:** `vX.Y.Z` is a deliberate stand-in resolved by Task 1 and flagged in Global Constraints; every other value is concrete. No TODO/TBD.

**Type consistency:** env var name `KAFKA_UI_PASSWORD` and username `admin` are identical across Tasks 2, 3, and 6. Image ref is `KAFBAT_IMAGE` everywhere, sourced once in Task 1.
