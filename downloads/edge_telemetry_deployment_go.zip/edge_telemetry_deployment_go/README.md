# EdgeTelemetry Deployment (Go)

Production deployment for the Go telemetry pipeline. Drop-in replacement for the
Python [`EdgeTelemetryDeployment`](../EdgeTelemetryDeployment): same container
names (`telemetry-*`), network (`telemetry-network`) and host ports; only the
images differ. Design rationale:
[`docs/2026-08-17-edge-telemetry-deployment-go-design.md`](docs/2026-08-17-edge-telemetry-deployment-go-design.md).

This README is the **deployment guide and on-call runbook** for the
**single-host** topology, the only one in active use. The segmented (DMZ/bank)
topology is documented in its own directory; see [Segmented deployment](#segmented-deployment).

**Contents**

1. [Architecture](#1-architecture)
2. [Deployment guide](#2-deployment-guide)
3. [Upgrade and rollback](#3-upgrade-and-rollback)
4. [Runbook](#4-runbook)
5. [Command reference](#5-command-reference)
6. [Security model](#6-security-model)
7. [Local development](#7-local-development)
8. [Segmented deployment](#segmented-deployment)

---

## 1. Architecture

```
                    ┌──────────────── single host ─────────────────────────────┐
 Mobile/edge app    │                                                          │
   │  HTTPS         │  nginx :443                                              │
   └──────────────► │   ├─ /collector-go/ ─► Collector-Go   127.0.0.1:8001     │
                    │   ├─ /processor-go/ ─► Processor-Go   127.0.0.1:8002     │
 Dashboard ───────► │   └─ /api/          ─► RUM Analytics  127.0.0.1:8003     │
                    │                                                          │
                    │  Collector-Go ──► Kafka (topic telemetry-upsert) ──►     │
                    │                   Processor-Go ──► PostgreSQL (external) │
                    │  RUM Analytics Go ◄── PostgreSQL + Redis                 │
                    └──────────────────────────────────────────────────────────┘
```

| Container | Image | Host port | Health endpoint | Role |
|---|---|---|---|---|
| `telemetry-collector` | `papijo/edge_telemetry_collector_go` (digest) | `127.0.0.1:8001` | `/ready` | Ingest API. Validates API keys from its in-memory copy of `rum-api-keys`, publishes to Kafka. Until caught up, `/ready` and ingest answer 503 + `Retry-After: 5` |
| `telemetry-processor` | `papijo/edge_telemetry_processor_go` (digest) | `127.0.0.1:8002` | `/health` | Kafka consumer. Runs DB migrations on start, writes `rum_*` tables |
| `telemetry-rum-analytics` | `papijo/edge_telemetry_rum_analytics_go` (digest) | `127.0.0.1:8003` | `/api/v1/health` | Dashboard API. Swagger at `/api/docs` |
| `telemetry-kafka` | `confluentinc/cp-kafka:7.4.0` | not published (29092 in-cluster) | `kafka-topics --list` | Message broker |
| `telemetry-kafka-init` | `confluentinc/cp-kafka:7.4.0` | — | exits 0 | One-shot: creates both topics, fixes config drift ([Kafka topics](#kafka-topics)) |
| `telemetry-zookeeper` | `confluentinc/cp-zookeeper:7.4.0` | not published | — | Kafka coordination |
| `telemetry-redis` | `redis:7.4.7-alpine` | not published | `redis-cli ping` | API-key cache, rate limits, RUM cache |
| `telemetry-kafka-ui` | `ghcr.io/kafbat/kafka-ui:v1.5.0` | `127.0.0.1:8080` | — | Read-only Kafka monitoring, login required |

**PostgreSQL is never bundled.** All three Go services connect to an external
`edge_db` via `DATABASE_URL`.

### Kafka topics

Broker auto-create is off. The one-shot `kafka-init` service
([`shared/scripts/kafka-init.sh`](shared/scripts/kafka-init.sh)) owns both
topics; collector, processor and RUM Analytics start only after it exits 0.
It is idempotent: it creates missing topics, then reapplies the full config
below. Compose runs it when its container is first created; to revert
hand-made topic changes later, run `make kafka-init`.

| Topic | Partitions | RF | Config |
|---|---|---|---|
| `telemetry-upsert` (`KAFKA_TOPIC`) | 12 | 1 | `retention.ms=604800000` (7 d), `retention.bytes=KAFKA_DISK_BUDGET_BYTES ÷ 12`, `compression.type=zstd` |
| `rum-api-keys` (`KAFKA_API_KEYS_TOPIC`) | 1 | 1 | `cleanup.policy=compact`, `segment.ms=3600000` (1 h), `delete.retention.ms=86400000` (1 d) |

`KAFKA_DISK_BUDGET_BYTES` (required, in `configs/single-host.env`) is the total
disk `telemetry-upsert` may use. `retention.bytes` is per partition, so
`kafka-init` sets it to the budget ÷ 12 (default `120000000000` → `10000000000`).
Kafka shares the disk with Postgres on single-host: leave Postgres headroom.
`config-check` and `kafka-init` both fail if it is missing or not a number.

**Partition count.** `telemetry-upsert` has 12 partitions in every install.
The one-time **1 → 12** grow of a pre-existing install is the only count
change ever allowed; `kafka-init` does it in place, keeping messages and
committed offsets. Any other count makes `kafka-init` fail, and the
dependent services stay down.

> **Never delete and recreate `telemetry-upsert`.** Recreating it restarts
> offsets at 0, and offset reuse breaks the processor's dedupe.

**HA (documented, not built).** Every topology runs 1 broker, RF 1, offsets
RF 1; durability comes from `acks=all`, the disk and SDK offline retry. The
HA path is 3 brokers on separate hosts, RF 3, `min.insync.replicas=2`,
offsets RF 3. The partition count stays 12.

---

## 2. Deployment guide

Follow these steps in order for a first deployment on a new host. For a
redeploy on an existing host, skip to [Upgrade and rollback](#3-upgrade-and-rollback).

### 2.1 Prerequisites

| Requirement | Detail |
|---|---|
| OS | Ubuntu (the bootstrap script assumes apt) |
| Docker | 27.5+ with Compose v2 |
| Resources | 2 GB RAM, 10 GB free disk |
| PostgreSQL | Existing `edge_db`, reachable **from inside containers** (not `localhost`). The DB role must own the `public.rum_*` tables and `analytics.v_mobile_rum_rca_evidence` |
| JWT secret | The exact `EDGE_JWT_SECRET` used by `edge_platform` |
| sudo | `make deploy` creates `/opt/edge-telemetry/` with sudo |
| Python stack | Must be **stopped** (`make down` in its single-host dir). Both stacks use the same names and ports and cannot run together |

### 2.2 Bootstrap the host (once per host)

```bash
./getstarted.sh            # installs Docker from Docker's apt repo, prepares /opt/edge-telemetry
```

### 2.3 Clone and configure

```bash
git clone <repo-url> && cd edge_telemetry_deployment_go/deployments/single-host
cp configs/single-host.env.example configs/single-host.env
cp configs/kafka-ui.env.example    configs/kafka-ui.env
```

Edit `configs/single-host.env`. One file serves all three Go services.

| Variable | Set to | Notes |
|---|---|---|
| `DATABASE_URL` | `postgresql://USER:PASS@HOST:5432/edge_db` | `+asyncpg` suffix is accepted. Host must resolve from inside Docker |
| `REDIS_PASSWORD` | `openssl rand -base64 24` | Deploy aborts if unset or `CHANGE_ME` |
| `EDGE_JWT_SECRET` | edge_platform's value, byte for byte | Mismatch means every dashboard request returns 401 |
| `EDGE_ENV` | `prod` | Enforces the JWT checks below |
| `EDGE_ALLOW_JWT_FALLBACK` | `false` | `true` is rejected in prod |
| `ALLOWED_ORIGINS` / `CORS_ALLOWED_ORIGINS` | Dashboard and app origins | RUM reads the first, Collector reads the second |
| `TRUSTED_PROXIES` | Keep the default | Without it the collector sees nginx as the client: no geo, one shared rate-limit bucket |

**Do not set** `EDGE_JWT_ISSUER` or `EDGE_JWT_AUDIENCE`. edge_platform tokens
carry no `iss`/`aud`, so setting either rejects every token.

Set the Kafka UI login password:

```bash
echo "SPRING_SECURITY_USER_PASSWORD=$(openssl rand -base64 24)" >> configs/kafka-ui.env
```

Validate before going further:

```bash
make config-check
```

### 2.4 Baseline the database (once per database)

The Go services need a newer schema than the v012 `edge_db`. Processor-Go's
own migrations **fail on a raw v012 database** (migration `0003` aborts on
missing `rum_devices.brand`), so apply the baseline first. Background:
[`docs/2026-10-06-v012-schema-drift.md`](docs/2026-10-06-v012-schema-drift.md).

```bash
make db-baseline
```

The script runs a pre-flight for duplicate `rum_apps.package_name` and
`rum_users.user_id` rows, prompts for confirmation, then applies
`shared/sql/go_baseline.sql` in a single transaction. It drops and recreates
`analytics.v_mobile_rum_rca_evidence`. Idempotent; re-running is a no-op.

`make deploy` refuses to proceed until the baseline is applied.

### 2.5 Deploy

```bash
make deploy
```

What it does, in order:

1. `config-check`: validates env files and secrets.
2. Baseline check: aborts if step 2.4 was skipped.
3. Creates `/opt/edge-telemetry/{data,logs}`.
4. `docker compose up -d`, then waits 60 s.
5. Detailed health check; restarts the processor once if it is unhealthy.

### 2.6 Wire up nginx

Services bind to `127.0.0.1` only; nginx terminates TLS and proxies. A
reference vhost is in
[`deployments/single-host/configs/nginx sample example.txt`](deployments/single-host/configs/nginx%20sample%20example.txt).

| Path | Upstream |
|---|---|
| `/collector-go/` | `http://127.0.0.1:8001/` (trailing slash strips the prefix) |
| `/processor-go/` | `http://127.0.0.1:8002/` |
| `/api/` | `http://127.0.0.1:8003` (no trailing slash: RUM expects the `/api` prefix) |

```bash
sudo nginx -t && sudo systemctl reload nginx
```

> **Gotcha:** vhosts in `sites-enabled/` are usually symlinks. `grep -r` skips
> them. Find the real file with `readlink -f /etc/nginx/sites-enabled/<site>`
> or inspect the loaded config with `sudo nginx -T`.

### 2.7 Verify

Run on the host. Every check must pass before you call the deploy done.

```bash
make health                                        # collector ready, processor + analytics healthy
make test-deployment                               # POSTs a sample event, tails processor logs
curl -fsS https://<domain>/collector-go/ready      # nginx → collector (keys loaded)
curl -fsS https://<domain>/api/v1/health           # nginx → RUM analytics
```

Then confirm in the database that the test event landed:

```sql
SELECT max(created_at) FROM rum_telemetry_events;
```

---

## 3. Upgrade and rollback

Images are pinned: first-party by digest, third-party by exact tag. CI
(`image-pins` job) rejects unpinned images. An upgrade is therefore always a
change to `deployments/single-host/docker-compose.yml`, merged through a PR.

**Upgrade**

```bash
cd deployments/single-host
git pull                    # brings in the new digests
make update
```

`make update` is stop-the-world. Ingest is down from step 2 to step 6:
nginx returns 502 and the SDKs queue events offline and retry.

1. `config-check`, then pull the pinned images (before anything stops).
2. Stop the collector. No new messages reach Kafka.
3. Drain: poll the processor group's lag (`make kafka-lag`) until it is 0.
   After `DRAIN_TIMEOUT_SECONDS` (default 1800) it gives up, exits non-zero
   and leaves the collector **stopped** and the topic untouched (it also
   stops at once if the lag can't be read). Fix the processor, then
   `make update` again to resume. To give up instead, restore the previous
   `docker-compose.yml` and run `make deploy`. Plain `make deploy` would start
   the newly pulled images without this ordering.
4. Stop the processor and analytics. Write the group's offsets to
   `backups/offsets-<ts>-before.txt`.
5. `kafka-init`: creates `rum-api-keys`, grows `telemetry-upsert` from 1 to 12
   partitions (first upgrade only) and reapplies topic config. Must exit 0.
6. Start analytics (migrates the shared `rum_*` tables), then the processor
   (its own migrations), then the collector, each waiting for healthy.
   Write `backups/offsets-<ts>-after.txt` and print it.

Partition 0's committed offset in the *after* file must equal the *before*
file. Partitions 1-11 show no committed offset until they receive traffic;
the processor reads them from offset 0 (`KAFKA_AUTO_OFFSET_RESET=earliest`).
Running `make update` with nothing to upgrade is safe: it drains, `kafka-init`
changes nothing and everything comes back.

> Never run `docker compose down -v` or `make clean` on a live install, never
> delete the `kafka-data` volume, and never delete or recreate
> `telemetry-upsert`. Each loses queued messages and the processor's committed
> offsets.

**Rollback**

Once `telemetry-upsert` has 12 partitions and the new migrations have run,
there is no topic or schema rollback. You can roll back images:

```bash
git log --oneline -- docker-compose.yml     # find the last good commit
git checkout <good-sha> -- docker-compose.yml
make update
```

Restore `docker-compose.yml` to `main` once a fixed release is merged.

> An older processor image reads all 12 partitions with one reader: safe but
> slower. Rolling back the **processor** or **analytics** does not undo
> migrations they already applied (`schema_migrations`,
> `analytics_schema_migrations`). Confirm the older image works with the
> newer schema before rolling back across a migration.

**Acceptance run**

Run after the upgrade (U3) and before announcing 4.0 SDK availability (S2).
It proves the whole release with curl-built batches; no SDK build is needed.
Scripts: `shared/scripts/acceptance/`.

> It writes Apps, API keys and telemetry into this install's database and
> Kafka. **Never run it against a client install without the operator's
> consent.** Every script refuses unless `ACCEPTANCE_OK=yes`.

Prerequisites: `docker`, `curl`, `jq`, `openssl` on the host; the stack up and
healthy; a `core.tenants` id and an active `core.users` id of that tenant
(the JWT's `sub`).

```bash
cd deployments/single-host
export ACCEPTANCE_OK=yes ACCEPTANCE_TENANT_ID=<tenant uuid> ACCEPTANCE_USER_ID=<user uuid>
make acceptance            # X1-X5 and XV; one PASS/FAIL line per check, exit 1 on any FAIL
make acceptance-clean      # RUN_ID=<id> for one run, RUN_ID=all for every run
```

| Check | Proves |
|---|---|
| X1 | A 4.0 batch with an App-bound key: headers, session `app_id`/`environment`, `rum_app_versions` row |
| XV | Analytics `?version=` and per-version experience return X1's session |
| X2 | A legacy batch with a legacy key lands on the App matching `(package_name, lower(device.platform))`; unmatched it dead-letters as `<app-not-registered>` and replays once the App exists |
| X3 | A revoked key gets 401 from the collector within 10s, with no restart |
| X4 | Re-consuming a Kafka message and replaying a dead-letter row twice add no rows |
| X5 | Rapid batches plus a late offline batch from one device share one partition in send order; LWW device context and session geo keep the newest event time |
| X6 | `make update` from a pre-effort install loses and duplicates nothing ([U3](#3-upgrade-and-rollback)) |

Each run tags its data with `RUN_ID` (default: a timestamp): devices
`acc-<RUN_ID>-*`, packages `com.acceptance.r<RUN_ID>.*`, Apps
`acceptance-<RUN_ID>-*`. API keys and the JWT are masked in the output and in
`backups/acceptance-<RUN_ID>.log`. X2 and X6 insert a legacy key by SQL and
restart analytics to republish it to `rum-api-keys`. Cleanup revokes those through
`POST /api/v1/api-keys/revoke`, the one key route outside
`/api/v1/rum/mobile/apps/{app_id}/api-keys` (that route 404s for a key with no App).

**X6** (`make acceptance-x6`) runs `make update` on the install, so it needs a
disposable host on the pre-effort release: deployment commit `5978c36`
(1-partition `telemetry-upsert`) on a baselined v012 database. Deploy it, then
run X6 from a checkout of the new release:

```bash
git show 5978c36:deployments/single-host/docker-compose.yml > pre-effort.yml
docker compose --env-file configs/single-host.env -f pre-effort.yml up -d --wait
make acceptance-x6          # then make acceptance on the upgraded stack
```

It queues legacy batches in partition 0 with the processor stopped (the update's
drain consumes them), posts more while `make update` has the collector down (the
SDK offline queue), and re-posts those after the update with the processor held
stopped, so they sit on partitions 1-11 until its next assignment. It then checks
partition 0's committed offset is unchanged, partitions 1-11 were read from
offset 0, and the event count is exact. No App is registered for the package:
the pre-effort processor created it, as on a real install.

---

## 4. Runbook

### 4.1 Triage: start here

```bash
cd deployments/single-host
make status          # which containers are up / restarting
make health          # which endpoints answer
make logs-<service>  # collector | processor | rum-analytics | redis | kafka
```

Use the symptom table to jump to a procedure.

| Symptom | Likely cause | Go to |
|---|---|---|
| Processor in a restart loop, logs mention `dirty` | Failed migration | [4.2](#42-processor-will-not-start-dirty-migration) |
| `make deploy` stops at "DB baseline: NOT applied" | Step 2.4 skipped | [4.3](#43-db-baseline-not-applied-or-pre-flight-fails) |
| `make db-baseline` reports duplicates | Duplicate `package_name` / `user_id` rows | [4.3](#43-db-baseline-not-applied-or-pre-flight-fails) |
| nginx returns 502 | Upstream down, or wrong vhost edited | [4.4](#44-nginx-returns-502) |
| Dashboard gets 401 on every call | JWT secret or claims mismatch | [4.5](#45-dashboard-returns-401) |
| `make config-check` fails | Placeholder or missing secret | [4.6](#46-config-check-failures) |
| Events accepted (2xx) but no new DB rows | Processor not consuming | [4.7](#47-events-accepted-but-not-stored) |
| All traffic shares one rate limit / no geo data | `TRUSTED_PROXIES` missing | [4.8](#48-no-geo-data-or-shared-rate-limit) |

### 4.2 Processor will not start: dirty migration

Processor-Go refuses to start when `schema_migrations.dirty = true`. Version
*N* dirty means migration *N* failed and was rolled back in full.

1. Find the cause: `make logs-processor`. Fix it (usually a schema
   precondition; on a v012 DB, run `make db-baseline`).
2. Clear the flag:

   ```bash
   make db-force
   ```

   This sets the version to *N-1* with `dirty = false` after confirmation, so
   migration *N* re-runs on the next start.
3. Restart and verify:

   ```bash
   docker compose --env-file configs/single-host.env restart telemetry-processor
   make health
   ```

Do **not** run `db-force` before fixing the cause. The migration fails again and
sets the flag again.

### 4.3 DB baseline not applied, or pre-flight fails

- **Not applied:** run `make db-baseline`, then `make deploy`.
- **Pre-flight lists duplicates:** the baseline adds unique indexes on
  `rum_apps(package_name)` and `rum_users(user_id)`. The output lists each
  duplicate value and its row ids. Merge the duplicates (repoint child rows to one id, delete the
  rest), then re-run `make db-baseline`. Coordinate with the DB owner; these
  tables are shared with the analytics team.
- **Permission errors:** the `DATABASE_URL` role must own the `public.rum_*`
  tables and `analytics.v_mobile_rum_rca_evidence`.

### 4.4 nginx returns 502

1. Is the upstream up? `curl -fsS http://127.0.0.1:8001/ready` (or 8002,
   8003 `/api/v1/health`). If not, troubleshoot the container, not nginx.
2. Are you editing the live file? `readlink -f /etc/nginx/sites-enabled/<site>`;
   confirm with `sudo nginx -T | grep -n 'proxy_pass'`.
3. Ports match [§2.6](#26-wire-up-nginx)?
4. `sudo nginx -t && sudo systemctl reload nginx`, then wait a few seconds
   before retesting. Requests in flight during the reload can still return 502.

### 4.5 Dashboard returns 401

1. `EDGE_JWT_SECRET` in `configs/single-host.env` must equal edge_platform's
   **exactly** (watch for trailing whitespace and quotes).
2. `EDGE_JWT_ISSUER` and `EDGE_JWT_AUDIENCE` must be **unset**.
3. After editing, recreate the container (a restart does not reload env files):
   `docker compose --env-file configs/single-host.env up -d telemetry-rum-analytics`.

To rotate the secret, change it in edge_platform and here at the same time.

### 4.6 config-check failures

| Message | Fix |
|---|---|
| `Database config: contains placeholder values` | Replace `USER:PASSWORD@DB_HOST` in `DATABASE_URL` |
| `Kafka UI password: missing` | Run the command printed in the error message |
| `Redis password: unset or still CHANGE_ME` | Set `REDIS_PASSWORD` |
| `Kafka disk budget: ... missing or not a byte count` | Set `KAFKA_DISK_BUDGET_BYTES` (see [Kafka topics](#kafka-topics)) |
| `JWT secret: missing` | Set `EDGE_JWT_SECRET` (required when `EDGE_ENV=prod`) |
| `JWT fallback: unsafe in prod` | `EDGE_ALLOW_JWT_FALLBACK=false` |
| `JWT secret: WARNING ... placeholder` | Non-blocking. Rotate with edge_platform at the next window |

### 4.7 Events accepted but not stored

1. `make logs-collector`: confirm the collector publishes without Kafka errors.
2. `make logs-processor`: look for DB errors such as missing columns (schema
   drift, see the baseline doc) or connection refusals.
3. Inspect the topic and consumer lag in the Kafka UI ([§4.9](#49-access-kafka-ui)).
4. Check for poisoned messages: `SELECT count(*) FROM processor_dead_letter_events;`

**Lag alert.** The `kafka-lag-watch` service checks the processor group's lag
every 5 min and logs one `WARN kafka_lag_high lag=<n>` line per check while it
exceeds `LAG_ALERT_MESSAGES` (default 1000000, about 48 min of backlog at 350
batches/s). No cron, no notifier: grep for it.

```bash
docker compose --env-file configs/single-host.env logs kafka-lag-watch | grep kafka_lag_high
```

Keep `LAG_ALERT_MESSAGES` below `retention.bytes` ÷ average message size per
partition, or messages age out before the alert fires. `WARN
kafka_lag_check_failed` means the check itself failed (Kafka down); the
watcher keeps running and recovers on its own.

### 4.8 No geo data or shared rate limit

The collector sees nginx (Docker bridge gateway) as the client. Confirm
`TRUSTED_PROXIES=127.0.0.0/8,172.16.0.0/12,10.0.0.0/8` is set and that nginx sends
`X-Forwarded-For`. Then recreate the collector with `up -d telemetry-collector`.

### 4.9 Access Kafka UI

Bound to `127.0.0.1:8080` only. Open an SSH tunnel:

```bash
ssh -L 8080:localhost:8080 <user>@<host>       # add -p <port> if SSH is non-standard
```

Browse to `http://localhost:8080` and log in as `admin` with
`SPRING_SECURITY_USER_PASSWORD` from `configs/kafka-ui.env`.

### 4.10 Redis CLI

Redis is not published to the host:

```bash
docker compose --env-file configs/single-host.env exec telemetry-redis redis-cli   # auth via REDISCLI_AUTH
```

### 4.11 Secret rotation

| Secret | Where | After changing |
|---|---|---|
| `REDIS_PASSWORD` | `configs/single-host.env` | `make down && make deploy` (Redis and all clients) |
| `EDGE_JWT_SECRET` | `configs/single-host.env` and edge_platform | `up -d telemetry-rum-analytics` |
| DB password | DB server and `DATABASE_URL` | `up -d` all three Go services |
| Kafka UI password | `configs/kafka-ui.env` | `up -d kafka-ui` |

For post-incident rotation, see
[`docs/2026-09-05-breach-credential-rotation.md`](docs/2026-09-05-breach-credential-rotation.md).

---

## 5. Command reference

Run inside `deployments/single-host/`.

| Command | Purpose |
|---|---|
| `make db-baseline` | One-time: upgrade a v012 `edge_db` to the Go schema |
| `make db-force` | Clear a dirty processor migration (after fixing the cause) |
| `make deploy` | Validate, check baseline, start, health check |
| `make update` | Stop-the-world upgrade: stop collector, drain lag, `kafka-init`, ordered restart ([§3](#3-upgrade-and-rollback)) |
| `make restart` | Restart all containers (does **not** reload env files) |
| `make down` | Stop the stack (volumes kept) |
| `make clean` | Stop and **delete volumes** (asks first), then prune Docker. Destructive: loses `telemetry-upsert` and its offsets |
| `make status` / `make health` / `make health-detailed` | State and health |
| `make config-check` | Validate env files |
| `make kafka-init` | Re-run topic setup: reverts hand-made topic config drift |
| `make kafka-lag` | Processor consumer-group lag per partition |
| `make acceptance` / `make acceptance-x6` / `make acceptance-clean` | System acceptance run X1-X6 and its cleanup ([§3](#3-upgrade-and-rollback)); writes test data, needs `ACCEPTANCE_OK=yes` |
| `make logs` / `make logs-<service>` | Tail logs |
| `make test-deployment` | Send a sample event |
| `make monitor` | Live health and resource view |

Root-level shortcuts: `make list-deployments`, `make deploy-single-host`.

---

## 6. Security model

Hardened after the Sep 3 2026 breach (unauthenticated Kafka UI RCE).

- **Network:** every host port binds `127.0.0.1`. Public traffic enters only through nginx.
- **Containers:** all `read_only` with `no-new-privileges`. First-party
  `papijo/*` images run as `65534:65534`.
- **Image pinning:** first-party images by digest, third-party by exact tag. Enforced in CI.
- **Redis:** `requirepass` is mandatory. A missing value aborts compose.
- **Kafka UI:** kafbat (not provectuslabs), read-only, login form, loopback only.
- **Secrets:** never committed. `.gitignore` blocks `*.pem`, `*.key`, `*.jks`,
  `*.p12` and real `.env` files. Install the backstop hook with
  `shared/scripts/install-pre-commit-hook.sh`.

Details: [`docs/2026-09-08-secure-kafka-ui-design.md`](docs/2026-09-08-secure-kafka-ui-design.md).

---

## 7. Local development

The root `docker-compose.yml` builds services from the sibling source repos
(`../edge_telemetry_collector_go`, `../edge_telemetry_processor_go`). Use it to
iterate on code. It is not a deployment mode.

```bash
cp .env.dev.example .env.dev    # edit POSTGRES_* / DATABASE_URL
make up-build
make logs
make down
```

---

## Segmented deployment

DMZ (Collector-Go and Kafka) plus bank (Processor-Go, RUM Analytics and Redis),
linked over Kafka `:9093` with mTLS (one client cert each for the processor and
analytics). The collector runs `api_key` with keys from `rum-api-keys`; deploy
the DMZ first. Not in active use. See
[`deployments/segmented/dmz/README.md`](deployments/segmented/dmz/README.md),
[`deployments/segmented/bank/README.md`](deployments/segmented/bank/README.md) and
[`shared/README.md`](shared/README.md) for key provisioning.
