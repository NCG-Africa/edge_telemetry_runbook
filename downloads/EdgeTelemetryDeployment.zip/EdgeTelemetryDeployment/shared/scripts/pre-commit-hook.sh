#!/bin/bash
# Pre-commit hook: prevent accidental commit of private key material
# Install with: shared/scripts/install-pre-commit-hook.sh

set -euo pipefail

STAGED_SECRETS=$(git diff --cached --name-only | grep -E '\.(pem|key|p12|jks|keystore|truststore)$' || true)

if [ -n "$STAGED_SECRETS" ]; then
    echo "========================================="
    echo " ERROR: Private key material detected!"
    echo "========================================="
    echo ""
    echo "The following files appear to contain secrets:"
    echo "$STAGED_SECRETS"
    echo ""
    echo "Remove them from staging with:"
    echo "  git reset HEAD <file>"
    echo ""
    echo "If this is intentional (e.g., test fixtures), bypass with:"
    echo "  git commit --no-verify"
    echo "========================================="
    exit 1
fi
