# shellcheck shell=bash
# X5: a device's batches sent rapidly, plus a late offline batch with older event times, all
# land on one partition, in order, and the LWW tables keep the newest-by-event-time values
# (C11, P1, P4).
X5_IP=8.8.8.8 X5_LATE_IP=196.201.214.1
x5() {
  local dev=$DEV_PREFIX-x5 before msgs i ts sent=() newest geo ctx ok=0
  create_app x5 android || return 1
  issue_key x5 "$APP_ID" production || return 1
  wait_for "collector to load key x5" 15 key_known x5 || return 1

  before=$(ends)
  for i in $(seq 1 20); do
    ts=$(iso $(( i - 30 ))); sent+=("$ts")
    post_batch x5 /telemetry "$(render batch-4.0.json "$dev" "$dev-s1" "$PKG_PREFIX.x5" "$ts" en-US)" "$X5_IP" || return 1
  done
  newest=$ts
  wait_for "X5 batches in rum_telemetry_events" 60 events_are "$dev" 40 || return 1
  geo=$(geo_of "$dev-s1")
  log "    geo after 20 batches: $geo"
  check "processor_session_geo row from X-Forwarded-For $X5_IP" yes "$([ -n "$geo" ] && echo yes || echo no)" || ok=1

  # Offline batch: a day older, another locale and another client IP.
  ts=$(iso -86400); sent+=("$ts")
  post_batch x5 /telemetry "$(render batch-4.0.json "$dev" "$dev-s1" "$PKG_PREFIX.x5" "$ts" fr-FR)" "$X5_LATE_IP" || return 1
  wait_for "X5 late batch in rum_telemetry_events" 60 events_are "$dev" 42 || return 1

  msgs=$(kfind "$dev" "$before")
  check "Kafka messages for $dev" 21 "$(printf '%s\n' "$msgs" | grep -c .)" || ok=1
  check "partitions they landed on" 1 "$(printf '%s\n' "$msgs" | cut -f1 | sort -u | grep -c .)" || ok=1
  check "offsets strictly increasing" yes \
    "$(printf '%s\n' "$msgs" | cut -f2 | awk 'NR > 1 && $1 <= prev {bad=1} {prev=$1} END {print bad ? "no" : "yes"}')" || ok=1
  check "message order = send order" "$(printf '%s\n' "${sent[@]}" | paste -sd, -)" \
    "$(printf '%s\n' "$msgs" | cut -f5- | jq -r .data.timestamp | paste -sd, -)" || ok=1

  ctx=$(q "SELECT c.locale || '|' || to_char(c.observed_at AT TIME ZONE 'UTC', 'YYYY-MM-DD\"T\"HH24:MI:SS.MS\"Z\"')
           FROM processor_device_context c JOIN rum_devices d ON d.id = c.rum_device_id WHERE d.device_id = '$dev'")
  check "processor_device_context locale" en-US "${ctx%|*}" || ok=1
  check "processor_device_context observed_at" "$newest" "${ctx#*|}" || ok=1
  check "processor_session_geo observed_at" "$newest" "${geo##*|}" || ok=1
  check "processor_session_geo after the late batch" "$geo" "$(geo_of "$dev-s1")" || ok=1
  return $ok
}
# geo_of <session id>: "country|region|city|observed_at" from processor_session_geo, or empty.
geo_of() {
  q "SELECT g.country_code || '|' || coalesce(g.region, '') || '|' || coalesce(g.city, '') || '|'
            || to_char(g.observed_at AT TIME ZONE 'UTC', 'YYYY-MM-DD\"T\"HH24:MI:SS.MS\"Z\"')
     FROM processor_session_geo g JOIN rum_sessions s ON s.id = g.session_id WHERE s.session_id = '$1'"
}
