# EdgeTelemetryProcessor Database Schema Documentation

## Overview
This document describes the database schema for the EdgeTelemetryProcessor application, which processes real-time telemetry data from mobile applications via Kafka and stores normalized data in MSSQL Server.

## Database: EDGE_DB

---

## 1. rum_apps
**Purpose:** Stores application metadata for telemetry tracking

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | INT IDENTITY(1,1) | PRIMARY KEY | Auto-incrementing unique identifier |
| name | NVARCHAR(255) | NOT NULL | Application display name |
| version | NVARCHAR(50) | NOT NULL | Application version (e.g., "1.2.3") |
| build_number | NVARCHAR(50) | NOT NULL | Build number from CI/CD |
| package_name | NVARCHAR(255) | NOT NULL, UNIQUE | Unique app identifier (e.g., "com.company.app") |
| created_at | DATETIME2 | DEFAULT GETUTCDATE() | Record creation timestamp |

**Indexes:**
- `IX_rum_apps_package_name` on `package_name`

**Relationships:**
- One-to-many with `rum_sessions`

---

## 2. rum_devices
**Purpose:** Stores device hardware and platform information

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | INT IDENTITY(1,1) | PRIMARY KEY | Auto-incrementing unique identifier |
| platform | NVARCHAR(50) | NOT NULL | Platform type (Android, iOS) |
| platform_version | NVARCHAR(255) | NULL | OS version (e.g., "Android 13") |
| model | NVARCHAR(100) | NULL | Device model (e.g., "Pixel 7") |
| manufacturer | NVARCHAR(100) | NULL | Device manufacturer (e.g., "Google") |
| brand | NVARCHAR(100) | NULL | Device brand |
| android_sdk | NVARCHAR(10) | NULL | Android SDK level |
| android_release | NVARCHAR(50) | NULL | Android release version |
| fingerprint | NTEXT | NULL | Unique device fingerprint for identification |
| hardware | NVARCHAR(100) | NULL | Hardware identifier |
| product | NVARCHAR(100) | NULL | Product identifier |
| created_at | DATETIME2 | DEFAULT GETUTCDATE() | Record creation timestamp |

**Relationships:**
- One-to-many with `rum_sessions`

---

## 3. rum_users
**Purpose:** Stores user identifiers for session tracking

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | INT IDENTITY(1,1) | PRIMARY KEY | Auto-incrementing unique identifier |
| user_id | NVARCHAR(255) | NOT NULL, UNIQUE | External user identifier from app |
| created_at | DATETIME2 | DEFAULT GETUTCDATE() | Record creation timestamp |

**Indexes:**
- `IX_rum_users_user_id` on `user_id`

**Relationships:**
- One-to-many with `rum_sessions`

---

## 4. rum_sessions
**Purpose:** Stores user session information and aggregated metrics

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | INT IDENTITY(1,1) | PRIMARY KEY | Auto-incrementing unique identifier |
| session_id | NVARCHAR(255) | NOT NULL, UNIQUE | Unique session identifier from app |
| start_time | DATETIME2 | NOT NULL | Session start timestamp |
| duration_ms | INT | NULL | Session duration in milliseconds |
| event_count | INT | DEFAULT 0 | Total number of events in session |
| metric_count | INT | DEFAULT 0 | Total number of metrics in session |
| screen_count | INT | DEFAULT 0 | Number of screens visited |
| visited_screens | NTEXT | NULL | Comma-separated list of visited screens |
| is_first_session | BIT | DEFAULT 0 | Whether this is user's first session |
| total_sessions | INT | DEFAULT 1 | Total sessions for this user |
| network_type | NVARCHAR(50) | NULL | Network type during session (WiFi, 4G, etc.) |
| created_at | DATETIME2 | DEFAULT GETUTCDATE() | Record creation timestamp |
| app_id | INT | NOT NULL, FK | Reference to rum_apps.id |
| device_id | INT | NOT NULL, FK | Reference to rum_devices.id |
| user_id | INT | NOT NULL, FK | Reference to rum_users.id |

**Indexes:**
- `IX_rum_sessions_session_id` on `session_id`
- `IX_rum_sessions_app_id` on `app_id`
- `IX_rum_sessions_device_id` on `device_id`
- `IX_rum_sessions_user_id` on `user_id`

**Foreign Keys:**
- `app_id` → `rum_apps.id`
- `device_id` → `rum_devices.id`
- `user_id` → `rum_users.id`

**Relationships:**
- Many-to-one with `rum_apps`, `rum_devices`, `rum_users`
- One-to-many with `rum_telemetry_events`

---

## 5. rum_telemetry_events
**Purpose:** Stores raw telemetry events as they arrive from the application

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | INT IDENTITY(1,1) | PRIMARY KEY | Auto-incrementing unique identifier |
| event_type | NVARCHAR(50) | NOT NULL | Type of event ('metric', 'event', 'http_request') |
| event_name | NVARCHAR(255) | NULL | Name of the event or metric |
| timestamp | DATETIME2 | NOT NULL | When the event occurred |
| batch_timestamp | DATETIME2 | NOT NULL | When the batch was processed |
| created_at | DATETIME2 | DEFAULT GETUTCDATE() | Record creation timestamp |
| session_id | INT | NOT NULL, FK | Reference to rum_sessions.id |

**Indexes:**
- `IX_rum_telemetry_events_session_id` on `session_id`
- `IX_rum_telemetry_events_event_type` on `event_type`
- `IX_rum_telemetry_events_timestamp` on `timestamp`

**Foreign Keys:**
- `session_id` → `rum_sessions.id`

**Relationships:**
- Many-to-one with `rum_sessions`
- One-to-one with `rum_performance_metrics`, `rum_performance_events`, `rum_http_requests`

---

## 6. rum_performance_metrics
**Purpose:** Stores detailed performance metric data (CPU, memory, frame rendering)

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | INT IDENTITY(1,1) | PRIMARY KEY | Auto-incrementing unique identifier |
| metric_name | NVARCHAR(255) | NOT NULL | Name of the performance metric |
| value | FLOAT | NOT NULL | Measured value of the metric |
| unit | NVARCHAR(50) | NULL | Unit of measurement (ms, MB, %) |
| frame_build_duration_ms | FLOAT | NULL | Frame build time for UI metrics |
| frame_raster_duration_ms | FLOAT | NULL | Frame raster time for UI metrics |
| frame_type | NVARCHAR(50) | NULL | Type of frame rendered |
| frame_dropped | BIT | NULL | Whether frame was dropped |
| memory_type | NVARCHAR(50) | NULL | Type of memory measured |
| memory_source | NVARCHAR(50) | NULL | Source of memory measurement |
| created_at | DATETIME2 | DEFAULT GETUTCDATE() | Record creation timestamp |
| telemetry_event_id | INT | NOT NULL, FK | Reference to rum_telemetry_events.id |

**Indexes:**
- `IX_rum_performance_metrics_metric_name` on `metric_name`
- `IX_rum_performance_metrics_telemetry_event_id` on `telemetry_event_id`

**Foreign Keys:**
- `telemetry_event_id` → `rum_telemetry_events.id`

**Relationships:**
- One-to-one with `rum_telemetry_events`

---

## 7. rum_performance_events
**Purpose:** Stores discrete performance events (memory pressure, frame drops)

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | INT IDENTITY(1,1) | PRIMARY KEY | Auto-incrementing unique identifier |
| event_name | NVARCHAR(255) | NOT NULL | Name of the performance event |
| memory_usage_mb | FLOAT | NULL | Memory usage at time of event |
| memory_pressure_level | NVARCHAR(50) | NULL | Memory pressure level (low, medium, high) |
| memory_timestamp | DATETIME2 | NULL | Timestamp of memory measurement |
| frame_build_duration_ms | FLOAT | NULL | Frame build duration causing event |
| frame_raster_duration_ms | FLOAT | NULL | Frame raster duration causing event |
| frame_total_duration_ms | FLOAT | NULL | Total frame duration |
| frame_severity | NVARCHAR(50) | NULL | Severity of frame drop event |
| frame_target_fps | INT | NULL | Target FPS for frame measurement |
| created_at | DATETIME2 | DEFAULT GETUTCDATE() | Record creation timestamp |
| telemetry_event_id | INT | NOT NULL, FK | Reference to rum_telemetry_events.id |

**Indexes:**
- `IX_rum_performance_events_event_name` on `event_name`
- `IX_rum_performance_events_telemetry_event_id` on `telemetry_event_id`

**Foreign Keys:**
- `telemetry_event_id` → `rum_telemetry_events.id`

**Relationships:**
- One-to-one with `rum_telemetry_events`

---

## 8. rum_http_requests
**Purpose:** Stores HTTP request telemetry data for network performance analysis

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | INT IDENTITY(1,1) | PRIMARY KEY | Auto-incrementing unique identifier |
| url | NTEXT | NOT NULL | HTTP request URL |
| method | NVARCHAR(10) | NOT NULL | HTTP method (GET, POST, etc.) |
| status_code | INT | NOT NULL | HTTP response status code |
| duration_ms | INT | NOT NULL | Request duration in milliseconds |
| request_timestamp | DATETIME2 | NOT NULL | When the request was made |
| success | BIT | NOT NULL | Whether request was successful |
| created_at | DATETIME2 | DEFAULT GETUTCDATE() | Record creation timestamp |
| telemetry_event_id | INT | NOT NULL, FK | Reference to rum_telemetry_events.id |

**Indexes:**
- `IX_rum_http_requests_method` on `method`
- `IX_rum_http_requests_status_code` on `status_code`
- `IX_rum_http_requests_success` on `success`
- `IX_rum_http_requests_telemetry_event_id` on `telemetry_event_id`

**Foreign Keys:**
- `telemetry_event_id` → `rum_telemetry_events.id`

**Relationships:**
- One-to-one with `rum_telemetry_events`

---

## Data Flow Architecture

```
Kafka Message → TelemetryService → Normalized Entities
     ↓
1. Extract app/device/user info → rum_apps, rum_devices, rum_users
2. Create/update session → rum_sessions
3. Create telemetry event → rum_telemetry_events
4. Create specific data based on event type:
   - Performance metrics → rum_performance_metrics
   - Performance events → rum_performance_events
   - HTTP requests → rum_http_requests
```

## Key Design Principles

1. **Normalization:** Apps, devices, and users are stored once and referenced by sessions
2. **Event-Driven:** Each telemetry event creates a base record with type-specific details
3. **Time-Series Ready:** All tables include timestamps for time-based analysis
4. **Performance Optimized:** Indexes on frequently queried columns
5. **Extensible:** Easy to add new event types without schema changes

## Common Queries

### Session Analytics
```sql
-- Get session summary by app
SELECT a.name, COUNT(*) as session_count, AVG(s.duration_ms) as avg_duration
FROM rum_sessions s
JOIN rum_apps a ON s.app_id = a.id
GROUP BY a.name;
```

### Performance Monitoring
```sql
-- Get frame drop events by device model
SELECT d.model, COUNT(*) as frame_drops
FROM rum_performance_events pe
JOIN rum_telemetry_events te ON pe.telemetry_event_id = te.id
JOIN rum_sessions s ON te.session_id = s.id
JOIN rum_devices d ON s.device_id = d.id
WHERE pe.event_name = 'frame_drop'
GROUP BY d.model;
```

### HTTP Performance
```sql
-- Get API response times by endpoint
SELECT LEFT(url, 100) as endpoint, 
       AVG(duration_ms) as avg_response_time,
       COUNT(*) as request_count
FROM rum_http_requests
GROUP BY LEFT(url, 100);
```