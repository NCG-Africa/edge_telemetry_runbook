#!/usr/bin/env bash
# Print a consumer group's per-partition and total lag on one topic.
# Runs inside any confluentinc/cp-kafka:7.4.0 container (uses its CLI tools).
#
#   kafka-lag.sh <group> [bootstrap] [command-config]
#
# Last line is always "total <n>". Exits 0 whenever the lag could be read.
# Lag is measured against the topic's own end offsets, not just the partitions
# the group reports: a partition the group never committed counts from its
# earliest offset, so unconsumed data there is never hidden (the group lists
# such partitions only while a member holds them).
#
# Env: KAFKA_TOPIC (default telemetry-upsert), KAFKA_BOOTSTRAP_SERVERS (if no bootstrap arg).
set -euo pipefail

group=${1:?usage: kafka-lag.sh <group> [bootstrap] [command-config]}
bs=${2:-${KAFKA_BOOTSTRAP_SERVERS:-kafka:29092}}
topic=${KAFKA_TOPIC:-telemetry-upsert}
cc=()
[ -n "${3:-}" ] && cc=(--command-config "$3")

# "<topic>:<partition>:<offset>" per partition
offsets() { kafka-get-offsets --bootstrap-server "$bs" "${cc[@]}" --topic "$topic" --time "$1"; }

# Captured first so an unreachable broker or missing topic fails loudly here
# instead of looking like an empty topic (kafka-get-offsets errors on stdout).
starts=$(offsets -2) || { echo "kafka-lag: $starts" >&2; exit 1; }
ends=$(offsets -1) || { echo "kafka-lag: $ends" >&2; exit 1; }
declare -A start end committed
while IFS=: read -r _ p o; do [ -n "$p" ] && start[$p]=$o; done <<< "$starts"
while IFS=: read -r _ p o; do [ -n "$p" ] && end[$p]=$o; done <<< "$ends"
[ ${#end[@]} -gt 0 ] || { echo "kafka-lag: topic $topic not found on $bs" >&2; exit 1; }

# GROUP TOPIC PARTITION CURRENT-OFFSET ...; "-" = nothing committed. A group
# that doesn't exist yet has committed nothing, so a describe failure is fine.
describe=$(kafka-consumer-groups --bootstrap-server "$bs" "${cc[@]}" --describe --group "$group" --offsets 2>/dev/null || true)
while read -r _ t p cur _; do
  [ "$t" = "$topic" ] && [[ $cur =~ ^[0-9]+$ ]] && committed[$p]=$cur
done <<< "$describe"

total=0
for p in $(printf '%s\n' "${!end[@]}" | sort -n); do
  from=${committed[$p]:-${start[$p]}}
  lag=$(( end[$p] - from ))
  total=$(( total + lag ))
  echo "partition $p committed ${committed[$p]:--} end ${end[$p]} lag $lag"
done
echo "total $total"
